<?php
/**
 * Multi order for WooCommerce - Order Item metas
 *
 * @version 1.0.0
 * @since   1.0.0
 * @author  Algoritmika Ltd.
 */

if ( ! class_exists( 'Alg_MOWC_Order_Item_Metas' ) ) {

	class Alg_MOWC_Order_Item_Metas {
		const SUB_ORDER = '_alg_mowc_suborder';
	}
}