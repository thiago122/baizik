<?php if ( ! defined( 'ABSPATH' ) ) exit; 
/*
	Plugin Name: Order Splitter for WooCommerce
	Plugin URI: https://wordpress.org/plugins/woo-order-splitter
	Description: Split, merge, clone, your crowd/combined/bulk orders using intelligent rules.
	Version: 2.8.3
	Author: Fahad Mahmood
	Author URI: http://androidbubble.com/blog/
	Text Domain: woo-order-splitter
	Domain Path: /languages/	
	License: GPL2
	
	
	This WordPress plugin is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 2 of the License, or
	any later version.
	 
	This WordPress plugin is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	 
	You should have received a copy of the GNU General Public License
	along with this WordPress plugin. If not, see http://www.gnu.org/licenses/gpl-2.0.html.
*/


	if ( ! defined( 'ABSPATH' ) ) {
		exit; // Exit if accessed directly
	}else{
		 clearstatcache();
	}
	
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	
	$wc_os_all_plugins = get_plugins();
	$wc_os_active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins' ) );
	
	if ( array_key_exists('woocommerce/woocommerce.php', $wc_os_all_plugins) && in_array('woocommerce/woocommerce.php', $wc_os_active_plugins) ) {
		
		
		
		
		global $wc_os_data, $wc_os_pro, $wc_os_activated, $wc_os_premium_copy, $yith_pre_order, $wc_os_bulk_instantiated, $wc_os_debug, $wos_actions_arr, $wc_os_cust, $wos_notices_css;
		$wos_notices_css = '.wos_notice_div {
								width: 98%;
								float: left;
								text-align: center;
								font-size: 16px;
								text-transform: uppercase;
								background-color: rgba(255,255,255,0.9);
								padding: 16px 0;
								border: 1px solid rgba(122,122,122, 0.3);
								margin: 0 0 20px 0;
								displey:none;
							}
							.woocommerce-checkout .wos_notice_div {
								width:100%;
							}
							.post-type-archive-product .wos_notice_div {
								margin: 0 auto;
								width: 78%;
								float: none;
							}';
		
		$wc_os_cust = get_option( 'wc_os_cuztomization', array() );
		
		$wos_actions_arr = array(
			
			'none' => array('action'=>__('None', 'woo-order-splitter'), 'description'=>__('Do not perform split action of any type.', 'woo-order-splitter')),
			'default' => array('action'=>__('Default', 'woo-order-splitter'), 'description'=>__('Perform split action if any of the following product items are found in the order. So every single item in the order will be added in a separate order.', 'woo-order-splitter')),
			'exclusive' => array('action'=>__('Exclusive', 'woo-order-splitter'), 'description'=>__('If any of the following product items are found in the order, separate them in new orders exclusively. So each selected item will be in a separate order.', 'woo-order-splitter')),
			'inclusive' => array('action'=>__('Inclusive', 'woo-order-splitter'), 'description'=>__('If any of the following product items are found in the order, separate them in a new order inclusively. So selected items will be grouped in another order separately.', 'woo-order-splitter')),
			'shredder' => array('action'=>__('Shredder', 'woo-order-splitter'), 'description'=>__('If any of the following product items are found in the order, group them in a new order. And other items will be separated.', 'woo-order-splitter')),
			'io' => array('action'=>__('In stock', 'woo-order-splitter').'/'.__('out of stock', 'woo-order-splitter'), 'description'=>__('If this option is selected, plugin will separate in stock and out of stock items. So items will be grouped as in stock items in one and remaining items in other order.', 'woo-order-splitter')),
			'quantity_split' => array('action'=>__('Quantity Split', 'woo-order-splitter'), 'description'=>__('If this option is selected, multiple orders can be created with default or defined quantity ratio.', 'woo-order-splitter')),
			'cats' => array('action'=>__('Category Based', 'woo-order-splitter'), 'description'=>__('If this option is selected, plugin will separate items or group of items according to the product categories these items belong to.', 'woo-order-splitter')),
			'group_cats' => array('action'=>__('Grouped Categories', 'woo-order-splitter'), 'description'=>__('If this option is selected, plugin will separate category based items or group of category based items into assigned groups.', 'woo-order-splitter')),
			'groups' => array('action'=>__('Grouped Products', 'woo-order-splitter'), 'description'=>__('If this option is selected, plugin will separate items or group of items into assigned groups.', 'woo-order-splitter')),
			'group_by_vendors' => array('action'=>__('Group by Vendors', 'woo-order-splitter'), 'description'=>__('If this option is selected, plugin will separate items or group of items by multi-vendors into assigned groups.', 'woo-order-splitter'))
			
		);

	
		$wc_os_debug = isset($_GET['wc_os_debug']);
		
		$yith_pre_order = (in_array( 'yith-pre-order-for-woocommerce/init.php',  $wc_os_active_plugins) || in_array( 'yith-woocommerce-pre-order.premium/init.php',  $wc_os_active_plugins));
		
		$wc_os_activated = true;
		
		$wc_os_bulk_instantiated = false;
		
		$wc_os_premium_copy = 'http://shop.androidbubbles.com/product/woo-order-splitter';		
		$wc_os_data = get_plugin_data(__FILE__);
		
		
		define( 'WC_OS_PLUGIN_DIR', dirname( __FILE__ ) );
		
		$wc_os_pro_file = WC_OS_PLUGIN_DIR . '/pro/wcos-pro.php';
		
		
		$wc_os_pro =  file_exists($wc_os_pro_file);
		
		require_once WC_OS_PLUGIN_DIR . '/inc/functions.php';
		
		if($wc_os_pro)
		include_once($wc_os_pro_file);
		
		if(is_admin()){
			

			//if(!is_multisite())
			add_action( 'admin_menu', 'wc_os_admin_menu' );	
			//else
			//add_action('network_admin_menu', 'wc_os_menu');
			
			add_filter('acf/settings/remove_wp_meta_box', '__return_false');
			
			if(function_exists('wc_os_plugin_linx')){
				$plugin = plugin_basename(__FILE__); 
				add_filter("plugin_action_links_$plugin", 'wc_os_plugin_linx' );	
			}
			
			if(function_exists('wc_os_admin_scripts'))
			add_action( 'admin_enqueue_scripts', 'wc_os_admin_scripts', 99 );	
			
		}else{
			if(function_exists('wc_os_front_scripts'))
			add_action( 'wp_enqueue_scripts', 'wc_os_front_scripts', 99 );	
		}
		
	}