<?php if ( ! defined( 'ABSPATH' ) ) exit; 
	
	function wc_os_currency_symbol(){
		return (function_exists('get_woocommerce_currency_symbol')?get_woocommerce_currency_symbol():'$');
	}

	include_once('wos-emails.php');
	
	function sanitize_wc_os_data( $input ) {
		if(is_array($input)){		
			$new_input = array();	
			foreach ( $input as $key => $val ) {
				$new_input[ $key ] = (is_array($val)?sanitize_wc_os_data($val):sanitize_text_field( $val ));
			}			
		}else{
			$new_input = sanitize_text_field($input);			
			if(stripos($new_input, '@') && is_email($new_input)){
				$new_input = sanitize_email($new_input);
			}
			if(stripos($new_input, 'http') || wp_http_validate_url($new_input)){
				$new_input = esc_url($new_input);
			}			
		}	
		return $new_input;
	}	
	
	
	if(!function_exists('wc_os_pre')){
	function wc_os_pre($data){
			if(isset($_GET['debug'])){
				wc_os_pree($data);
			}
		}	 
	} 	
	if(!function_exists('wc_os_pree')){
	function wc_os_pree($data){
				echo '<pre>';
				print_r($data);
				echo '</pre>';	
		
		}	 
	} 
	
	function wc_os_settings_update(){
		
		//wc_os_pree(get_option('wc_os_auto_forced', 0));exit;
		if(isset($_GET['post_type']) && $_GET['post_type']=='shop_order')// && get_option('wc_os_auto_forced', 0)
		wc_os_crons();
		
		if(!empty($_POST)){
			//wc_os_pree($_POST);exit;
			//wc_os_pree($_POST);exit;
			global $wc_os_currency, $wc_os_settings;
			$split_action = (isset($_POST['split_action'])?$_POST['split_action']:array());		
			//wc_os_pree($split_action);exit;
			if(!empty($_POST) && isset($_POST['wc_os_settings'])){
				 
				
				$wc_os_currency = 
	
				wc_os_settings_refresh();
				//wc_os_pree($_POST);exit;
				
				
			
						
				
				if ( 
					! isset( $_POST['wc_os_settings_field'] ) 
					|| ! wp_verify_nonce( $_POST['wc_os_settings_field'], 'wc_os_settings_action' ) 
				) {
				
				   _e('Sorry, your nonce did not verify.', 'woo-order-splitter');
				   exit;
				
				} else {
				
				   // process form data
				   		$split_action_existing = array();
						if(!empty($wc_os_settings['wc_os_products'])){
							foreach($wc_os_settings['wc_os_products'] as $action_old=>$data_old){
								if(!empty($data_old)){
									//wc_os_pree($split_action_existing);
									foreach($data_old as $item_old){		
										
										$item_old_arr = (is_array($item_old)?$item_old:array($item_old));
										
										foreach($item_old_arr as $item_old){														
											$split_action_existing[$item_old] = $action_old;
										}
										
										//wc_os_pree($item_old);
										//wc_os_pree($action_old);		
									}
								}
							}
						}

						//pree($split_action);
						//wc_os_pree($_POST);exit;
						$wc_os_additional = (isset($_POST['wc_os_settings']['wc_os_additional']));			   
						
						$wc_os_settings_updated = wc_os_sanitize_text_or_array_field($_POST['wc_os_settings'] );
						//wc_os_pree($split_action_existing);
						//wc_os_pree($wc_os_settings);
						
						//wc_os_pree($wc_os_settings_updated);exit;
						
						$wc_os_settings_updated['wc_os_products'] = (isset($wc_os_settings_updated['wc_os_products']) && is_array($wc_os_settings_updated['wc_os_products']))?$wc_os_settings_updated['wc_os_products']:(isset($wc_os_settings['wc_os_products'])?$wc_os_settings['wc_os_products']:'');
						
						$wc_os_settings_updated['wc_os_ie'] = isset($wc_os_settings_updated['wc_os_ie'])?$wc_os_settings_updated['wc_os_ie']:$wc_os_settings['wc_os_ie'];
						
						$wc_os_settings_updated['wc_os_cats'] = ((isset($wc_os_settings['wc_os_cats']) && is_array($wc_os_settings['wc_os_cats']))?$wc_os_settings['wc_os_cats']:array());
						
						$wc_os_settings_updated['wc_os_qty_split_option'] = isset($wc_os_settings_updated['wc_os_qty_split_option'])?$wc_os_settings_updated['wc_os_qty_split_option']:(isset($wc_os_settings['wc_os_qty_split_option'])?$wc_os_settings['wc_os_qty_split_option']:'');
						
						$wc_os_settings_updated['wc_os_additional'] = (isset($wc_os_settings_updated['wc_os_additional']) && is_array($wc_os_settings_updated['wc_os_additional']))?$wc_os_settings_updated['wc_os_additional']:(isset($wc_os_settings['wc_os_additional'])?$wc_os_settings['wc_os_additional']:'');
						
						
						//pree($wc_os_settings_updated['wc_os_ie']);exit;
						//exit;
						/*
						if isset() has more than one variable submitted to it, 
						then all variables must return true for for isset to be true.
						So isset($a, $b) is the same as isset($a) && isset($b).
						The reason I am checking both variables is because if 
						$wc_os_settings_updated['wc_os_all_product'] is not checked, 
						it is not submitted with the form.
						Since it is on the same form as $wc_os_settings_updated['wc_os_ie'], 
						I can test to see if that field has been submitted to verify that the form is
						telling us that $wc_os_settings_updated['wc_os_all_product'] is unchecked.
						http://php.net/manual/en/function.isset.php
						*/
						//pree($split_action);
						//pree($wc_os_settings_updated['wc_os_ie']);
						//pree($_POST);exit;
						$wc_os_products_existing = $wc_os_settings['wc_os_products'];
						//pree($wc_os_products_existing);exit;
						$wc_os_settings_updated['wc_os_all_products'] = isset($wc_os_settings_updated['wc_os_all_product'],$wc_os_settings_updated['wc_os_ie'])?true:(isset($wc_os_settings['wc_os_all_product'])?$wc_os_settings['wc_os_all_product']:''); 
						
						$wc_os_settings_updated['wc_os_products'] = array_merge($wc_os_products_existing, $wc_os_settings_updated['wc_os_products']);
						$wc_os_settings_updated['wc_os_products'] = (!empty($wc_os_settings_updated['wc_os_products'])?array_filter($wc_os_settings_updated['wc_os_products'], 'is_array'):array());
						//pree($wc_os_settings_updated);//exit;
						//pree($wc_os_settings_updated['wc_os_products']);
						
						//wc_os_pree($wc_os_settings_updated['wc_os_products']);
						if(!empty($wc_os_settings_updated['wc_os_products'])){ //07-05-2019
							foreach($wc_os_settings_updated['wc_os_products'] as $item_action=>$item_ids){
								
								//pree($item_action);//pree($item_ids);
								//$wc_os_settings_updated['wc_os_products']
								if(!empty($item_ids)){
									foreach($item_ids as $index=>$item_id_item){
										//wc_os_pree('$index');
										//wc_os_pree($index);
										//wc_os_pree('$item_id');
										//wc_os_pree($item_id_item);
										//wc_os_pree($item_id);
										$item_id_arr = (is_array($item_id_item)?$item_id_item:array($item_id_item));
										
										//wc_os_pree($item_id_arr);
										
										foreach($item_id_arr as $item_id){
											
											//pree($split_action);pree($split_action_existing);
											$item_action_valid = ((is_array($split_action) && isset($split_action[$item_id]))?$split_action[$item_id]:(isset($split_action_existing[$item_id])?$split_action_existing[$item_id]:''));
											//wc_os_pree($item_action_valid.' - '.$item_action);
											//pree($item_action.' && '.$item_action_valid);
											if($item_action_valid==$item_action){
											}elseif($item_action && $item_action_valid){
												
												//pree($item_action.' && '.$index);
												if(is_numeric($index)){
													unset($wc_os_settings_updated['wc_os_products'][$item_action][$index]);																								
												}
												$wc_os_settings_updated['wc_os_products'][$item_action_valid][] = $item_id;
											}
										}
									}
								}
							}
							$wc_os_settings_updated['wc_os_products'] = wos_array_unique_recursive($wc_os_settings_updated['wc_os_products']);
						}
						//wc_os_pree($wc_os_settings_updated['wc_os_products']);
						
						//exit;
						//wc_os_pree(sanitize_wc_os_data($wc_os_settings_updated));exit;
						//pree($wc_os_settings_updated);exit;
						//unset($wc_os_settings_updated['wc_os_products']['b']);
						//unset($wc_os_settings_updated['wc_os_products']['c']);
						update_option('wc_os_settings', sanitize_wc_os_data($wc_os_settings_updated));
						//exit;
				  
						//add_action( 'admin_notices', 'wc_os_admin_notice_success' );
						
						//pree($_POST);
						
						
						$wc_os_auto_forced = (isset($_POST['wc_os_auto_forced'])?sanitize_wc_os_data($_POST['wc_os_auto_forced']):($wc_os_additional?0:get_option('wc_os_auto_forced', 0)));
						
						$wc_os_auto_clone = (isset($_POST['wc_os_auto_clone'])?sanitize_wc_os_data($_POST['wc_os_auto_clone']):($wc_os_additional?0:get_option('wc_os_auto_clone', 0)));
						
						$wc_os_billing_off = (isset($_POST['wc_os_billing_off'])?sanitize_wc_os_data($_POST['wc_os_billing_off']):($wc_os_additional?0:get_option('wc_os_billing_off', 0)));
				
						$wc_os_shipping_off = (isset($_POST['wc_os_shipping_off'])?sanitize_wc_os_data($_POST['wc_os_shipping_off']):($wc_os_additional?0:get_option('wc_os_shipping_off', 0)));
						
						$wc_os_shipping_cost = (isset($_POST['wc_os_shipping_cost'])?sanitize_wc_os_data($_POST['wc_os_shipping_cost']):($wc_os_additional?0:get_option('wc_os_shipping_cost', 0)));
				
						$wc_os_order_comments_off = (isset($_POST['wc_os_order_comments_off'])?sanitize_wc_os_data($_POST['wc_os_order_comments_off']):($wc_os_additional?0:get_option('wc_os_order_comments_off', 0)));
						
						$wc_os_backorder_mail_notification = (isset($_POST['wc_os_backorder_mail_notification'])?sanitize_wc_os_data($_POST['wc_os_backorder_mail_notification']):($wc_os_additional?0:get_option('wc_os_backorder_mail_notification', 0)));
						
						$wc_os_order_title_splitted = (isset($_POST['wc_os_order_title_splitted'])?sanitize_wc_os_data($_POST['wc_os_order_title_splitted']):($wc_os_additional?0:get_option('wc_os_order_title_splitted', 0)));
						
						
						
						$wc_os_order_combine_email = (isset($_POST['wc_os_order_combine_email'])?sanitize_wc_os_data($_POST['wc_os_order_combine_email']):($wc_os_additional?0:get_option('wc_os_order_combine_email', 0)));
						$wc_os_order_split_email = (isset($_POST['wc_os_order_split_email'])?sanitize_wc_os_data($_POST['wc_os_order_split_email']):($wc_os_additional?0:get_option('wc_os_order_split_email', 0)));
						
						$wc_os_order_splitf_column = (isset($_POST['wc_os_order_splitf_column'])?sanitize_wc_os_data($_POST['wc_os_order_splitf_column']):($wc_os_additional?0:get_option('wc_os_order_splitf_column', 0)));
						
						$wc_os_order_clonef_column = (isset($_POST['wc_os_order_clonef_column'])?sanitize_wc_os_data($_POST['wc_os_order_clonef_column']):($wc_os_additional?0:get_option('wc_os_order_clonef_column', 0)));
						//pree($wc_os_order_splitf_column);
	
						//pree($_POST);exit;
						update_option( 'wc_os_auto_forced', $wc_os_auto_forced );
						update_option( 'wc_os_auto_clone', $wc_os_auto_clone );						
						update_option( 'wc_os_billing_off', $wc_os_billing_off );
						update_option( 'wc_os_shipping_off', $wc_os_shipping_off );
						update_option( 'wc_os_shipping_cost', $wc_os_shipping_cost );
						update_option( 'wc_os_order_comments_off', $wc_os_order_comments_off );
						update_option( 'wc_os_backorder_mail_notification', $wc_os_backorder_mail_notification );
						update_option( 'wc_os_order_title_splitted', $wc_os_order_title_splitted );
						
						update_option( 'wc_os_order_combine_email', $wc_os_order_combine_email );
						update_option( 'wc_os_order_split_email', $wc_os_order_split_email );
						
						
						update_option( 'wc_os_order_splitf_column', $wc_os_order_splitf_column );
						update_option( 'wc_os_order_clonef_column', $wc_os_order_clonef_column );
						
						
						//pree($_POST);exit;
						//pree($wc_os_billing_off);
						//exit;
											
						wc_os_settings_refresh();
				   
				}
				
				
				
				
	
				
			}
	
	
			//pree($_POST);exit;
			
			if(!empty($_POST) && isset($_POST['wos_actions'])){
				 
			
				if ( 
					! isset( $_POST['wc_os_cuztomization_field'] ) 
					|| ! wp_verify_nonce( $_POST['wc_os_cuztomization_field'], 'wc_os_cuztomization' ) 
				) {
				
				   _e('Sorry, your nonce did not verify.', 'woo-order-splitter');
				   exit;
				
				} else {
					
					//pree($_POST);exit;
					update_option( 'wc_os_cuztomization', wc_os_sanitize_text_or_array_field($_POST['wos_actions']) );
					update_option( 'wc_os_cart_notices', wc_os_sanitize_text_or_array_field($_POST['wos_cart_notices']) );
					
				}
			
			}	
			
			
			if(!empty($_POST) && isset($_POST['wc_os_cats'])){
				 
				//wc_os_pree($_POST);exit;
				if ( 
					! isset( $_POST['wc_os_cats_field'] ) 
					|| ! wp_verify_nonce( $_POST['wc_os_cats_field'], 'wc_os_cats_action' ) 
				) {
				
				   _e('Sorry, your nonce did not verify.', 'woo-order-splitter');
				   exit;
				
				} else {
					//wc_os_pree($_POST);exit;
					//wc_os_pree($wc_os_settings);exit;
					$wc_os_settings['wc_os_ie'] = (isset($_POST['wc_os_cats']['group_cats'])?'group_cats':'cats');
					//wc_os_pree($wc_os_settings['wc_os_ie']);exit;
					
					$updated_split_action = array();
					switch($wc_os_settings['wc_os_ie']){
						case 'group_cats':			
							//wc_os_pree('updated_split_action');
							//wc_os_pree($split_action);
							if(!empty($split_action)){
								foreach($split_action as $sa_name=>$sa_data){
									//wc_os_pree($sa_data);
									foreach($sa_data as $sa_item){
										if(!is_array($sa_item) && $sa_item!=''){
											$updated_split_action[$sa_item] = $sa_name;
										}
									}
								}
							}//exit;
							//wc_os_pree($updated_split_action);exit;
						break;
					}
					
					$split_action_existing = array();
					//pree($wc_os_settings['wc_os_cats']);exit;
					if(!empty($wc_os_settings['wc_os_cats'])){						
						//wc_os_pree('split_action_existing');
						//pree($wc_os_settings['wc_os_cats']);
						foreach($wc_os_settings['wc_os_cats'] as $action_old=>$data_old){
							if(!empty($data_old)){
								foreach($data_old as $item_old_item){
									//wc_os_pree($action_old.' - '.$item_old);
									$item_old_arr = (is_array($item_old_item)?$item_old_item:array($item_old_item));
									
									foreach($item_old_arr as $item_old){
										if($item_old!=''){
											$split_action_existing[$item_old] = $action_old;
										}
									}
								}
							}
						}
						//wc_os_pree($split_action_existing);exit;
					}	
					//exit;
					//wc_os_pree($split_action_existing);exit;
					//pree($split_action);
					//pree($wc_os_settings);
					//pree($_POST);exit;
					$wc_os_settings_updated = wc_os_sanitize_text_or_array_field($_POST['wc_os_cats']);
					//wc_os_pree($wc_os_settings_updated);exit;
					$wc_os_products_existing = $wc_os_settings['wc_os_cats'];
					//wc_os_pree($wc_os_products_existing);
					$wc_os_settings_updated['wc_os_cats'] = array_merge($wc_os_products_existing, $wc_os_settings_updated);
					//wc_os_pree($wc_os_settings_updated);exit;
					$wc_os_settings_updated['wc_os_cats'] = (!empty($wc_os_settings_updated['wc_os_cats'])?array_filter($wc_os_settings_updated['wc_os_cats'], 'is_array'):array());
					
					$wc_os_settings_group_cats = $wc_os_settings_updated['wc_os_cats']['group_cats'];
					$wc_os_settings_cats = $wc_os_settings_updated['wc_os_cats']['cats'];
					//wc_os_pree($wc_os_settings_updated);exit;
					//wc_os_pree($wc_os_settings_updated['wc_os_cats']);
					//wc_os_pree($split_action);
					//wc_os_pree($split_action_existing);
					//pree($wc_os_settings_updated['wc_os_products']);//exit;
					if(!empty($wc_os_settings_updated['wc_os_cats'])){ //07-05-2019
						$wc_os_settings_refreshed = array();
						foreach($wc_os_settings_updated['wc_os_cats'] as $item_action=>$item_ids){
							//$wc_os_settings_updated['wc_os_products']
							//wc_os_pree($item_action);
							//wc_os_pree($item_ids);
							if(!empty($item_ids)){
								foreach($item_ids as $index=>$item_id_item){
									
									$item_id_arr = (is_array($item_id_item)?$item_id_item:array($item_id_item));
									//wc_os_pree($item_id_arr);
									foreach($item_id_arr as $item_id){
										//wc_os_pree($item_action_valid);
										$item_action_valid = ((is_array($split_action) && isset($split_action[$item_id]))?$split_action[$item_id]:(isset($split_action_existing[$item_id])?$split_action_existing[$item_id]:''));
										//$item_action_valid = (isset($split_action[$item_id])?$split_action[$item_id]:'');//:$split_action_existing[$item_id]);
										//wc_os_pree($item_id.' - '.$item_action_valid.' - '.$item_action);
										$wc_os_settings_refreshed[$item_action][] = $item_id;
										/*
										if($item_action_valid==$item_action){
											$wc_os_settings_refreshed[$item_action][]=$item_id;
										}elseif($item_action && $item_action_valid){
											
											unset($wc_os_settings_updated['wc_os_cats'][$item_action][$index]);			
											
											//pree('$wc_os_settings_updated["wc_os_cats"]['.$item_action.']['.$index.']');
											//if($split_action[$item_id])								
											//$wc_os_settings_updated['wc_os_cats'][$item_action_valid][]=$item_id;
										}
										*/
									
									}
								}
							}
						}
						
						//wc_os_pree($wc_os_settings_refreshed);
						$wc_os_settings_updated = wos_array_unique_recursive($wc_os_settings_refreshed);				
					
					}
					
					$existing_group_cats = $wc_os_settings['wc_os_cats']['group_cats'];
					$existing_cats = (isset($wc_os_settings['wc_os_cats'])?$wc_os_settings['wc_os_cats']['cats']:array());
					//pree($split_action);
					//wc_os_pree($wc_os_settings_updated);exit;
					//pree($wc_os_settings['wc_os_ie']);
					$wc_os_settings['wc_os_cats'] = $wc_os_settings_updated;
					
					//pree($wc_os_settings['wc_os_ie']);exit;
					
					switch($wc_os_settings['wc_os_ie']){
						case 'group_cats':
							
							$wc_os_settings['wc_os_cats']['cats'] = $existing_cats;
							$wc_os_settings['wc_os_cats']['group_cats'] = $wc_os_settings_group_cats;
							
						break;
						
						case 'cats':
							
							$wc_os_settings['wc_os_cats']['cats'] = $wc_os_settings_cats;
							$wc_os_settings['wc_os_cats']['group_cats'] = $existing_group_cats;
						
						break;
					}
					
					//wc_os_pree($_POST);exit;
					//wc_os_pree($wc_os_settings);exit;
					//wc_os_pree(sanitize_wc_os_data($wc_os_settings));exit;
					
					update_option('wc_os_settings', sanitize_wc_os_data($wc_os_settings));
					//wc_os_pree(get_option('wc_os_settings'));exit;
				}
			
			}	
			
			if(!empty($_POST) && isset($_POST['wc_os_vendors'])){
				 
				//wc_os_pree($_POST);exit;
				if ( 
					! isset( $_POST['wc_os_vendors_field'] ) 
					|| ! wp_verify_nonce( $_POST['wc_os_vendors_field'], 'wc_os_vendors_action' ) 
				) {
				
				   _e('Sorry, your nonce did not verify.', 'woo-order-splitter');
				   exit;
				
				} else {
					$wc_os_settings['wc_os_ie'] = (array_key_exists('wc_os_vendors', $_POST['split_action'])?'group_by_vendors':$wc_os_settings['wc_os_ie']);
					$wc_os_settings['wc_os_vendors'] = sanitize_wc_os_data($_POST['wc_os_vendors']);
					//wc_os_pree($wc_os_settings);
					//pree($_POST);exit;
					update_option('wc_os_settings', sanitize_wc_os_data($wc_os_settings));
					
				}
			}
	
		}
	}
	
	add_action('admin_init', 'wc_os_settings_update');	
	
	class wc_os_order_splitter {
		
		/** @var original order ID. */
		public $original_order_id;
		public $processing;
		public $auto_split;
		public $exclude_items;
		public $include_items;
		public $include_items_qty;
		public $general_array;
		public $cron_in_progress;
		public $clone_in_progress;
	
		/**
		 * Fire clone_order function on clone request.
		 */
		
		function __construct() {
			
			$this->processing = true;
			$this->auto_split = false;
			$this->exclude_items = array();
			$this->include_items = array();
			$this->include_items_qty = array();
			$this->general_array = array();
			$this->cron_in_progress = false;
			$this->clone_in_progress = false;
			
			add_action( 'plugins_loaded', array($this, 'duplicationCheck') );
			add_action( 'plugins_loaded', array($this, 'splitCheck') );
			
			
		}
		
		
		
		
				
		public function duplicationCheck() {
			
			if (isset($_GET['clone']) && $_GET['clone'] == 'yes' && isset($_GET['_wpnonce'])){// && isset($_GET['clone-session']) && $_GET['clone-session'] == date('Ymhi')) {
				
				if ( is_user_logged_in() ) {
				
					if( current_user_can('manage_woocommerce') && wc_os_order_cloning()) {
				
						add_action('init', array($this, 'clone_order'));
						
					
					} else {
						
						wp_die(__('You do not have permission to complete this action.', 'woo-order-splitter'));
						
					}
					
				} else {
				
					wp_die(__('You have to be logged in to complete this action', 'woo-order-splitter'));
					
				}
				
			}
			
		}
		
		public function splitCheck() {
			
			if (isset($_GET['split']) && $_GET['split'] == 'init' && isset($_GET['_wpnonce'])){// && isset($_GET['split-session']) && $_GET['split-session'] == date('Ymhi')) {
				
				if ( is_user_logged_in() ) {
				
					if( current_user_can('manage_woocommerce') && wc_os_order_split()) {
						
						global $wc_os_settings;
						
						//wc_os_pree($wc_os_settings);exit;
						//pree($wc_os_settings['wc_os_ie']);exit;
						
						switch($wc_os_settings['wc_os_ie']){
							default:								
								//add_action('init', array($this, 'split_order_logic')); //14/05/2019 - disabling direct split and redirecting through cron
								$originalorderid = $_GET['order_id'];
								//pree($originalorderid);
								update_post_meta($originalorderid, 'wc_os_order_splitter_cron', true);
								//pree(get_post_meta($originalorderid, 'wc_os_order_splitter_cron', true));exit;
							break;
							case 'default':
								//wc_os_pree($order_id);
								//
								add_action('init', array($this, 'split_order'));
								
							break;								
						}
												
					
					} else {
						
						wp_die(__('You do not have permission to complete this action...', 'woo-order-splitter'));
						
					}
					
				} else {
				
					wp_die(__('You have to be logged in to complete this action', 'woo-order-splitter'));
					
				}
				
			}
			
		}	
		
		
		
		
		/**
		 * Create replicated order post and initiate cloned_order_data function.
		 */
	  
						
		public function clone_order($originalorderid = null, $force=false){
			//pree($this->cron_in_progress);exit;
			if($this->cron_in_progress && !$force)
			return;
			//$currentUser = wp_get_current_user();
			
			$original_order = new WC_Order($originalorderid);
			
			$user_id = $original_order->get_user_id();
			
			$order_data =  array(
				'post_type'     => 'shop_order',
				'post_status'   => 'publish',
				'ping_status'   => 'closed',
				'post_author'   => $user_id,
				'post_password' => uniqid( 'order_' ),
			);
		
			$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
			//update_post_meta($order_id, 'testing_position', 'clone_order');
			//wc_os_pree('clone_order/order_id'. $order_id);
	
			if ( is_wp_error( $order_id ) ) {
				
				if(!$this->cron_in_progress)
				add_action( 'admin_notices', array($this, 'clone__error'));
			} else {
				$this->clone_in_progress = true;
				$this->cloned_order_data($order_id, $originalorderid);	
				if($force){	
					update_post_meta($originalorderid, 'wos_cloned', true);
				}
			}
			
			return $order_id;
			
			
		}
		
		public function products_with_actions($filter=''){
			
			$ret = array();
			
			global $wc_os_settings;
			
			$wc_os_products = $wc_os_settings['wc_os_products'];
			
			if(!empty($wc_os_products)){
				$current_keys = array_keys($wc_os_products);
				if(is_numeric(current($current_keys))){
					if(!empty($wc_os_products)){
						foreach($wc_os_products as $product_id){
								if($filter=='' || ($filter!='' && $filter==$wc_os_settings['wc_os_ie'])){
									$ret[$product_id] = $wc_os_settings['wc_os_ie'];
								}
						}
					}					
				}else{
					if(!empty($wc_os_products)){
						foreach($wc_os_products as $action=>$products){
							
							/*wc_os_pree('$action');
							wc_os_pree($action);
							wc_os_pree('$products');
							wc_os_pree($products);*/
							
							foreach($products as $product_id){
								
								$product_id_arr = (is_array($product_id)?$product_id:array($product_id));
								
								foreach($product_id_arr as $product_id){
									if($filter=='' || ($filter!='' && $filter==$action)){
										$ret[$product_id] = $action;
									}
								}
							}
						}
					}					
				}
				
			}
			
			return $ret;
			
		}
		
		/*
			START - 
			07 January 2019
			Automatic Settings Added 
		*/
			
		public function split_order_logic($originalorderid = null){
			//pree(':)');exit;
			global $wc_os_settings, $wc_os_pro, $wc_os_debug;
			
			$consider_action_for_all = false;
			$new_order_ids = array();
			$order_id = 0;
			//pree($wc_os_settings['wc_os_ie']);exit;
			//pree($originalorderid.' && '.$_GET['order_id'].' && '.$_GET['split'].' && '.$_GET['_wpnonce']);exit;
			//pree(is_numeric($this->auto_split));
			if($originalorderid==0 && isset($_GET['order_id']) && isset($_GET['split']) && $_GET['split'] == 'init' && isset($_GET['_wpnonce'])){
				$originalorderid = $_GET['order_id'];
				$this->processing = false;								
			}
			$this->auto_split = $wc_os_settings['wc_os_ie'];
			//wc_os_pree($wc_os_settings['wc_os_ie']);exit;
			//wc_os_pree($this->auto_split);exit;
			//$currentUser = wp_get_current_user();
			
			
			
			$split_status = get_post_meta($originalorderid, 'split_status', true);
			$split_lock = (isset($wc_os_settings['wc_os_additional']['split_lock'])?$wc_os_settings['wc_os_additional']['split_lock']:'');
			
			
			//wc_os_pree('split_order_logic-1');
			//wc_os_pree($split_status);exit;
			if($split_status){
				return false;
			}
			
			
			//wc_os_pree('split_order_logic-2');exit;
			//wc_os_pree($originalorderid);
			//wc_os_pree($split_status);exit;
			//wc_os_pree($this->auto_split);
			//exit;
			$original_order = new WC_Order($originalorderid);
			//wc_os_pree($original_order);
			//exit;
			//wc_os_pree($split_lock);
			//wc_os_pree($original_order->has_status($split_lock));
			//wc_os_pree($original_order->get_status());exit;
			
			
			$wc_os_order_statuses = wc_get_order_statuses(); 
			$wc_os_order_statuses_keys = array_keys($wc_os_order_statuses);		
			$wc_os_order_statuses_keys = array_unique($wc_os_order_statuses_keys);			
			$status_lock_released = (!$split_lock || ($split_lock && $original_order->has_status($split_lock)));
			
			if(empty($original_order) || !$status_lock_released){
				return false;
			}
			//wc_os_pree($original_order);exit;
			$user_id = $original_order->get_user_id();
			
			//wc_os_pree($original_order);//exit;
			
			$wc_os_all_products = (isset($wc_os_settings['wc_os_all_product']) && $wc_os_settings['wc_os_all_product']) ? true : false; //flag indicating to all products are subject to splitting
			$wc_os_products = $wc_os_settings['wc_os_products'];
			//pree($wc_os_products);
			$products_with_actions = $this->products_with_actions($this->auto_split);//23/10/2019 > from > $this->products_with_actions();
			//wc_os_pree($products_with_actions);exit;
			
			$wc_order_items = array();
			$wc_order_items_qty = array();
			$this->include_items_qty = array();
			//wc_os_pree('split_order_logic-2.1');exit;
			//pree($original_order->get_items());
			
			if(empty($original_order->get_items())){
				return false;
			}
			
			if(get_option('wc_os_auto_clone', 0)){
				if(!get_post_meta($originalorderid, 'wos_cloned', true)){
					$this->clone_order($originalorderid, true);
				}
				//pree($originalorderid);
			}
			
			foreach($original_order->get_items() as $item_id=>$item_data){
				//wc_os_pree($item_id);
				//wc_os_pree($item_data->get_meta_data());
				//wc_os_pree($item_data);
				$formatted_meta_data = $item_data->get_formatted_meta_data();
				$formatted_meta_data = empty($formatted_meta_data)?$item_data->get_meta_data():$formatted_meta_data;
				//_reduced_stock
				//wc_os_pree($formatted_meta_data);//exit;
				//wc_os_pree($item_meta_data);
				$product_item_id = 0;
				
				if($item_data->get_variation_id()){
					$product_item_id = $item_data->get_variation_id();
				}else{
					$product_item_id = $item_data->get_product_id();
				}
				$wc_order_items[] = $product_item_id;
				
				$wc_order_items_qty[$product_item_id] = $item_data->get_quantity();
				
				//wc_os_pree($wc_order_items_qty);
				
				if(!empty($formatted_meta_data)){
					$formatted_meta_data = current($formatted_meta_data);
					$formatted_meta_data = (array)$formatted_meta_data;
					//wc_os_pree($formatted_meta_data);
					if(!empty($formatted_meta_data) && !array_key_exists('key', $formatted_meta_data)){
						$formatted_meta_data = current($formatted_meta_data);
					}
					//wc_os_pree($formatted_meta_data);	
					if(!empty($formatted_meta_data) && array_key_exists('key', $formatted_meta_data)){
							
						extract($formatted_meta_data);
						$key = strtolower($key);
						//$key = str_replace(array('*data', '*current_data'), 'key', $key);
						//wc_os_pree($key);
						
						switch($key){
							case 'backordered':
							case '_reduced_stock':
								//wc_os_pree($key);
								//wc_os_pree($value);	
								//$wc_order_items_qty[$item_data->get_product_id()] = 
								$this->include_items_qty[$product_item_id] = $value;
							break;							
						}
					
					}
				}
				
				
				//wc_os_pree($item_data->get_product_id());
			}
			
			//wc_os_pree('split_order_logic-2.2');exit;
			//exit;
			if($wc_os_debug)
			wc_os_pree($this->include_items_qty);
			//wc_os_pree($wc_order_items_qty);exit;
			
			//wc_os_pree($wc_os_all_products);exit;
			
			if($wc_os_all_products){
				$wc_order_items_diff = array();
				$wc_order_items_matched = $wc_order_items;
			}else{
				$wc_order_items_diff = array_diff($wc_order_items, array_keys($products_with_actions));
				$wc_order_items_diff = array_filter($wc_order_items_diff);
				
				$wc_order_items_matched = array_intersect(array_keys($products_with_actions), $wc_order_items);
				$wc_order_items_matched = array_filter($wc_order_items_matched);
			}
			//wc_os_pree($wc_os_settings['wc_os_ie']);exit;
			//wc_os_pree($wc_os_products);
			//wc_os_pree($wc_order_items);
			//wc_os_pree($products_with_actions);
			//wc_os_pree($wc_order_items_diff);
			//wc_os_pree($wc_order_items_matched);exit;
			
			
			
			
			
			if(!empty($wc_os_products) && !empty($wc_order_items_diff)){
				//echo ':)';
			}
			
			
			//pree($wc_order_items_matched);exit;
			
			if(!empty($wc_order_items)){
				
				$wos_forced_ie = get_post_meta($originalorderid, 'wos_forced_ie', true);	
				
				//pree($wos_forced_ie);
				//pree($wc_os_settings['wc_os_ie']);
				//pree($wc_os_ie_selected);
				//pree($this->auto_split);exit;
				
				if($this->auto_split=='cats' || $this->auto_split=='group_cats'){			
					$wc_os_ie_selected = $this->auto_split;
				}else{
					//pree($this->auto_split);
					$actions_arr = array();
					if(!empty($wc_order_items_matched)){
						foreach($wc_order_items_matched as $matched_items){					
							$actions_arr[] = $products_with_actions[$matched_items];
						}
					}
					//pree($actions_arr);exit;
					//$actions_arr[] = 'exclusive';
					$actions_arr = array_unique($actions_arr);
					//pree($actions_arr);exit;
					$wc_os_ie_selected = $wc_os_settings['wc_os_ie'];
					//pree($wc_os_ie_selected);
					//echo $expected_orders;
					//wc_os_pree((count($wc_order_items) - count($wc_order_items_matched)));exit;
					if(count($actions_arr)==0){ //BACKWARDS COMPATIBILITY
						$consider_action_for_all = true;
					}elseif(count($actions_arr)==1){ //REGULAR/VALID/NORMAL CASE
						$wc_os_ie_selected = current($actions_arr);
					}elseif(count($actions_arr)>1){ //EXPECTED/INVALID/CONFLICT CASE
						if($wos_forced_ie){
							$wc_os_ie_selected = $wos_forced_ie;
						}else{
							//pree($actions_arr);
							//pree($wc_os_ie_selected);exit;
							switch($wc_os_ie_selected){
								case 'groups':
								break;
								default:
									update_post_meta($originalorderid, 'conflict_status', true);
									update_post_meta($originalorderid, 'split_status', true);
									return;
								break;
							}
						}
					}
					
				}
				
				
				$n_plus_1 = (count($wc_order_items) - count($wc_order_items_matched));
				
				//pree('auto_split: '.$this->auto_split);
				//pree('$wc_os_ie_selected: '.$wc_os_ie_selected);exit;
				

				if($this->auto_split){
					switch($wc_os_ie_selected){ //06/05/2019
						default:
						case 'default':
							//wc_os_pree($order_id);
							//
						break;	
						case 'exclusive':
						
							//wc_os_pree('exclusive1');
							
							if($n_plus_1){
								
								$this->exclude_items = array();
								$this->include_items = array();
								
								foreach($wc_order_items_matched as $item){
									$this->exclude_items[] = $item;
								}
								
								//wc_os_pree($this->exclude_items);//exit;
								
								$order_data =  array(
									'post_type'     => 'shop_order',
									'post_status'   => 'publish',
									'ping_status'   => 'closed',
									'post_author'   => $user_id,
									'post_password' => uniqid( 'order_' ),
								);
							
								$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id, 'testing_position', 'exclusive2');
								//wc_os_pree($order_data);exit;
								
								//wc_os_pree('order_id:'.$order_id);
						
								if ( is_wp_error( $order_id ) ) {									
									
									
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'clone__error'));
									
									
									
								} else {
									$this->cloned_order_data($order_id, $originalorderid);	
									
									update_post_meta($order_id, 'split_status', true);
									
									$new_order_ids[] = $order_id;
								}	
								
							}else{
								//wc_os_pree('exclusive2');
							}
							
							
							
							$this->exclude_items = array();
							
							//wc_os_pree($wc_order_items_matched);
							
							if(!empty($wc_order_items_matched)){
								foreach($wc_order_items_matched as $item){
									
									//wc_os_pree($item);
									
									$this->include_items = array();
									
									$this->include_items[] = $item;
									
									//wc_os_pree($this->include_items);//
									
									$order_data =  array(
										'post_type'     => 'shop_order',
										'post_status'   => 'publish',
										'ping_status'   => 'closed',
										'post_author'   => $user_id,
										'post_password' => uniqid( 'order_' ),
									);
								
									$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
									//update_post_meta($order_id, 'testing_position', 'exclusive');
									//wc_os_pree('order_id:'.$order_id);
							
									if ( is_wp_error( $order_id ) ) {
										
										if(!$this->cron_in_progress)
										add_action( 'admin_notices', array($this, 'clone__error'));
									} else {
										$this->cloned_order_data($order_id, $originalorderid);		
										
										update_post_meta($order_id, 'split_status', true);
										
										$new_order_ids[] = $order_id;
									}	
																	
								}
							}else{
								//wc_os_pree('exclusive3');
							}
							
							//wc_os_pree('exclusive4');
							//wc_os_pree($this->include_items);exit;
							
						break;	
						case 'inclusive':
							//wc_os_pree('inclusive');exit;
							
							if($n_plus_1){
								
								$this->exclude_items = array();
								$this->include_items = array();
								
								foreach($wc_order_items_matched as $item){
									$this->exclude_items[] = $item;
								}
							
								$order_data =  array(
									'post_type'     => 'shop_order',
									'post_status'   => 'publish',
									'ping_status'   => 'closed',
									'post_author'   => $user_id,
									'post_password' => uniqid( 'order_' ),
								);
							
								$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id, 'testing_position', 'inclusive2');
								//wc_os_pree('inclusive/order_id'. $order_id);exit;
						
								if ( is_wp_error( $order_id ) ) {
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'clone__error'));
								} else {
									$this->cloned_order_data($order_id, $originalorderid);		
									
									update_post_meta($order_id, 'split_status', true);
									
									$new_order_ids[] = $order_id;
								}	
								
							}
							
							$this->exclude_items = array();
							$this->include_items = array();
							
							if(!empty($wc_order_items_matched)){
								
								foreach($wc_order_items_matched as $item){
									
									$this->include_items[] = $item;
									
								}
									
								$order_data =  array(
									'post_type'     => 'shop_order',
									'post_status'   => 'publish',
									'ping_status'   => 'closed',
									'post_author'   => $user_id,
									'post_password' => uniqid( 'order_' ),
								);
							
								$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id, 'testing_position', 'inclusive');
								//wc_os_pree('inclusive/order_id'. $order_id);
						
								if ( is_wp_error( $order_id ) ) {
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'clone__error'));
								} else {
									$this->cloned_order_data($order_id, $originalorderid);		
									
									update_post_meta($order_id, 'split_status', true);
									
									$new_order_ids[] = $order_id;
									
								}	
							}
							//exit;
							
						break;	
						
						
						case 'shredder':

							if($n_plus_1){
								
								$this->exclude_items = array();
								$this->include_items = array();
								
								foreach($wc_order_items_diff as $item){
									$this->exclude_items[] = $item;
								}
								
								//wc_os_pree($this->exclude_items);//exit;
								
								$order_data =  array(
									'post_type'     => 'shop_order',
									'post_status'   => 'publish',
									'ping_status'   => 'closed',
									'post_author'   => $user_id,
									'post_password' => uniqid( 'order_' ),
								);
							
								$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id, 'testing_position', 'shredder2');
								//wc_os_pree('order_id:'.$order_id);
						
								if ( is_wp_error( $order_id ) ) {									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'clone__error'));
								} else {
									$this->cloned_order_data($order_id, $originalorderid);	
									
									update_post_meta($order_id, 'split_status', true);
									
									$new_order_ids[] = $order_id;	
								}	
								
							}
							
							
							
							$this->exclude_items = array();
							
							//wc_os_pree($wc_order_items_matched);
							
							foreach($wc_order_items_diff as $item){
								
								//wc_os_pree($item);
								
								$this->include_items = array();
								
								$this->include_items[] = $item;
								
								//wc_os_pree($this->include_items);//
								
								$order_data =  array(
									'post_type'     => 'shop_order',
									'post_status'   => 'publish',
									'ping_status'   => 'closed',
									'post_author'   => $user_id,
									'post_password' => uniqid( 'order_' ),
								);
							
								$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id, 'testing_position', 'shredder');
								//wc_os_pree('order_id:'.$order_id);
						
								if ( is_wp_error( $order_id ) ) {
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'clone__error'));
								} else {
									$this->cloned_order_data($order_id, $originalorderid);		
									
									update_post_meta($order_id, 'split_status', true);
									
									$new_order_ids[] = $order_id;
								}	
																
							}
															
						
							
						break;		
						
						
						case 'io':
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
								
								//pree($wc_order_items);
								$items_io = $classObj->separate_io_items($wc_order_items, $this->include_items_qty);
								
								//pree($items_io);exit;
								
								$this->exclude_items = array();
								$this->include_items = array();
								$backorder_only = array();
								
								$save_quantity = $this->include_items_qty;
														
								if($items_io['in_stock'] && !empty($items_io['in_stock'])){ //create order of in-stock items
									
									//set items to include in order
									$this->include_items = $items_io['in_stock']['items'];
									
									//set quantities for items
									$this->include_items_qty = $items_io['in_stock']['quantity'];
									
									//pree($this->include_items);pree($this->include_items_qty);exit;
									$classObj->wos_update_order_item($originalorderid, $this->include_items, $this->include_items_qty);
									
									
									
									if(isset($items_io['backorder'])){
										$backorder_items = (isset($items_io['backorder']['items'])?$items_io['backorder']['items']:array());
										$backorder_only = array_diff($backorder_items, $this->include_items);
									}

									
								}
				
								if($items_io['backorder'] && !empty($items_io['backorder'])) //create order of backorder items
								{
									if($items_io['backorder_split_required']){
										//set items to include in order
										$this->include_items = $items_io['backorder']['items'];
										
										//set quantities for items
										$this->include_items_qty = $items_io['backorder']['quantity'];
										
										//pree($this->include_items);pree($this->include_items_qty);exit;
										
										//create post order data
										$order_data =  array(
											'post_type'     => 'shop_order',
											'post_status'   => 'publish',
											'ping_status'   => 'closed',
											'post_author'   => $user_id,
											'post_password' => uniqid( 'order_' ),
										);
										
										//save order to database
										if(!$wc_os_debug)
										$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
										//update_post_meta($order_id, 'testing_position', 'io+backorder');
										
										if ( is_wp_error( $order_id ) ) {
										
											if(!$this->cron_in_progress)
											add_action( 'admin_notices', array($this, 'clone__error'));
										} else { //add data to new post
											if(!$wc_os_debug) //save order
											$this->cloned_order_data($order_id, $originalorderid);
											
											update_post_meta($order_id, 'split_status', true);
											update_post_meta($order_id, '_wos_out_of_stock', true);
											
											$new_order_ids[] = $order_id;
											
											$outofstock_order = wc_get_order( $order_id );
											$outofstock_order->update_status('on-hold');
										}
									}else{
										update_post_meta($originalorderid, '_wos_out_of_stock', true);
										$original_order->update_status('on-hold');
									}
								}
				
								//restore saved quantity
								$this->include_items_qty = $save_quantity;								
								

								if(!empty($backorder_only)){
									$classObj->wos_delete_order_item($originalorderid, $backorder_only);
								}
								update_post_meta($originalorderid, '_wos_calculate_totals', true);
							
							
							}
						break;	
						
						case 'quantity_split':
							//return;
							//pree($originalorderid);
							//pree($consider_action_for_all);
							//exit;
							if(!$wc_os_pro){ return; }
							//wc_os_pree('quantity_split');exit;
							//pree(count($original_order->get_items()));
							//pree($wc_order_items_matched);exit;
							$qty_split_option = (($consider_action_for_all && in_array($wc_os_settings['wc_os_qty_split_option'], array('custom', 'default')))?'custom':$wc_os_settings['wc_os_qty_split_option']);//$consider_action_for_all < 23/10/2019
							//pree($qty_split_option);exit;
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
											
								//pree($wc_order_items_matched);exit;
								$qty_split_group = array('parent_group'=>array(), 'child_group'=>array());
								
								foreach($original_order->get_items() as $item_key=>$item_values){
									//pree($item_key);
									
									$order_id_new = 0;
									if($item_values->get_product_id() && (in_array($item_values->get_product_id(), $wc_order_items_matched) || $consider_action_for_all)){ //$consider_action_for_all < 23/10/2019
										
										$qty = $item_values->get_quantity();
										$qty_split_arr = $classObj->get_qty_split_arr($qty_split_option, $item_key, $qty);
									
										$item = $item_values->get_data();
										$product_id = $item['product_id'];
										$variation_id = $item['variation_id'];
										
										if ($variation_id != 0) {
											$product = new WC_Product_Variation($variation_id);
							
										} else {
											$product = new WC_Product($product_id);	
										}			
										
										
										if($item_values['total']==$product->get_price()){
											$unit_price = $product->get_price();
										}else{
											$unit_price = ($item_values['total']/$qty); //06 March 2019 - with Sean Owen
										}
													
										$order_data =  array(
											'post_type'     => 'shop_order',
											'post_status'   => 'publish',
											'ping_status'   => 'closed',
											'post_author'   => $user_id,
											'post_password' => uniqid( 'order_' ),
										);
										
										
										$wc_pos_order_type = get_post_meta($originalorderid, 'wc_pos_order_type', true);
										$wc_pos_order_type = ($wc_pos_order_type?$wc_pos_order_type:'online');
										
										//pree($qty_split_option);exit;
										if($qty_split_option=='eric_logic'){
											//pree($product->get_id());
											if(empty($qty_split_arr)){
												$qty_split_group['parent_group'][$product_id] = array('qty'=>array($qty), 'item_key'=>$item_key,  'item_values'=>$item_values, 'product'=>$product);
											}else{
												
												if(count($qty_split_arr)==1){
													$qty_split_group['child_group'][$product_id] = array('qty'=>$qty_split_arr, 'item_key'=>$item_key,  'item_values'=>$item_values, 'product'=>$product);
													$remaining = ($qty - array_sum($qty_split_arr));
													if($remaining>0){
														$qty_split_group['parent_group'][$product_id] = array('qty'=>array($remaining), 'item_key'=>$item_key,  'item_values'=>$item_values, 'product'=>$product);
													}
												}elseif(count($qty_split_arr)>1){
													$iter = 0;
													foreach($qty_split_arr as $split_figure){ $iter++;
														//pree($product_id.' - '.$qty.' - '.$split_figure);
														if($iter==1){
															$qty_split_group['parent_group'][$product_id] = array('qty'=>array($split_figure), 'item_key'=>$item_key,  'item_values'=>$item_values, 'product'=>$product);
														}else{
															$qty_split_group['child_group'][$product_id] = array('qty'=>array($split_figure), 'item_key'=>$item_key,  'item_values'=>$item_values, 'product'=>$product);
														}
													}	
												}
												
												
											}
											
										}else{
											
											//pree($qty);pree($original_order->get_items());pree(count($original_order->get_items()));exit;
											
											if($qty<=1 && count($original_order->get_items())==1){ //22/08/2019 - Added this condition while talking to Paul Rodarte 
												continue;
											}
											
											
											//pree($qty_split_arr);exit;
											
											//continue;
											
											
											
											
											
											
											
											if(!empty($qty_split_arr)){
												//pree($qty_split_arr);exit;
												foreach($qty_split_arr as $qty_split){
													
													//if($qty_split>0){ 
														$order_id_new = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
														//update_post_meta($order_id_new, 'testing_position', 'qty_split+qty_split_arr');
														//pree($order_id_new.' - '.$qty_split);
														update_post_meta($order_id_new, 'wc_pos_order_type', sanitize_wc_os_data($wc_pos_order_type)); // NO QTY. SPLIT
														update_post_meta($order_id_new, 'qty_splitted', true);
												
														if ( is_wp_error( $order_id_new ) ) {
															
															if(!$this->cron_in_progress)
															add_action( 'admin_notices', array($this, 'split__error'));
														} else {
															//wc_os_pree($unit_price);
															//wc_os_pree('quantity_split1');exit;
															$this->splitted_order_data($order_id_new, $originalorderid, $product_id, $variation_id, $qty_split, $unit_price);		
															
															
															$valid_process = true;
															
															if(method_exists($this, 'ywpo_add_order_item_meta')){
																$this->ywpo_add_order_item_meta($item_key, $product);
															}
														}
														
													//}
												}
											}else{
												
													switch($qty_split_option){
														case 'custom':
																
																$order_id_new = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
																//update_post_meta($order_id, 'testing_position', 'qty_split+custom');
																
																update_post_meta($order_id_new, 'wc_pos_order_type', sanitize_wc_os_data($wc_pos_order_type)); // NO QTY. SPLIT
																update_post_meta($order_id_new, 'qty_splitted', true);
														
																if ( is_wp_error( $order_id_new ) ) {
																	
																	if(!$this->cron_in_progress)
																	add_action( 'admin_notices', array($this, 'split__error'));
																} else {
																	//wc_os_pree($unit_price);
																	//wc_os_pree('quantity_split2');exit;
																	$this->splitted_order_data($order_id_new, $originalorderid, $product_id, $variation_id, $qty, $unit_price);		
																	
																	
																	$valid_process = true;
																	
																	if(method_exists($this, 'ywpo_add_order_item_meta')){
																		$this->ywpo_add_order_item_meta($item_key, $product);
																	}
																}		
																
																//pree($order_id_new.' - '.$qty);	
	
														
														break;
														case 'eric_logic':
															//pree($wc_order_items);exit;
															//
														break;
														default:
															//pree($qty);
															
															for($q=1; $q<=$qty; $q++){
																
																$order_id_new = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
																//update_post_meta($order_id, 'testing_position', 'qty_split+default');
																//pree($order_id_new);
																
																update_post_meta($order_id_new, 'wc_pos_order_type', sanitize_wc_os_data($wc_pos_order_type)); // YES QTY. SPLIT
																update_post_meta($order_id_new, 'qty_splitted', true);
														
																if ( is_wp_error( $order_id_new ) ) {
																	
																	if(!$this->cron_in_progress)
																	add_action( 'admin_notices', array($this, 'split__error'));
																} else {
																	//wc_os_pree($unit_price);
																	//wc_os_pree('quantity_split2');exit;
																	$this->splitted_order_data($order_id_new, $originalorderid, $product_id, $variation_id, 1, $unit_price);		
																	
																	
																	$valid_process = true;
																	
																	if(method_exists($this, 'ywpo_add_order_item_meta')){
																		$this->ywpo_add_order_item_meta($item_key, $product);
																	}
																}	
																
																//pree($order_id_new.' - 1');			
																				
															}
															
													}
												
											}
											
										}
										
										
										if($order_id_new){										
											$new_order_ids[] = $order_id_new;
											
											$classObj->wos_delete_order_item($originalorderid, array($item_values->get_product_id())); //REMOVING SPLITTED ITEMS FROM ORIGINAL ORDER 19/10/2019
											$order_data_updated = wc_get_order( $originalorderid );
											$order_data_updated->calculate_totals();
											delete_post_meta($order_id_new, 'wc_os_order_splitter_cron'); //in case this meta_key was inherited from parent order
											update_post_meta($order_id_new, 'split_status', true); //23/10/2109 so no further split
											
										}
									}
								}
								
								if(!empty($qty_split_group)){
									//pree($qty_split_group);exit;
									
									$parent_group = $qty_split_group['parent_group'];
									
									if(!empty($parent_group)){
										
										//MOVED INSIDE CONDITION ON BUG REPORTED BY "ryonwhyte" ON 22/11/2019
										$new_order_ids = $classObj->split_order_by_qty_split_groups($qty_split_group, $originalorderid, $order_data);
										
										$modify_original_order = wc_get_order($originalorderid);
										foreach($modify_original_order->get_items() as $cart_item_key=>$cart_item_data){
											//pree($cart_item_data['product_id']);
											if(array_key_exists($cart_item_data['product_id'], $parent_group)){
												$group_item_data = $parent_group[$cart_item_data['product_id']];
												$product = $group_item_data['product'];
												//pree($group_item_data);
												$cart_item_data['quantity'] = array_sum($group_item_data['qty']);
												$unit_price = $product->get_price();
												$cart_item_data['subtotal'] = $unit_price*$cart_item_data['quantity'];
												$cart_item_data['total'] = $cart_item_data['subtotal'];
												
												//pree($cart_item_data['quantity']);
												$modify_original_order->save();
											}
										}
									}
									
								}
								
								//pree($qty_split_group);
								//exit;
								$order_data_check = wc_get_order( $originalorderid );
								if(count($order_data_check->get_items())<1){
									wos_clone_order_notes($originalorderid, $new_order_ids);
									wp_delete_post($originalorderid);
								}
							}
							//exit;
							
				
							
						break;											
						case 'cats':			
						
							if(!$wc_os_pro){ return; }
							
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
								
								$wos_forced_ie = get_post_meta($originalorderid, 'wos_forced_ie', true);
								$wos_delete_order = get_post_meta($originalorderid, 'wos_delete_order', true);
								
								if($wos_forced_ie && $wos_delete_order){
									//pree($originalorderid);
									//pree($wc_os_ie_selected);
									//wc_os_pree($this->auto_split);//exit;
									//wc_os_pree($wc_os_settings['wc_os_ie']);
									$wc_os_ie_selected = $wos_forced_ie;
									//delete_post_meta($originalorderid, 'wos_forced_ie');
									//pree($wc_os_ie_selected);exit;
									//pree($n_plus_1);
									
									$new_order_ids = $classObj->split_order_by_category($wos_forced_ie, $wc_order_items, $originalorderid, $user_id);
									
									if(!empty($new_order_ids)){
										$original_cloned_from = get_post_meta($originalorderid, 'cloned_from', true);
										$original_splitted_from = get_post_meta($originalorderid, 'splitted_from', true);
										foreach($new_order_ids as $new_ordder_id){
											update_post_meta($new_ordder_id, 'cloned_from', $original_cloned_from);
											update_post_meta($new_ordder_id, 'splitted_from', $original_splitted_from);
											delete_post_meta($new_ordder_id, 'wos_delete_order');
											delete_post_meta($new_ordder_id, 'wos_forced_ie');
										}
										//delete_post_meta($originalorderid, 'wos_delete_order');								
										//wp_trash_post($originalorderid);
										$originalorderid = $original_cloned_from;
									}
									
	
									
								}else{			
								
									$wc_os_cats = $wc_os_settings['wc_os_cats'];
									$wc_os_cats_arr = array();
									foreach($wc_os_cats as $item_group=>$cat_items){								
										foreach($cat_items as $cat_item){
											$wc_os_cats_arr[$cat_item] = $item_group;
										}
									} 
									//pree($wc_os_cats_arr);
								
									$category_arr = array();
									foreach($wc_order_items as $item){
										
										$product_cats = get_the_terms ( $item, 'product_cat' );								
										foreach($product_cats as $product_cat){
											$category_arr[$product_cat->term_id][] = $item;
										}
									}
									
									
									
									if(!empty($category_arr)){
										foreach($category_arr as $cat_group=>$items_arr){
											
											$order_split_action = (array_key_exists($cat_group, $wc_os_cats_arr)?$wc_os_cats_arr[$cat_group]:'');
											
											$this->exclude_items = array();
											$this->include_items = array();									
											foreach($items_arr as $item_id){
												$this->include_items[] = $item_id;
											}		
											//pree($this->include_items);
											$order_data =  array(
												'post_type'     => 'shop_order',
												'post_status'   => 'publish',
												'ping_status'   => 'closed',
												'post_author'   => $user_id,
												'post_password' => uniqid( 'order_' ),
											);
											//pree($this->include_items);//exit;
											
											$order_id = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
											//update_post_meta($order_id, 'testing_position', 'cats');
											//wc_os_pree('inclusive/order_id'. $order_id);
									
											if ( is_wp_error( $order_id ) ) {
												
												if(!$this->cron_in_progress)
												add_action( 'admin_notices', array($this, 'clone__error'));
											} else {
												$this->cloned_order_data($order_id, $originalorderid);		
												
												if($order_split_action && count($this->include_items)>1){
													update_post_meta($order_id, 'wos_forced_ie', $order_split_action);
													update_post_meta($order_id, 'wos_delete_order', true);
													//update_post_meta($order_id, 'conflict_status', true);											
													update_post_meta($order_id, 'wc_os_order_splitter_cron', true);
												}else{
													update_post_meta($order_id, 'split_status', true);
												}
												
												
												$new_order_ids[] = $order_id;
												
											}	
										}
									}
									
								}
								
							}
							//exit;
						break;
						case 'groups':
							//pree('GROUPS');exit;
							if(!$wc_os_pro){ return; }
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
								//pree($wc_order_items);exit;
								if(count($wc_order_items)>1){
									$new_order_ids = $classObj->split_order_by_groups($wc_order_items, $originalorderid, $user_id);
									$order_data_check = wc_get_order($originalorderid);			
									//pree(($order_data_check->get_items()));exit;
									if(count($order_data_check->get_items())<1){
										wos_clone_order_notes($originalorderid, $new_order_ids);
										wp_delete_post($originalorderid);
									}
								}
								
							}
							//exit;
							
						break;	
						case 'group_cats':
							
							if(!$wc_os_pro){ return; }
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
							
								$new_order_ids = $classObj->split_order_by_group_cats($wc_order_items, $originalorderid, $user_id);
							}
							
						break;	
						case 'group_by_vendors':
						
							if(!$wc_os_pro){ return; }
							
							if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')){
								
								$classObj = new wc_os_bulk_order_splitter;
								
								$new_order_ids = $classObj->split_order_by_vendor_groups($wc_order_items, $originalorderid, $user_id);
								
							}
							
						break;					
					}		
				}				
				


				update_post_meta($originalorderid, 'split_status', true);
				
				if(!empty($new_order_ids)){
					wos_clone_order_notes($originalorderid, $new_order_ids);
					wos_email_notification(array('new'=>$new_order_ids, 'original'=>$originalorderid), 'split');
				}
				
				//if($order_id){
				if(!empty($new_order_ids)){
					
					//pree($new_order_ids);
					
					foreach($new_order_ids as $order_id){
						$_customer_user_agent = get_post_meta($originalorderid, '_customer_user_agent', true);
						update_post_meta($order_id, 'splitted_from', $originalorderid);
						
						//pree($order_id.', splitted_from, '.$originalorderid);
						
						if($_customer_user_agent)
						update_post_meta( $order_id, '_customer_user_agent',  $_customer_user_agent);
					}
					//exit;
				}
					
				//}

			}else{
				
				//06 March 2019 - with Sean Owen
				$split_qty = wc_os_order_qty_split();
				
				if($split_qty){
					$this->split_order($originalorderid, $wc_os_products);
					
					update_post_meta($originalorderid, 'split_status', true);
				//wc_os_pree('split_order_logic-3');
				}
			}
			
			
			//exit;
			
			
			delete_post_meta($originalorderid, 'wc_os_order_splitter_cron');
			update_post_meta($originalorderid, '_wos_calculate_totals', true);
			
			
			return true;
		}		
		
		
		/*
			- END
			07 January 2019
			Automatic Settings Added 
		*/			
			
		
	  
		public function split_order($originalorderid = null, $wc_os_products=array()){
			//$originalorderid = 2453;
			//return;
			//wc_os_pree($_POST);exit;
			//wc_os_pree($originalorderid);
			//wc_os_pree(wc_os_order_split());exit;
			if(!wc_os_order_split())
			return;
			
			$new_order_ids = array();	
			$proceed = true;
			$wc_os_all_products = (isset($wc_os_settings['wc_os_all_product']) && $wc_os_settings['wc_os_all_product']) ? true : false; //flag indicating to all products are subject to splitting
			
			//wc_os_pree($originalorderid);exit;
			
			if($originalorderid==0){
				$originalorderid = $_GET['order_id'];
				$this->processing = false;
			}
			
			
			//wc_os_pree($originalorderid);exit;
			
			if($originalorderid>0){
				$order_data = wc_get_order( $originalorderid );
				//pree($order_data);exit;
				if(empty($order_data))
				return;
				
				
				
				$split_qty = wc_os_order_qty_split();
				//wc_os_pree($split_qty);exit;
				
				
				$user_id = get_post_meta($originalorderid, '_customer_user', true);
				//pree($user_id);
				$split_status = get_post_meta($originalorderid, 'split_status', true);
				$qty_splitted = get_post_meta($originalorderid, 'qty_splitted', true);
				
				//wc_os_pree($split_status);
				//wc_os_pree($qty_splitted);exit;
				
				$qty_split_check = ($split_qty && !$qty_splitted);//true;
				
				//wc_os_pree($order_data->get_item_count());exit;
				//wc_os_pree(count($order_data->get_items()));
				//wc_os_pree($split_status);exit;
				//wc_os_pree(count($order_data->get_items()));exit;
				$multiple_items_check = (count($order_data->get_items())>1 && !$split_status);
				
				
				
					
				
				//wc_os_pree($qty_split_check);
				//wc_os_pree($multiple_items_check);exit;
				
				if($qty_split_check || $multiple_items_check){
					
				}else{
					//$order_qty = 0;
					//foreach ($order_data->get_items() as $item_id => $item_data) {
					//	$order_qty += $item_data->get_quantity();
					//}
					//wc_os_pree($order_qty);exit;
					//if($order_qty<=1){
						return;
					//}else{
						//$qty_split_check = true;
					//}
				}
				
				
				//wc_os_pree($_POST['wc_os_ps']);
				//wc_os_pree($order_data->get_items());exit;		
				if($wc_os_all_products);
		        else{
					foreach( $order_data->get_items() as $item_key => $item_values ){
						
						if(!$proceed)
						continue;
						
						if($this->processing){
							if(in_array($item_values->get_product_id(), $wc_os_products)){
							}else{
								$proceed = false;
							}
						}				
					}
				}
				
				$valid_process = false;
				
				//pree($_POST['wc_os_ps']);exit;
				//wc_os_pree($order_data->get_items());exit;
								
				foreach( $order_data->get_items() as $item_key => $item_values ){
					

					if($item_values->get_product_id() && (empty($_POST['wc_os_ps']) || (!empty($_POST['wc_os_ps']) && in_array($item_key, $_POST['wc_os_ps'])))){
						//pree($item_values->get_product_id());					
						//pree($item_values->get_quantity());
						
						$qty = $item_values->get_quantity();
						
						$qty_check = ($qty_split_check && $qty>1);
						
						
						//wc_os_pree(($multiple_items_check || $qty_check));exit;
						
						if($multiple_items_check || $qty_check){
						}else{
							continue;
						}
						
						//wc_os_pree('$multiple_items_check || '.$multiple_items_check);
						//wc_os_pree('$qty_check || '.$qty_check);
						//exit;
						
						
						$item = $item_values->get_data();
						$product_id = $item['product_id'];
						$variation_id = $item['variation_id'];
						//pree($item);exit;

						
						if ($variation_id != 0) {
							$product = new WC_Product_Variation($variation_id);
			
						} else {
							$product = new WC_Product($product_id);	
						}			
						//wc_os_pree($product->get_price());exit;
						//wc_os_pree('$item_values[\'total\']==$product->get_price()');
						//wc_os_pree($item_values['total'].' == '.$product->get_price());
						//exit;
						if($item_values['total']==$product->get_price()){
							$unit_price = $product->get_price();
						}else{
							$unit_price = ($item_values['total']/$qty); //06 March 2019 - with Sean Owen
						}
						//wc_os_pree($unit_price);exit;
						
									
						$order_data =  array(
							'post_type'     => 'shop_order',
							'post_status'   => 'publish',
							'ping_status'   => 'closed',
							'post_author'   => $user_id,
							'post_password' => uniqid( 'order_' ),
						);
						
						
						$wc_pos_order_type = get_post_meta($originalorderid, 'wc_pos_order_type', true);
						$wc_pos_order_type = ($wc_pos_order_type?$wc_pos_order_type:'online');
						
						
						if($qty_check){
							
							//wc_os_pree('split_order/order_id');wc_os_pree($qty);exit;
							
							for($q=1; $q<=$qty; $q++){
								$order_id_new = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id_new, 'testing_position', 'split_order');
								//wc_os_pree('split_order/order_id'. $order_id);exit;
								
								update_post_meta($order_id_new, 'wc_pos_order_type', sanitize_wc_os_data($wc_pos_order_type)); // NO QTY. SPLIT
								update_post_meta($order_id_new, 'qty_splitted', true);
						
								if ( is_wp_error( $order_id_new ) ) {
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'split__error'));
								} else {
									//wc_os_pree($unit_price);
									//wc_os_pree('split_order1');exit;
									$this->splitted_order_data($order_id_new, $originalorderid, $product_id, $variation_id, 1, $unit_price);		
									
									
									$valid_process = true;
									
									if(method_exists($this, 'ywpo_add_order_item_meta')){
										$this->ywpo_add_order_item_meta($item_key, $product);
									}
								}			
												
							}
							
						}elseif($multiple_items_check && $qty){
							
							
								$order_id_new = wp_insert_post( apply_filters( 'woocommerce_new_order_data', $order_data), true );
								//update_post_meta($order_id_new, 'testing_position', 'multiple_items_check');
								//wc_os_pree('split_order/multiple_items_check/order_id'. $order_id);
								
								update_post_meta($order_id_new, 'wc_pos_order_type', sanitize_wc_os_data($wc_pos_order_type)); // NO QTY. SPLIT
								if ( is_wp_error( $order_id_new ) ) {
									
									if(!$this->cron_in_progress)
									add_action( 'admin_notices', array($this, 'split__error'));
								} else {
									//wc_os_pree('split_order2');exit;
									$this->splitted_order_data($order_id_new, $originalorderid, $product_id, $variation_id, $qty, $unit_price);
									
									$valid_process = true;
									
									update_post_meta($order_id_new, 'split_status', true);
									
									
									
									if(method_exists($this, 'ywpo_add_order_item_meta')){
										$this->ywpo_add_order_item_meta($item_key, $product);
									}


								}	
								
								global $yith_pre_order;							
								
								if($yith_pre_order && function_exists('wos_update_orders_again'))				
								wos_update_orders_again($order_id_new, $originalorderid);
						}else{
							
						}
					
						$new_order_ids[] = $order_id_new;
						
						
						
						
											
					}
				}
				
				//exit;
				if($valid_process){
					
					//wc_os_pree($originalorderid);exit;
					delete_post_meta($originalorderid, 'wc_os_order_splitter_cron');
					
					if(wc_os_order_removal() && empty($_POST['wc_os_ps'])){
						//wc_os_pree($multiple_items_check);
						//wc_os_pree($originalorderid);
						//exit;
						//pree($order_id.' removed through split order');//exit;
						wp_trash_post($originalorderid);
					}else{
						update_post_meta($originalorderid, 'split_status', true);
						if(!empty($new_order_ids)){
							wos_email_notification(array('new'=>$new_order_ids, 'original'=>$originalorderid), 'split');
						}
					}
					
					if(is_admin() && !$this->cron_in_progress){
						wp_redirect('edit.php?post_type=shop_order');exit;
					}
				}
				
			}
			
			//return true;
		}	
		/**
		 * Create new WC_Order and clone all exisiting data
		 */
		
		public function cloned_order_data($order_id, $originalorderid = null, $clone_order=true, $reduce_stock=false, $clone_shipping=true){
			
			
			
			global $yith_pre_order, $wc_os_debug;
			$order = new WC_Order($order_id);
		
			$originalorderids = (is_array($originalorderid)?$originalorderid:array($originalorderid));
			
			
			//pree($originalorderids);exit;
			foreach( $originalorderids as $originalorderid ) {
			
				
				
				if ($originalorderid != null) {
					$this->original_order_id = $originalorderid;
				} else {
					$this->original_order_id = $_GET['order_id'];
				}
				
				
				if(!$wc_os_debug){
					
					$this->wos_update_post_meta($order_id, 'cloned_from', $this->original_order_id);
					if(!$this->clone_in_progress)				
					$this->wos_update_post_meta($order_id, 'splitted_from', $this->original_order_id);
				}
				//pree($this->original_order_id);exit;
				$original_order = new WC_Order($this->original_order_id);
				
				$original_order->add_order_note(__('Child Order').' #'.$order_id.'');
				
				$order_status = $original_order->get_status();
				
				// Check if Sequential Numbering is installed
				
				if ( class_exists( 'WC_Seq_Order_Number_Pro' ) ) {
					
					// Set sequential order number 
					
					$setnumber = new WC_Seq_Order_Number_Pro;
					$setnumber->set_sequential_order_number($order_id);
					
				}
				
				if(!$wc_os_debug){
				
					$this->clone_order_header($order_id);
					$this->clone_order_billing($order_id);
					
					if($clone_shipping)
					$this->clone_order_shipping($order_id);
					
					$this->clone_order_shipping_items($order_id, $original_order);
					$this->clone_order_fees($order, $original_order);
					
					$this->clone_order_coupons($order, $original_order);
				
				}
				
				add_filter( 'woocommerce_can_reduce_order_stock','wos_filter_woocommerce_can_reduce_order_stock', 10, 2 );
				
				if($clone_order){
					$this->clone_order_items($order, $original_order);//pree('clone_order_items');
				}elseif(method_exists($this, 'add_order_items')){
					$this->add_order_items($order);//pree('add_order_items');
				}
//				exit;
				
				if(!$wc_os_debug){
					$this->wos_update_post_meta( $order_id, '_payment_method', get_post_meta($this->original_order_id, '_payment_method', true) );
					$this->wos_update_post_meta( $order_id, '_payment_method_title', get_post_meta($this->original_order_id, '_payment_method_title', true) );
				}
				
				// Reduce Order Stock
				//if($reduce_stock)
				//wc_reduce_stock_levels($order_id);
				
				// POSSIBLE CHANGE? - Set status to on hold as payment is not received		
				if(!$wc_os_debug){
					$order->update_status($order_status); //('on-hold');
					$order->calculate_totals();
				}
				// Set order note of original cloned order
	
				
				if(function_exists('wos_update_orders_again')){
					if($yith_pre_order){
						wos_update_orders_again($order_id, $this->original_order_id);
					}else{
						wos_clone_order_notes($this->original_order_id, $order_id);
					}
				}
	
				
				$this->meta_keys_clone_from_to($order_id, $this->original_order_id);//exit;
				
				$order->add_order_note(__('Parent Order').' #'.$this->original_order_id.'');
				
				// Returns success message on clone completion
				if(!$this->cron_in_progress)
				add_action( 'admin_notices', array($this, 'clone__success'));
				//wp_redirect('edit.php?post_type=shop_order');exit;
			
			}
		}
		
		public function wos_update_post_meta($post_id, $key, $val){
			if(is_array(get_post_custom_keys($post_id)) && !in_array($key, get_post_custom_keys($post_id))){
				update_post_meta($post_id, $key, $val);
			}
		}
		
		
		public function meta_keys_clone_from_to($order_id_to=0, $order_id_from=0){
			if($order_id_from && $order_id_to){
				$order_id_to_meta = get_post_meta($order_id_to);
				$order_id_to_keys = array_keys($order_id_to_meta);
				
				$order_id_from_meta = get_post_meta($order_id_from);
				//$order_id_from_meta['wpml_language'] = array('de');
				$order_id_from_keys = array_keys($order_id_from_meta);
				
				
				
				//wc_os_pree($order_id_to_keys);
				//wc_os_pree($order_id_from_keys);
				
				$arr_diff = array_diff($order_id_from_keys, $order_id_to_keys);
				//wc_os_pree($arr_diff);
				
				if(!empty($arr_diff)){
					foreach($arr_diff as $diff_key){
						//wc_os_pree($order_id_from_meta[$diff_key]);
						if(array_key_exists($diff_key, $order_id_from_meta)){
							$diff_value = current($order_id_from_meta[$diff_key]);
							if(!in_array($diff_key, array('wc_os_order_splitter_cron', 'wos_update_status')))
							update_post_meta($order_id_to, $diff_key, $diff_value);
						}
					}
				}
				
				$original_order = wc_get_order($order_id_from);
				$new_order = wc_get_order($order_id_to);
				
				$old_order_items = array();
				foreach($original_order->get_items() as $item_id=>$item_data){
					//$item_meta = wc_get_order_item_meta($item_id);
					$item_meta = $this->wc_os_get_order_item_meta($item_id);
					
					
					$pid = $item_data->get_product_id();
					$vid = $item_data->get_variation_id();	
					
					$old_order_items[$pid][$vid] = $item_meta;
										
					
				}

				
				$new_order_items = array();
				foreach($new_order->get_items() as $item_id=>$item_data){
					$pid = $item_data->get_product_id();
					$vid = $item_data->get_variation_id();					
					
					if(!empty($old_order_items) && array_key_exists($pid, $old_order_items)){
						if(array_key_exists($vid, $old_order_items[$pid])){
							$item_meta = $old_order_items[$pid][$vid];
							foreach($item_meta as $key=>$value){			
								$value = (current($value));			
								$existing_value = wc_get_order_item_meta($item_id, $key, true);		
								if($existing_value==''){
									wc_update_order_item_meta($item_id, $key, $value);
								}
							}
						}
					}
				}
				
				//exit;
				
			}			
		}
		function wc_os_get_order_item_meta($item_id){
			$obj = array();
			if($item_id){
				global $wpdb;
				$results = $wpdb->get_results('SELECT * FROM `'.$wpdb->prefix.'woocommerce_order_itemmeta` WHERE order_item_id='.$item_id);
				if(!empty($results)){
					foreach($results as $result){
						$obj[$result->meta_key] = array($result->meta_value);
					}
				}
			}
			return $obj;
		}
		
		public function splitted_order_data($order_id, $originalorderid = null, $product_id, $variation_id, $qty=false, $_order_total=false, $reduce_stock=false){
			
			global $wc_os_pro, $yith_pre_order;
			
			$order = new WC_Order($order_id);
			
			if ($originalorderid != null) {
				$this->original_order_id = $originalorderid;
			} else {
				$this->original_order_id = $_GET['order_id'];
			}
			
			
			$this->meta_keys_clone_from_to($order_id, $originalorderid);
			
			$original_order = new WC_Order($this->original_order_id);
						
			// Check if Sequential Numbering is installed
			
			if ( class_exists( 'WC_Seq_Order_Number_Pro' ) ) {
				
				// Set sequential order number 
				
				$setnumber = new WC_Seq_Order_Number_Pro;
				$setnumber->set_sequential_order_number($order_id);
				
			}
			
			//pree($order_id.', splitted_from, '.$originalorderid);
			
			update_post_meta($order_id, 'splitted_from', $originalorderid);
			
			$this->clone_order_header($order_id, $_order_total);
			$this->clone_order_billing($order_id);
			$this->clone_order_shipping($order_id);
			
			if ($variation_id != 0) {
				$product = new WC_Product_Variation($variation_id);
			
			} else {
				$product = new WC_Product($product_id);	
			}	
			
			//wc_os_pree('$is_virtual');
			//wc_os_pree($product->is_virtual('yes'));exit;
			$is_virtual = ($product->is_virtual('yes'));//($product->virtual=='yes');			
			
			//wc_os_pree($is_virtual);exit;
			
			if(!$is_virtual) //14/11/2018
			$this->clone_order_shipping_items($order_id, $original_order, $qty);
			
			$this->clone_order_fees($order, $original_order);
			
			$this->clone_order_coupons($order, $original_order);
			
			$this->splitted_order_items($order, $original_order, $product_id, $variation_id, $qty, $_order_total);
			
			if(!$original_order->get_total_tax()){
				delete_post_meta($order_id, 'vat_compliance_country_info');
				delete_post_meta($order_id, 'wceuvat_conversion_rates');
				delete_post_meta($order_id, 'vat_compliance_vat_paid');
				//delete_post_meta($order_id, 'wc_pos_order_type');
				//$order->set_total(0);
				update_post_meta($order_id, 'wos_remove_taxes', true);
				

			}
			//vat_compliance_country_info
			//wc_os_pree(get_post_meta($originalorderid));
			//wc_os_pree($original_order->get_total_tax());
			//wc_os_pree($order->get_total_tax());
			//wc_os_pree(get_post_meta($order_id));
			//exit;
			
			
			
			update_post_meta( $order_id, '_payment_method', get_post_meta($this->original_order_id, '_payment_method', true) );
			update_post_meta( $order_id, '_payment_method_title', get_post_meta($this->original_order_id, '_payment_method_title', true) );
			
			// Reduce Order Stock
			//if($reduce_stock)
			//wc_reduce_stock_levels($order_id);
			
			// POSSIBLE CHANGE? - Set status to on hold as payment is not received			
			$order_status = $original_order->get_status();
			
			//wc_os_pree($order_status);
			//wc_os_pree($wc_os_pro);
			
			//$order->update_status(($this->processing?'completed':$order_status));
			if($wc_os_pro){
				//START >> 05 January 2019 - THIS SECTION IS ADDED TO CONTROL DIFFERENT ORDER STATUSES WITH PRODUCT BASED META KEYS AND VALUES
				
				$classObj = new wc_os_bulk_order_splitter;
				
				$order_status_by_rule = $classObj->get_order_status_by_rule($order_id, $product_id);
				
				$order_status = ($order_status_by_rule?$order_status_by_rule:$order_status);
				
				//wc_os_pree($order_status);

				//END << 05 January 2019 - THIS SECTION IS ADDED TO CONTROL DIFFERENT ORDER STATUSES WITH PRODUCT BASED META KEYS AND VALUES
				
			}
			
			$order_status_directed = wc_os_order_split_status_action();

			if($order_status_directed){
				wp_update_post(array('ID'=>$order_id, 'post_status'=>$order_status_directed));
			}else{			
				$order->update_status($order_status);
			}
			//wc_os_pree($order_status);//exit;
			// Set order note of original cloned order
			
			$order->add_order_note(__('Cloned Order from').' #'.$this->original_order_id.'');
			
			
			$order->calculate_totals();
			$_order_total = $order->calculate_totals();
			update_post_meta( $order_id, '_order_total',  $_order_total);
			// Returns success message on clone completion
			
			if(!$this->cron_in_progress)
			add_action( 'admin_notices', array($this, 'split__success'));
			
			
			
		}
			
		/**
		 * Duplicate Order Header meta
		 */
		
		public function clone_order_header($order_id, $_order_total=false){
			
			
			//pree($_order_total);
			if($_order_total){
				
			}else{
				
				$_order_total = get_post_meta($this->original_order_id, '_order_total', true);
				
			}
			
			//pree($_order_total);exit;
	
			update_post_meta( $order_id, '_order_shipping', get_post_meta($this->original_order_id, '_order_shipping', true) );
			update_post_meta( $order_id, '_order_discount', get_post_meta($this->original_order_id, '_order_discount', true) );
			update_post_meta( $order_id, '_cart_discount', get_post_meta($this->original_order_id, '_cart_discount', true) );
			update_post_meta( $order_id, '_order_tax', get_post_meta($this->original_order_id, '_order_tax', true) );
			update_post_meta( $order_id, '_order_shipping_tax', get_post_meta($this->original_order_id, '_order_shipping_tax', true) );
			update_post_meta( $order_id, '_order_total',  sanitize_wc_os_data($_order_total));
	
			update_post_meta( $order_id, '_order_key', 'wc_' . apply_filters('woocommerce_generate_order_key', uniqid('order_') ) );
			update_post_meta( $order_id, '_customer_user', get_post_meta($this->original_order_id, '_customer_user', true) );
			update_post_meta( $order_id, '_order_currency', get_post_meta($this->original_order_id, '_order_currency', true) );
			update_post_meta( $order_id, '_prices_include_tax', get_post_meta($this->original_order_id, '_prices_include_tax', true) );
			update_post_meta( $order_id, '_customer_ip_address', get_post_meta($this->original_order_id, '_customer_ip_address', true) );
			update_post_meta( $order_id, '_customer_user_agent', get_post_meta($this->original_order_id, '_customer_user_agent', true) );
			
	
			$_tribe_tickets_meta = get_post_meta($this->original_order_id, '_tribe_tickets_meta', true);
			if($_tribe_tickets_meta)
			update_post_meta( $order_id, '_tribe_tickets_meta', get_post_meta($this->original_order_id, '_tribe_tickets_meta', true) );
			
		}
		
		/**
		 * Duplicate Order Billing meta
		 */
		
		public function clone_order_billing($order_id){
	
			update_post_meta( $order_id, '_billing_city', get_post_meta($this->original_order_id, '_billing_city', true));
			update_post_meta( $order_id, '_billing_state', get_post_meta($this->original_order_id, '_billing_state', true));
			update_post_meta( $order_id, '_billing_postcode', get_post_meta($this->original_order_id, '_billing_postcode', true));
			update_post_meta( $order_id, '_billing_email', get_post_meta($this->original_order_id, '_billing_email', true));
			update_post_meta( $order_id, '_billing_phone', get_post_meta($this->original_order_id, '_billing_phone', true));
			update_post_meta( $order_id, '_billing_address_1', get_post_meta($this->original_order_id, '_billing_address_1', true));
			update_post_meta( $order_id, '_billing_address_2', get_post_meta($this->original_order_id, '_billing_address_2', true));
			update_post_meta( $order_id, '_billing_country', get_post_meta($this->original_order_id, '_billing_country', true));
			update_post_meta( $order_id, '_billing_first_name', get_post_meta($this->original_order_id, '_billing_first_name', true));
			update_post_meta( $order_id, '_billing_last_name', get_post_meta($this->original_order_id, '_billing_last_name', true));
			update_post_meta( $order_id, '_billing_company', get_post_meta($this->original_order_id, '_billing_company', true));
			
			do_action('clone_extra_billing_fields_hook', $order_id, $this->original_order_id);
			
		}
		
		/**
		 * Duplicate Order Shipping meta
		 */
		
		public function clone_order_shipping($order_id){
	
			update_post_meta( $order_id, '_shipping_country', get_post_meta($this->original_order_id, '_shipping_country', true));
			update_post_meta( $order_id, '_shipping_first_name', get_post_meta($this->original_order_id, '_shipping_first_name', true));
			update_post_meta( $order_id, '_shipping_last_name', get_post_meta($this->original_order_id, '_shipping_last_name', true));
			update_post_meta( $order_id, '_shipping_company', get_post_meta($this->original_order_id, '_shipping_company', true));
			update_post_meta( $order_id, '_shipping_address_1', get_post_meta($this->original_order_id, '_shipping_address_1', true));
			update_post_meta( $order_id, '_shipping_address_2', get_post_meta($this->original_order_id, '_shipping_address_2', true));
			update_post_meta( $order_id, '_shipping_city', get_post_meta($this->original_order_id, '_shipping_city', true));
			update_post_meta( $order_id, '_shipping_state', get_post_meta($this->original_order_id, '_shipping_state', true));
			update_post_meta( $order_id, '_shipping_postcode', get_post_meta($this->original_order_id, '_shipping_postcode', true));
			
			do_action('clone_extra_shipping_fields_hook', $order_id, $this->original_order_id);
		
		}
		
		
		/**
		 * Duplicate Order Fees
		 */
		
		public function clone_order_fees($order, $original_order){
	
			$fee_items = $original_order->get_fees();
	 
			if (empty($fee_items)) {
				
			} else {
				
				foreach($fee_items as $fee_key => $fee_value){
					
					$fee_item  = new WC_Order_Item_Fee();
	
					$fee_item->set_props( array(
						'name'        => $fee_item->get_name(),
						'tax_class'   => $fee_value['tax_class'],
						'tax_status'  => $fee_value['tax_status'],
						'total'       => $fee_value['total'],
						'total_tax'   => $fee_value['total_tax'],
						'taxes'       => $fee_value['taxes'],
					) );
					//pree('clone_order_fees');exit;
					$order->add_item( $fee_item );	 
					
				}
				
			}
	   
		}
		
		/**
		 * Duplicate Order Coupon
		 */
		
		public function clone_order_coupons($order, $original_order){
	
			$coupon_items = $original_order->get_used_coupons();
	
			if (empty($coupon_items)) {
				
			} else {
				
				foreach($original_order->get_items( 'coupon' ) as $coupon_key => $coupon_values){
					
					$coupon_item  = new WC_Order_Item_Coupon();
	
					$coupon_item->set_props( array(
						'name'  	   => $coupon_values['name'],
						'code'  	   => $coupon_values['code'],
						'discount'     => $coupon_values['discount'],
						'discount_tax' => $coupon_values['discount_tax'],
					) );
	
					$order->add_item( $coupon_item );	 
					
				}
				
			}
	   
		}
		

		
		/**
		 * Clone Items - v 1.3
		 */
		
		public function clone_order_items($order, $original_order){
			
			global $wc_os_pro, $yith_pre_order, $wc_os_debug;
			
			$order_id = $order->get_id();
			$order_status = $original_order->get_status();
			
			//pree($this->exclude_items);pree($this->include_items);
					
			foreach($original_order->get_items() as $order_key => $values){
				//pree($values->get_product_id());
				//pree($values->get_variation_id());
				//exit;
				
				if($values->get_variation_id()){
					$applied_product_id = $values->get_variation_id();
				}else{
					$applied_product_id = $values->get_product_id();
				}	
				
				
				if(!empty($this->exclude_items) && (in_array($applied_product_id, $this->exclude_items))){ //07 January 2019 - So we can clone, slice, partially clone and/or partially split an order
					continue;
				}
				
				if(!empty($this->include_items) && (!in_array($applied_product_id, $this->include_items))){ //07 January 2019 - So we can clone, slice, partially clone and/or partially split an order
					continue;
				}				
				
				//wc_os_pree($values['product_id']);
					
		
				//$order->update_status(($this->processing?'completed':$order_status));
				if($wc_os_pro){
					//START >> 05 January 2019 - THIS SECTION IS ADDED TO CONTROL DIFFERENT ORDER STATUSES WITH PRODUCT BASED META KEYS AND VALUES				
					$wc_os_rules = get_option('wc_os_rules', array());
					$wc_os_rules = is_array($wc_os_rules)?$wc_os_rules:array();				
					$meta_kv = get_post_meta($applied_product_id);
					$meta_kv = (is_array($meta_kv)?$meta_kv:array());
					//wc_os_pree($wc_os_rules);
					//wc_os_pree($meta_kv);
					
					$cross_match = array_intersect_key($wc_os_rules, $meta_kv);
					//wc_os_pree('$cross_match');
					//wc_os_pree($cross_match);
					
					if(!empty($cross_match)){
						$wc_os_order_statuses = wc_get_order_statuses();
						//wc_os_pree($wc_os_order_statuses);
						$wc_os_order_statuses_keys = array_keys($wc_os_order_statuses);
						//wc_os_pree($wc_os_order_statuses_keys);
						foreach($cross_match as $mk=>$rd){
							if(!empty($rd)){
								foreach($rd as $rk=>$rv){
									if(in_array($rv, $wc_os_order_statuses_keys)){
										$order_status = $rv;
									}
								}
							}
						}
						
						
											
						if($yith_pre_order){
							
							if(array_key_exists('_ywpo_preorder', $meta_kv)){						
								$order_status = 'wc-on-hold';
								update_post_meta( $order_id, '_order_has_preorder', $meta_kv['_ywpo_preorder'][0]);
							}

						}
					}
	
					//END << 05 January 2019 - THIS SECTION IS ADDED TO CONTROL DIFFERENT ORDER STATUSES WITH PRODUCT BASED META KEYS AND VALUES
					
				}
				
				if ($values['variation_id'] != 0) {
					$product = new WC_Product_Variation($values['variation_id']);
				
				} else {
					$product = new WC_Product($values['product_id']);	
				}
				
				$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
				
				$unit_price = $product->get_price();
				
				$item                       = new WC_Order_Item_Product();
				$item->legacy_values        = $values;
				$item->legacy_cart_item_key = $order_key;
				
				//wc_os_pree($this->include_items_qty);
				
				$product_qty = ((is_array($this->include_items_qty) && array_key_exists($product_id, $this->include_items_qty))?$this->include_items_qty[$product_id]:$values['quantity']);
				
				//wc_os_pree('$unit_price: '.$unit_price.', line_subtotal: '.$values['line_subtotal'].', quantity: '.$values['quantity']);
				
				
				$line_price = ($values['quantity']>=1?($values['line_total']/$values['quantity']):$values['line_total']);
				
				
				
				$set_props = array(
					//'quantity'     => ($product_qty>$values['quantity']?$product_qty:$values['quantity']),
					'quantity'     => ($product_qty<=$values['quantity']?$product_qty:$values['quantity']),//24/10/2019 because new provided qty should be within ordered qty.
					'variation'    => $values['variation'],					
					'subtotal_tax' => $values['line_subtotal_tax'],
					'total_tax'    => $values['line_tax'],
					'taxes'        => $values['line_tax_data'],
				);
				//pree('clone_order_items');exit;
				if($line_price!=$unit_price){
					$total = $line_price*$set_props['quantity'];
				}else{
					$total = false;
				}
				//pree($total);
				//wc_os_pree('$unit_price: '.$unit_price.', '.'$product_qty: '.$product_qty.', quantity: '.$values['quantity'].', line_total: '.$values['line_total'].', price: '.$line_price.', $total: '.$total);
				
				$set_props['subtotal'] = ($total?$total:$unit_price*$set_props['quantity']);
				$set_props['total'] = ($total?$total:$unit_price*$set_props['quantity']);
				
				//wc_os_pree($set_props);
				$item->set_props($set_props);
				
				if ( $product ) {
					$item->set_props( array(
						'name'         => $product->get_name(),
						'tax_class'    => $product->get_tax_class(),
						'product_id'   => $product_id,
						'variation_id' => $product->is_type( 'variation' ) ? $product->get_id() : 0,
					) );
				}
				
				//wc_os_pree($item);//exit;
				
				//if(array_key_exists($product_id, $this->include_items_qty))
				$item->set_backorder_meta();
				
				if($product_qty){
					$order->add_item( $item );
					//wc_delete_order_item_meta(, 'split');
				}else{
					//if($wc_os_debug)
					//wc_os_pree('product_qty = '.$product_qty);
				}
			 
			}
			
			
		}
		
		
		public function splitted_order_items($order, $original_order, $product_id, $variation_id, $qty=false, $total=false){
			//pree('splitted_order_items');exit;
			 foreach($original_order->get_items() as $order_key => $values){
				
				if ($values['variation_id'] != 0) {
					$product = new WC_Product_Variation($values['variation_id']);
	
				} else {
					$product = new WC_Product($values['product_id']);	
				}
				
				$unit_price = $product->get_price();
				
				if(
						($values['variation_id'] != 0 && $variation_id==$values['variation_id'] && $product_id==$values['product_id'])
					||
						($values['variation_id'] == 0 && $product_id==$values['product_id'])
				){
				}else{
					continue;
				}
				
				
				$item                       = new WC_Order_Item_Product();
				$item->legacy_values        = $values;
				$item->legacy_cart_item_key = $order_key;
				
				
				
				//wc_os_pree($qty);
				//wc_os_pree($values);//exit;
				//wc_os_pree($unit_price);
				
				
				$line_price = ($values['quantity']>=1?($values['line_total']/$values['quantity']):$values['line_total']);
				
				//wc_os_pree('$unit_price: '.$unit_price.', '.'$qty: '.$qty.', quantity: '.$values['quantity'].', line_total: '.$values['line_total'].', price: '.$line_price.', $total: '.$total);
				
				$set_props = array(
					'quantity'     => ($qty?$qty:$values['quantity']),
					'variation'    => $values['variation'],					
					'subtotal_tax' => $values['line_subtotal_tax'],
					'total_tax'    => $values['line_tax'],
					'taxes'        => $values['line_tax_data'],
				);
				//pree($set_props);exit;
				//pree($total);
				//wc_os_pree('$unit_price: '.$unit_price.' != $line_price: '.$line_price);
				if($line_price!=$unit_price){
					$total = $line_price*$set_props['quantity'];
				}else{
					$total = false;
				}
				//pree($total);
				
				$set_props['subtotal'] = ($total?$total:$unit_price*$set_props['quantity']);
				$set_props['total'] = ($total?$total:$unit_price*$set_props['quantity']);
				
				//wc_os_pree($set_props);
				
				$item->set_props( $set_props );
				
				if ( $product ) {
					$set_pros = array(
						'name'         => $product->get_name(),
						'tax_class'    => $product->get_tax_class(),
						'product_id'   => $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id(),
						'variation_id' => $product->is_type( 'variation' ) ? $product->get_id() : 0,
					);
					//wc_os_pree($set_pros);exit; 
					$item->set_props( $set_pros );
				}
	
				$item->set_backorder_meta();
				
				//wc_os_pree($item);exit;
				
				$order->add_item( $item );	 
				 
			 }
			 
			 //exit;
		}	
		
		/**
		 * Clone success
		 */
		
		function clone__success() {
		
			$class = 'notice notice-success is-dismissible';
			$message = __( 'Order Cloned.', 'woo-order-splitter' );
		
			printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
	
		}
		
		function split__success() {
		
			$class = 'notice notice-success is-dismissible';
			$message = __( 'Order Splitted.', 'woo-order-splitter' );
		
			printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
	
		}	
		
		/**
		 * Clone error
		 */
		
		function merge__error() {
			$class = 'notice notice-error';
			$message = __( 'Consolidation Failed an error has occurred.', 'woo-order-splitter' );
		
			printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
		}
				
		function clone__error() {
			$class = 'notice notice-error';
			$message = __( 'Duplication Failed an error has occurred.', 'woo-order-splitter' );
		
			printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
		}
		
		
		function split__error() {
			$class = 'notice notice-error';
			$message = __( 'Split Failed an error has occurred.', 'woo-order-splitter' );
		
			printf( '<div class="%1$s"><p>%2$s</p></div>', $class, $message ); 
		}
			
		
		/**
		 * Duplicate Shipping Item Meta
		 * v1.4 - Shipping is added with order items
		 */
		
		public function clone_order_shipping_items($order_id, $original_order, $qty=false){
		 	
			$original_order_shipping_items = $original_order->get_items('shipping');
	
			foreach ( $original_order_shipping_items as $original_order_shipping_item ) {
				
				//wc_os_pree($original_order_shipping_item);
				//wc_os_pree(wc_format_decimal($original_order_shipping_item['cost']));exit;
				$cost = wc_format_decimal( $original_order_shipping_item['cost'] );
				//wc_os_pree($cost);
				if($cost && $qty){ //22/05/2019
					$qty_total = wc_order_total_qty($original_order);
					//wc_os_pree($qty_total);
					$per_item_cost = ($cost/$qty_total);
					//wc_os_pree($per_item_cost);
					$order = new WC_Order($order_id);
					//$qty_total_new = wc_order_total_qty($order);
					//wc_os_pree($qty_total_new);
					
					//$cost = ($qty_total_new*$per_item_cost);
					//wc_os_pree($cost);
					$cost = ($qty*$per_item_cost);
					//wc_os_pree($cost);
				}
				//exit;
				$item_id = wc_add_order_item( $order_id, array(
					'order_item_name'       => $original_order_shipping_item['name'],
					'order_item_type'       => 'shipping'
				) );
	
				if ( $item_id ) {
					wc_add_order_item_meta( $item_id, 'method_id', $original_order_shipping_item['method_id'] );
					wc_add_order_item_meta( $item_id, 'cost',  $cost );
				}
	
			}
		}
		   
	}
	
	new wc_os_order_splitter;


	function wc_os_admin_menu()
	{
		global $wc_os_data;
		
		$title = str_replace('WooCommerce', 'WC', $wc_os_data['Name']);
		add_submenu_page('woocommerce', $title, $title, 'manage_woocommerce', 'wc_os_settings', 'wc_os_settings' );



	}

	function wc_os_settings(){ 



		if ( !current_user_can( 'administrator' ) )  {



			wp_die( __( 'You do not have sufficient permissions to access this page.', 'woo-order-splitter' ) );



		}



		global $wpdb; 

		

				
		include('wc_settings.php');	

		

	}
	
	
	function wc_os_plugin_linx($links) { 

		global $wc_os_premium_copy, $wc_os_pro;


		$settings_link = '<a href="admin.php?page=wc_os_settings">'.__('Settings', 'woo-order-splitter').'</a>';

		
		if($wc_os_pro){
			array_unshift($links, $settings_link); 
		}else{
			 
			$wc_os_premium_link = '<a href="'.$wc_os_premium_copy.'" title="'.__('Go Premium', 'woo-order-splitter').'" target="_blank">'.__('Go Premium', 'woo-order-splitter').'</a>'; 
			array_unshift($links, $settings_link, $wc_os_premium_link); 
		
		}
				
		
		return $links; 
	}
	
	function wc_os_get_products(){
		$args = array(
			'post_type' => 'product',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',

			);
		$results = get_posts( $args );		
		
		return $results;
	}		
	
	function wc_os_get_product_categories(){
		$cat_args = array(
			'orderby'    => 'name',
			'order'      => 'ASC',
			'hide_empty' => false,
		);
		 
		$product_categories = get_terms( 'product_cat', $cat_args );		
		
		return $product_categories;
	}		
		
	function wc_os_settings_refresh(){
		global $wc_os_settings;
		$wc_os_settings = get_option('wc_os_settings', array());		
		$wc_os_settings['wc_os_products'] = (isset($wc_os_settings['wc_os_products']) && is_array($wc_os_settings['wc_os_products']))?$wc_os_settings['wc_os_products']:array();
		$wc_os_settings['wc_os_additional'] = (isset($wc_os_settings['wc_os_additional']) && is_array($wc_os_settings['wc_os_additional']))?$wc_os_settings['wc_os_additional']:array();		
		$wc_os_settings['wc_os_ie'] =(isset($wc_os_settings['wc_os_ie']) && $wc_os_settings['wc_os_ie']!=''?$wc_os_settings['wc_os_ie']:'default');
		//wc_os_pree($wc_os_settings);
	}
	
	function wc_os_crons($order_id=0){
		
		
		
		
		global $wc_os_settings, $wc_os_debug, $pagenow;
		
		//pree($pagenow);exit;
		if(!is_admin() || (is_admin() && $pagenow=='edit.php' && isset($_REQUEST['post_type']) && $_REQUEST['post_type']=='shop_order')){
		}else{
			return;
		}
		
		wc_os_settings_refresh();
		
		//wc_os_pree($_POST['wc_os_ps']);exit;
		//wc_os_pree(wc_os_order_split());exit;
		
		
		
		//wc_os_pree(wc_os_order_split());exit;
		if(wc_os_order_split()){
			
			$wc_os_products = $wc_os_settings['wc_os_products'];		
			
			$wc_os_order_splitter_cron = get_option('wc_os_order_splitter_cron', array());
			$wc_os_order_splitter_cron = (is_array($wc_os_order_splitter_cron)?$wc_os_order_splitter_cron:array());
			
			global $wpdb;
			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key IN ('_wos_out_of_stock')";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);			
			//pree($wc_os_order_key_cron);
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){			
					$order_id = $all_crons_items->ID;
					delete_post_meta($order_id, '_wos_out_of_stock');
					//delete_post_meta($order_id, 'split_status');
					//update_post_meta($order_id, 'wc_os_order_splitter_cron', true);
					
				}
			}			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key IN ('_wos_consider_split_email', 'wos_consider_split_email')";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);			
			//pree($wc_os_order_key_cron);
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){			
					$order_id = $all_crons_items->ID;
					//$order_received_text = trim(__wos_change_order_received_text($order_id));
					//pree($order_id);
					//pree($order_received_text);
					//if($order_received_text!=''){
						$mail_success = wos_email_notification(array('new'=>array($order_id), 'original'=>$order_id));
						if($mail_success){
							delete_post_meta($order_id, '_wos_consider_split_email');
							delete_post_meta($order_id, 'wos_consider_split_email');
						}
					//}
				}
			}
			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key='items_status_check'";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);			
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){
			
					$order_id = $all_crons_items->ID;
					$order_data = wc_get_order( $order_id );
					if(count($order_data->get_items())<1){
						wp_delete_post($order_id);
					}
				}
				//if(is_admin()){ wp_redirect('edit.php?post_type=shop_order');exit; }
			}
			
			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key='_wos_calculate_totals'";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){			
					$order_id = $all_crons_items->ID;
					$order_data = wc_get_order( $order_id );
					$order_data->calculate_taxes();
					$order_data->calculate_totals();
					delete_post_meta($order_id, '_wos_calculate_totals');
					update_post_meta($order_id, '__wos_calculate_totals_for_tax', true);
				}
			}
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key='__wos_calculate_totals_for_tax'";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){			
					$order_id = $all_crons_items->ID;
					$order_data = wc_get_order( $order_id );
					$order_data->calculate_taxes();
					$order_data->calculate_totals();
					delete_post_meta($order_id, '__wos_calculate_totals_for_tax');
				}
			}
			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key='wos_remove_taxes'";
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);
			//wc_os_pre($cron_query);
			//wc_os_pre($wc_os_order_key_cron);
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){
			
					$order_id = $all_crons_items->ID;
					$order_data = wc_get_order( $order_id );
					delete_post_meta($order_id, 'wos_remove_taxes');
					foreach($order_data->get_items() as $item_id => $item_data){
					
						update_metadata( 'order_item', $item_id, '_line_subtotal_tax', 0);
						update_metadata( 'order_item', $item_id, '_line_tax_data', 0);
						update_metadata( 'order_item', $item_id, '_line_tax_data', array());
					
					}
					$order_data->calculate_totals();
				
				}
				//if(is_admin()){ wp_redirect('edit.php?post_type=shop_order');exit; }
			}
			
			
			$cron_query = "SELECT p.ID FROM $wpdb->postmeta mt RIGHT JOIN $wpdb->posts p ON p.ID=mt.post_id AND p.post_type='shop_order' WHERE mt.meta_key='wc_os_order_splitter_cron'";// AND mt.meta_key!='splitted_from'
			//wc_os_pre($cron_query);//exit;
			$wc_os_order_key_cron = $wpdb->get_results($cron_query);			
			//pree($wc_os_order_key_cron);exit;
			
			if($wc_os_debug)
			wc_os_pree($wc_os_order_key_cron);
			
			if(!empty($wc_os_order_key_cron)){
				foreach($wc_os_order_key_cron as $all_crons_items){
					//wc_os_pree($all_crons_items->ID);
					if(!array_key_exists($all_crons_items->ID, $wc_os_order_splitter_cron)){
						$wc_os_order_splitter_cron[$all_crons_items->ID] = true;//get_option('wc_os_auto_forced', 0); 23/10/2019
						
						//if(!$wc_os_debug)
						//delete_post_meta($all_crons_items->ID, 'wc_os_order_splitter_cron');
					}
				}
			}
			//pree($wc_os_order_splitter_cron);exit;	
			
			$wc_os_order_splitter_cron_clear = get_option('wc_os_order_splitter_cron_clear', array());
			$wc_os_order_splitter_cron_clear = (is_array($wc_os_order_splitter_cron_clear)?$wc_os_order_splitter_cron_clear:array());
			//wc_os_pree($wc_os_order_splitter_cron_clear);exit;
			
			$wc_os_order_splitter = new wc_os_order_splitter;
			
			
			
			//wc_os_pree($wc_os_order_splitter_cron);exit;
			//$wc_os_order_splitter_cron[348] = true;
			
			//$a = 0;
						
			if(!empty($wc_os_order_splitter_cron)){
				
				
				//wc_os_pree($wc_os_order_splitter_cron);exit;
				
				if($wc_os_debug)
				wc_os_pree($wc_os_order_splitter_cron);				
				
				foreach($wc_os_order_splitter_cron as $order_id => $auto_split){
					//wc_os_pree($auto_split);
					
					$valid_order = wc_get_order($order_id); 
					//wc_os_pree($valid_order);
					if(empty($valid_order)){ unset($wc_os_order_splitter_cron[$order_id]); continue; }
					//wc_os_pree($order_id);   
					//wc_os_pree($order);
					
					
					$wc_os_order_splitter->cron_in_progress = true;
					
					$wc_os_order_splitter->auto_split = ($auto_split?true:false);
				
					//wc_os_pree($auto_split);//exit;
					//wc_os_pree($wc_os_order_splitter->auto_split);
					//wc_os_pree($order_id);exit;
					
					$wc_os_prcess_status = true;
									
					if($auto_split){	
						//echo $order_id.'<br /><br />';
							$wc_os_ie = $wc_os_settings['wc_os_ie'];
							//wc_os_pree($wc_os_ie);exit;
							$wos_forced_ie = get_post_meta($order_id, 'wos_forced_ie', true);
							$wos_delete_order = get_post_meta($order_id, 'wos_delete_order', true);
							if($wos_forced_ie && $wos_delete_order){
								$wc_os_ie = $wos_forced_ie;
							}
							
							//wc_os_pree($wc_os_ie);
						//exit;
						//if(!$a){
							switch($wc_os_ie){
								default:
									$wc_os_prcess_status = $wc_os_order_splitter->split_order_logic($order_id);//, $wc_os_products);
									//wc_os_pree($order_id.' > '.$wc_os_prcess_status);
								break;
								case 'default':
									//wc_os_pree($order_id);
									//
									$wc_os_order_splitter->split_order($order_id);
								break;								
							}
							
							//$a++;
							
						//}
						//exit;
						
						//wc_os_pree('split_order_logic');
						
					}else{
						
						//wc_os_pree('wc_os_crons');exit;
						//wc_os_pree($order_id);wc_os_pree($wc_os_products);exit;
						
						//1 MARCH, 2019
						//if(!$wc_os_debug)
						//$wc_os_order_splitter->split_order($order_id, $wc_os_products);
						//else
						//wc_os_pree('split_order');
					}
					
					//if(wc_os_order_removal()){ //WE ARE CLONING SO WE HAVE TO REMOVE IT, NO NEED TO CHECK REMOVAL OPTION
					if($wc_os_prcess_status){ //20/05/2019
						$wc_os_order_splitter_cron_clear[$order_id] = time(); //24/01/2019
						unset($wc_os_order_splitter_cron[$order_id]);
					}
					//}

					
					
					$wc_os_order_splitter->cron_in_progress = false;
					
				}
				//exit;
				
				if(!$wc_os_debug)
				update_option('wc_os_order_splitter_cron', $wc_os_order_splitter_cron);
				else
				wc_os_pree('update_option: wc_os_order_splitter_cron');
				
				
			} 
			
			//wc_os_pree($wc_os_order_splitter_cron_clear);
			
			if(!empty($wc_os_order_splitter_cron_clear)){
				
				foreach($wc_os_order_splitter_cron_clear as $order_id => $timestamp){
					
					$mins = ((time()-$timestamp)/60);
					
					//if(wc_os_order_removal() && 
					//if($mins>=1){
						//$order_items_check = new WC_Order($order_id);
						//wc_os_pree(count($order_items_check->get_items()));
						//wc_os_pree($order_items_check->get_items());exit;
						$split_status = get_post_meta($order_id, 'split_status', true);
						$splitted_from = get_post_meta($order_id, 'splitted_from', true);		
						$cloned_from = get_post_meta($order_id, 'cloned_from', true);
						//$wos_delete_order = get_post_meta($order_id, 'wos_delete_order', true);

						//wc_os_pree($order_id);
						//wc_os_pree(get_post_meta($order_id));
						//exit;
						if(!$wc_os_debug){
							
							if(!wc_os_order_removal()){
								
								$wos_delete_order = get_post_meta($order_id, 'wos_delete_order', true);
								if($wos_delete_order){
									wp_trash_post($order_id); //14/05/2019
								}else{
									$removal_action = wc_os_order_removal_action('string');
									//wc_os_pree(($removal_action && (!$splitted_from && !$cloned_from)));
									if($removal_action!=''){
										$removal_arr = get_option('wos_update_status', array());
										$removal_arr[$order_id] = $removal_action;
										update_option('wos_update_status', $removal_arr);
									}
									//echo 'sk';
								}
								//pree($removal_action);exit;
							}elseif($split_status && (!$splitted_from && !$cloned_from) && wc_os_order_removal()){
								//pree($order_id.' removed through crons ~ '.($split_status?'Splitted':'Not Splitted').' from '.$splitted_from.' or Cloned from '.$cloned_from);//exit;
								wp_trash_post($order_id); //24/01/2019
							}
						}
						
						unset($wc_os_order_splitter_cron_clear[$order_id]);
					//}									
				}
				
				if(!$wc_os_debug)
				update_option('wc_os_order_splitter_cron_clear', $wc_os_order_splitter_cron_clear);
				else
				wc_os_pree('update_option: wc_os_order_splitter_cron_clear');
				
				
				
			}
			
			//exit;
			
			$removal_arr = get_option('wos_update_status', array());
			
			
			if(!empty($removal_arr)){
				//wc_os_pree($removal_arr);
				foreach($removal_arr as $order_id=>$status){
					
					
			
					$order_data = wc_get_order( $order_id );
					if(!empty($order_data) && method_exists($order_data, 'update_status')){
						$order_data->update_status($status);						
					}else{
						wp_update_post(array('ID'=>$order_id, 'post_status'=>$status));
					}
					unset($removal_arr[$order_id]);
					update_option('wos_update_status', $removal_arr);
					
					//pree($order_id.' - '.$status);
				}
				//exit;
				//if(is_admin()){ wp_redirect('edit.php?post_type=shop_order');exit; }
			}
			
			
		}
		
		
		
		
		//if($wc_os_debug)
		//exit;
							
	}
	
	function wos_array_unique_recursive($array)
	{
		$array = array_unique($array, SORT_REGULAR);
	
		foreach ($array as $key => $elem) {
			if (is_array($elem)) {
				$array[$key] = wos_array_unique_recursive($elem);
			}
		}
	
		return $array;
	}	

	
	
	
	
	
	function wc_os_init(){
		
		global $wc_os_currency, $wc_os_settings, $wc_os_activated;
		
		
		
		if(!$wc_os_activated)
		return;
		
		
		$wc_os_currency = wc_os_currency_symbol();
		wc_os_settings_refresh();
		
		
		//wc_os_pree($wc_os_settings);
		
		//add_action('init', array($this, 'split_order'));
		
		
		
		
	}
	
	add_action('init', 'wc_os_init');	
	
	
	//add_action('woocommerce_order_status_pending', 'wc_os_checkout_order_processed');
	//add_action('woocommerce_order_status_on-hold', 'wc_os_checkout_order_processed');
	//add_action('woocommerce_order_status_processing', 'wc_os_checkout_order_processed');
	//add_action('woocommerce_order_status_completed', 'wc_os_checkout_order_processed');
	
	function __wos_change_order_received_text($order_id, $deleted=true){
		ob_start();

		$parent_order = wc_get_order($order_id);
		//pree($parent_order);pree($order_id);
		
		
		$cart_total = 0;
		if(!empty($parent_order)){
			$cart_total = $parent_order->get_total();
		}
		
		
		$wos_cart_notices = get_option( 'wc_os_cart_notices', true);
		$co_total = $wos_cart_notices['co_total'];
		$args = array(
			'posts_per_page'   => -1,
			'offset'           => 0,
			'cat'         => '',
			'category_name'    => '',
			'orderby'          => 'date',
			'order'            => 'DESC',
			'include'          => '',
			'exclude'          => '',
			'meta_key'         => 'splitted_from',
			'meta_value'       => $order_id,
			'post_type'        => 'shop_order',
			'post_mime_type'   => '',
			'post_parent'      => '',
			'author'	   => '',
			'author_name'	   => '',
			'post_status'      => 'any',
			'suppress_filters' => true,
			'fields'           => '',
		);
		//pree($args);
		$posts_array = get_posts( $args );
		//pree($posts_array);
		
		if(!empty($posts_array)){
			$first_order = current($posts_array);
			$order_total = 0;
			foreach($posts_array as $post_data){
				$this_order = wc_get_order($post_data->ID);
				$total_amount = $this_order->get_total();
				$order_total += $total_amount;
				
				if(!get_option('wc_os_shipping_cost', 0)){
					$child_order_shipping_items = $this_order->get_items('shipping');
					//pree($child_order_shipping_items);
					if(!empty($child_order_shipping_items)){
						foreach($child_order_shipping_items as $item_id=>$item_data){
							//pree($item_id);
							wc_delete_order_item($item_id);
						}
						
					}
				}
				$this_order->calculate_totals();
				
				
				
			}
			
			
			
	?>
	
    <?php if($deleted): ?>
	
	<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">
	
        <li class="woocommerce-order-overview__order order">
        Order number: <strong><?php echo $order_id; ?></strong>
        </li>
        
        <li class="woocommerce-order-overview__date date">
        Date: <strong><?php echo date('F d, Y', strtotime($first_order->post_date)); ?></strong>
        </li>
        
        
        <li class="woocommerce-order-overview__total total">
        Total: <strong><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"><?php echo wc_os_currency_symbol(); ?></span><?php echo number_format($cart_total, 2); ?></span></strong>
        </li>
	
	</ul>
    
    <?php endif; ?>
    
	<section class="woocommerce-order-details">
	
	<h2 class="woocommerce-order-details__title"><?php echo $wos_cart_notices['co_heading']?$wos_cart_notices['co_heading']:'Child Order'.(count($posts_array)>1?'s':''); ?></h2>
	
	
	<?php 
	$cart_total += $order_total;
	//$posts_array = get_posts( $args );
	foreach($posts_array as $post_data){ $child_order = wc_get_order($post_data->ID); 
		
		$_payment_method = $child_order->get_payment_method_title();
		$child_order_data = $child_order->get_data();	
		
	?>
	
	<h3 class="child_order_heading"><?php echo $wos_cart_notices['co_number']?$wos_cart_notices['co_number']:'Order number'; ?> <?php echo $post_data->ID; ?></h3>
	<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
	
	<thead>
	<tr>
	<th class="woocommerce-table__product-name product-name">Product</th>
	<th class="woocommerce-table__product-table product-total">Total</th>
	</tr>
	</thead>
	
	<tbody>
	
	<?php foreach($child_order->get_items() as $order_items){ ?>    
	<tr class="woocommerce-table__line-item order_item">
	
	<td class="woocommerce-table__product-name product-name">
	<a href="<?php echo get_permalink($order_items->get_product_id()); ?>"><?php echo $order_items['name']; ?></a> <strong class="product-quantity">× <?php echo $order_items->get_quantity(); ?></strong>	</td>
	
	<td class="woocommerce-table__product-total product-total">
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"><?php echo wc_os_currency_symbol(); ?></span><?php echo number_format($order_items->get_total(), 2); ?></span>	</td>
	
	</tr>
	<?php } ?>
    
    <tr>
    <td>Tax:	</td>	
	<td><span class="woocommerce-Price-currencySymbol"><?php echo wc_os_currency_symbol(); ?></span><?php echo number_format($child_order_data['total_tax'], 2); ?></td>	
	</tr>
    
    <tr>
    <td>Payment method:	</td>	
	<td><?php echo $_payment_method; ?></td>	
	</tr>
    
	
	</tbody>
	
	<tfoot>
					
		
				   <tr>
			<th scope="row">Total:</th>
			<td><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"><?php echo wc_os_currency_symbol(); ?></span><?php echo number_format($child_order->get_total(), 2); ?></span></td>
		</tr>
							</tfoot>
	</table>
	<?php 
	}
	?>

    
    <?php if($co_total): ?>
    <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
	
	<thead>
	<tr>
	<th class="woocommerce-table__product-name product-name">Order Total</th>
	<th class="woocommerce-table__product-table product-total">Amount</th>
	</tr>
	</thead>
	
	<tbody>
	
	
	<tr class="woocommerce-table__line-item order_item">
	
	<td class="woocommerce-table__product-name product-name">
	Total amount charged to billing method	</td>
	
	<td class="woocommerce-table__product-total product-total">
	<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol"><?php echo wc_os_currency_symbol(); ?></span><?php echo number_format($cart_total, 2); ?></span>	</td>
	
	</tr>
	
	
	</tbody>
	
	
	</table>
    <?php endif;?>
	</section>
	<?php					
	
			
		}	
		//pree($order_id);pree($post_data->ID);
		//$wc_os_order_splitter = new wc_os_order_splitter;
		//$wc_os_order_splitter->cloned_order_data($post_data->ID, $order_id);
		
		$str = ob_get_contents();
		ob_end_clean();	
		return $str;
	}
	
	add_filter('woocommerce_thankyou_order_received_text', 'wos_change_order_received_text', 10, 2 );
	
	function wos_change_order_received_text( $str, $order ) {
		$qs = $_SERVER['REQUEST_URI'];
		$qs = explode('/', $qs);
		$qs = array_filter($qs, 'strlen');
		if(!is_numeric(end($qs))){
			array_pop($qs);
			//$qs = array_filter($qs, 'strlen');
		}
		//pree($qs);
		
		if(is_numeric(end($qs))){
			$order_id = end($qs);
			//pree($order_id);
			$order = wc_get_order($order_id);
			if(empty($order)){
				
				$str .= __wos_change_order_received_text($order_id);
				
			}
		}
		
		return $str;
	}
	
	add_action('woocommerce_thankyou', 'wc_os_checkout_order_processed', 10, 1);
	
	
	function wc_os_checkout_order_processed($order_id){
		//return;
		//wc_os_pree($_POST['wc_os_ps']);exit;
		//wc_os_pree($_REQUEST);exit;
		
		
		if ( ! $order_id )
        return;
		
		
				
		if(
				is_admin() 
			&& 
			(
					((isset($_GET['clone']) && $_GET['clone'] == 'yes') || (isset($_REQUEST['post_type']) && $_REQUEST['post_type']=='shop_order' && $_REQUEST['action']=='clone'))
				||
					((isset($_REQUEST['post_type']) && $_REQUEST['post_type']=='shop_order' && $_REQUEST['action']=='split'))
			)
		){
			return;
		}
		
		$order_obj = get_post($order_id);
		order_details_page_saved( $order_id, $order_obj );
		
		global $wc_os_settings;
		$order_data = wc_get_order( $order_id );
		//pree(count($order_data->get_items()));
		//wc_os_pree($order_id);
		//wc_os_pree($order_data);
		$split_lock = (isset($wc_os_settings['wc_os_additional']['split_lock'])?$wc_os_settings['wc_os_additional']['split_lock']:'');
		$status_lock_released = (!$split_lock || ($split_lock && $order_data->has_status($split_lock)));
		//wc_os_pree($status_lock_released);
		//wc_os_pree(get_option('wc_os_auto_forced', 0));
		if(!empty($order_data) && $status_lock_released && get_option('wc_os_auto_forced', 0)){
			
			//wc_os_pree($order_id);
			for($c=0;$c<=5;$c++){
				wc_os_crons($order_id);
			}
		}
		
		//echo $order_id;
		
		if(!is_admin()){
		
			echo __wos_change_order_received_text($order_id, false);

		}
		
		
	}
		
	function order_details_page_saved( $order_id, $post=array() ) {
		
		$order_details_page = isset($_POST['wc_os_ps']);
		
		//wc_os_pree($_POST);
		//wc_os_pree($order_details_page);exit;
		
		//wc_os_pree($order_id);
		//wc_os_pree($order_status);exit;
		
		// If this is just a revision, don't send the email.
		if ( wp_is_post_revision( $order_id ))
		return;
		
		//pree($post);//exit;
		//if ( !$post && !$order_details_page )
		$do_not_proceed = ( (!empty($post) && isset($post->post_type) && $post->post_type!='shop_order') && !$order_details_page );
		//pree($do_not_proceed);exit;
		if ($do_not_proceed)
		return; 
			
		global $wc_os_settings;
		wc_os_settings_refresh();
		
		//wc_os_pree($_POST['wc_os_ps']);exit;
		//wc_os_pree(wc_os_order_split());
		//wc_os_pree($wc_os_settings);
		//wc_os_pree($_POST);exit;
		//exit;
		//wc_os_pree($order_id);
		
		//wc_os_pree(wc_os_order_split());
		//wc_os_pree($wc_os_settings);exit;
		
		
		if(wc_os_order_split()){
			$wc_os_all_products = (isset($wc_os_settings['wc_os_all_product']) && $wc_os_settings['wc_os_all_product']) ? true : false; //flag indicating to all products are subject to splitting
			$wc_os_products = $wc_os_settings['wc_os_products'];
			
			
			//wc_os_pree($wc_os_all_products); exit;
			
			//wc_os_pree($_POST['wc_os_ps']);exit;
			$wc_os_ps = false;
			$wc_os_ie = $wc_os_settings['wc_os_ie'];
			
			if($order_details_page){
				$_POST['wc_os_ps'] = (!empty($_POST['wc_os_ps'])?$_POST['wc_os_ps']:array());
				$_POST['wc_os_ps'] = array_filter($_POST['wc_os_ps'], 'is_numeric');
				$wc_os_ps = true;
			}
			//wc_os_pree($wc_os_order_splitter->cron_in_progress);exit;
			//wc_os_pree($_POST['wc_os_ps']);exit;
			//wc_os_pree(!empty($wc_os_products) && count($wc_os_products)>1);

			//wc_os_pree('$wc_os_all_products');
			//wc_os_pree($wc_os_all_products);
			
			//wc_os_pree('$wc_os_products');			
			$wc_os_products = (isset($wc_os_products[$wc_os_ie])?$wc_os_products[$wc_os_ie]:array());
			//wc_os_pree($wc_os_products);
			//wc_os_pree('$order_details_page');
			//wc_os_pree($order_details_page);
			$wc_os_order_splitter_cron = get_option('wc_os_order_splitter_cron', array());
			$wc_os_order_splitter_cron = (is_array($wc_os_order_splitter_cron)?$wc_os_order_splitter_cron:array());
		
			if(
			
					($wc_os_ie=='cats')
				||
					(
							($wc_os_ie!='cats')
						&&
							($wc_os_all_products || (!empty($wc_os_products) && count($wc_os_products)>1))
					)
						
				||
					$order_details_page
				
			){
				//wc_os_pree($order_details_page);
				//wc_os_pree($wc_os_all_products);exit;
				
				//wc_os_pree($order_id);
				//wc_os_pree($_POST['wc_os_ps']);exit;
				
				
				$wc_os_order_splitter = new wc_os_order_splitter;		
				//wc_os_pree('wc_os_ie');		
				//wc_os_pree($wc_os_settings['wc_os_ie']);//exit;
				
				switch($wc_os_settings['wc_os_ie']){
					
						default:
						case 'default':
						
							//wc_os_pree('order_details_page_saved');exit;
							
							if($order_details_page)
							$wc_os_order_splitter->split_order($order_id, $wc_os_products);
							elseif(!$wc_os_order_splitter->cron_in_progress)
							$wc_os_order_splitter_cron[$order_id] = ($wc_os_all_products?true:false);
							
						break;	
						
						case 'exclusive':
						case 'inclusive':
						case 'shredder':
						case 'io':
						case 'quantity_split':
						case 'cats':
						case 'groups':
						case 'group_cats':
						
							//$this->auto_split = true;
							//$wc_os_order_splitter->split_order_logic($order_id, $wc_os_products);
							$wc_os_order_splitter_cron[$order_id] = true;
							
						break;
						
				}
				//wc_os_pree('wc_os_order_splitter_cron');		
				//wc_os_pree($wc_os_order_splitter_cron);
				//wc_os_pree($wc_os_order_splitter->cron_in_progress);exit;
				
				//wc_os_pree('is_admin cron_in_progress wc_os_ps order_id');
				//wc_os_pree(!is_admin());
				//wc_os_pree(!$wc_os_order_splitter->cron_in_progress);
				//wc_os_pree($wc_os_ps);exit;
				//wc_os_pree($order_id);
				
				if((!is_admin() && !$wc_os_order_splitter->cron_in_progress) || $wc_os_ps)	
				update_post_meta($order_id, 'wc_os_order_splitter_cron', true);
				
				//wc_os_pree($wc_os_order_splitter_cron);exit;
				
				if((!is_admin() && !$wc_os_order_splitter->cron_in_progress) || $wc_os_ps){
					update_option('wc_os_order_splitter_cron', $wc_os_order_splitter_cron);
				}else{
					
				}
				
				
				
			}elseif(!is_admin() && get_option('wc_os_auto_forced', 0)){
				$wc_os_order_splitter_cron[$order_id] = true;
				update_post_meta($order_id, 'wc_os_order_splitter_cron', true);
				update_option('wc_os_order_splitter_cron', $wc_os_order_splitter_cron);
			}
		}		
	
	}
	add_action( 'save_post', 'order_details_page_saved', 11 );	
	
	function wc_os_sanitize_text_or_array_field($array_or_string) {
		if( is_string($array_or_string) ){
			$array_or_string = sanitize_text_field($array_or_string);
		}elseif( is_array($array_or_string) ){
			foreach ( $array_or_string as $key => &$value ) {
				if ( is_array( $value ) ) {
					$value = wc_os_sanitize_text_or_array_field($value);
				}
				else {
					$value = sanitize_text_field( $value );
				}
			}
		}
	
		return $array_or_string;
	}
	
	function wc_os_front_scripts() {	
		wp_enqueue_script(
			'wos_scripts',
			plugins_url('js/front-scripts.js', dirname(__FILE__)),
			array('jquery'),
			time()
		);	
	}
		
	function wc_os_admin_scripts() {
		
		global $wc_os_css_arr, $wc_os_settings, $post, $wc_os_cust, $wos_actions_arr;
		
		
		wp_register_style('wos-admin', plugins_url('css/admin-style.css?t='.time(), dirname(__FILE__)));
		
		
		wp_enqueue_style( 'wos-admin' );
		
		wp_enqueue_script(
			'wos_scripts',
			plugins_url('js/admin-scripts.js', dirname(__FILE__)),
			array('jquery'),
			time()
		);		
		//pree($post);exit;
		$conflict_status_options = array();
		if(!empty($post) && isset($post->post_type) && $post->post_type=='shop_order' && isset($_GET['action']) && $_GET['action']=='edit'){
			$order_id = $post->ID;
			$conflict_status = get_post_meta($order_id, 'conflict_status', true);
			
			if($conflict_status){
				
				$order_data = wc_get_order( $order_id );
				//pree($actions_arr);
				if($order_data->get_items()){			
					//pree($order_data->get_items());
					$wc_os_ie_selected = $wc_os_settings['wc_os_ie'];
					$wc_os_order_splitter = new wc_os_order_splitter;
					$products_with_actions = $wc_os_order_splitter->products_with_actions();
					$actions_arr = array();
					foreach($order_data->get_items() as $item_data){				
						//pree($item_data);
						//pree($item_data->get_product_id());
						if(array_key_exists($item_data->get_product_id(), $products_with_actions)){
							$actions_arr[] = $products_with_actions[$item_data->get_product_id()];
						}
					}
					$actions_arr = array_unique($actions_arr);
					//pree($actions_arr);	
					if(count($actions_arr)==0){ //BACKWARDS COMPATIBILITY
					}elseif(count($actions_arr)==1){ //REGULAR/VALID/NORMAL CASE
						$wc_os_ie_selected = current($actions_arr);
					}elseif(count($actions_arr)>1){ //EXPECTED/INVALID/CONFLICT CASE					
						$conflict_status_options[] = '<h6>'.__('Following product/items are configured with different split actions.', 'woo-order-splitter').'<br />'.__('Select one of these split actions to proceed for this order.', 'woo-order-splitter').'</h6>';
						if(!empty($actions_arr)){
							$conflict_status_options[] = '<ul>';
							$wos_forced_ie = get_post_meta($order_id, 'wos_forced_ie', true);
							foreach($actions_arr as $action_title){
								$conflict_status_options[] = '<li><a data-action="'.$action_title.'" class="'.($wos_forced_ie==$action_title?'forced':'').'">'.ucwords(split_actions_display($action_title, 'title')).'</a></li>';
							}
							$conflict_status_options[] = '</ul><div class="wos_loading smart"></div>';
						}
					}				
				}
			}
		}
		//pree($conflict_status_options);

		$translation_array = array(
			'defined_rules_confirm' => __('Are you sure, you want delete this rule?', 'woo-order-splitter'),
			'this_url' => admin_url( 'admin.php?page=wc_os_settings' ),
			'conflict_status' => (!empty($conflict_status_options)?implode('', $conflict_status_options):''),
			'orders_list' => admin_url( 'edit.php?post_type=shop_order' ),
			'wc_os_ie' => $wc_os_settings['wc_os_ie'],
			'wc_os_tab' => (isset($_GET['t'])?$_GET['t']:'0'),
			'wc_os_splitting' => (((isset($_GET['post_type']) && $_GET['post_type']=='shop_order') && 
			
							(
									
									((isset($_GET['order_id']) && is_numeric($_GET['order_id'])) && (isset($_GET['split']) && $_GET['split']=='init') && isset($_GET['split-session']))
								||
									isset($_GET['ids'])
									
							))?true:false)
		);
		
		
		
		wp_localize_script( 'wos_scripts', 'wos_obj', $translation_array );
		
		
		
	}		
	
	add_filter( 'woocommerce_checkout_fields' , 'wc_os_override_checkout_fields' );
	
	function split_actions_display($key, $type){
		global $wc_os_cust, $wos_actions_arr;
		
		$action_type = ($type=='title'?'action':'description');
		return ((isset($wc_os_cust[$key]) && isset($wc_os_cust[$key][$type]) && $wc_os_cust[$key][$type]!='')?$wc_os_cust[$key][$type]:((isset($wos_actions_arr[$key]) && isset($wos_actions_arr[$key][$action_type]))?$wos_actions_arr[$key][$action_type]:''));
	}
	
	
	
	function wc_os_override_checkout_fields( $fields ) {
	
		if(get_option('wc_os_shipping_off', 0)){
			unset($fields['shipping']['shipping_first_name']);
			unset($fields['shipping']['shipping_last_name']);
			unset($fields['shipping']['shipping_company']);
			unset($fields['shipping']['shipping_address_1']);
			unset($fields['shipping']['shipping_address_2']);
			unset($fields['shipping']['shipping_city']);
			unset($fields['shipping']['shipping_postcode']);
			unset($fields['shipping']['shipping_country']);
			unset($fields['shipping']['shipping_state']);
			unset($fields['shipping']['shipping_phone']);	
			unset($fields['shipping']['shipping_address_2']);
			unset($fields['shipping']['shipping_postcode']);
			unset($fields['shipping']['shipping_company']);
			unset($fields['shipping']['shipping_last_name']);
			unset($fields['shipping']['shipping_email']);
			unset($fields['shipping']['shipping_city']);	
		}
		
		if(get_option('wc_os_billing_off', 0)){
			unset($fields['billing']['billing_first_name']);
			unset($fields['billing']['billing_last_name']);
			unset($fields['billing']['billing_company']);
			unset($fields['billing']['billing_address_1']);
			unset($fields['billing']['billing_address_2']);
			unset($fields['billing']['billing_city']);
			unset($fields['billing']['billing_postcode']);
			unset($fields['billing']['billing_country']);
			unset($fields['billing']['billing_state']);
			unset($fields['billing']['billing_phone']);	
			unset($fields['billing']['billing_address_2']);
			unset($fields['billing']['billing_postcode']);
			unset($fields['billing']['billing_company']);
			unset($fields['billing']['billing_last_name']);
			unset($fields['billing']['billing_email']);
			unset($fields['billing']['billing_city']);
		}
		
		if(get_option('wc_os_order_comments_off', 0))
		unset($fields['order']['order_comments']);
		
		return $fields;
	}	
	
	function wc_os_header_scripts(){
		//global $post;
?>
	<style type="text/css">
	<?php
		if(get_option('wc_os_shipping_off', 0)){
?>
			.woocommerce-shipping-fields{
				display:none;	
			}
<?php			
		}
		if(get_option('wc_os_billing_off', 0)){
?>
			.woocommerce-billing-fields{
				display:none;	
			}
<?php			
		}
		if(get_option('wc_os_order_comments_off', 0)){
?>
			.woocommerce-additional-fields{
				display:none;
			}
<?php			
		}				
	?>
	</style>
<?php		
	}
	
	add_action('wp_head', 'wc_os_header_scripts');		
	
	function wc_os_order_cloning(){
		wc_os_settings_refresh();
		global $wc_os_settings;
		
		$cloning = (in_array('cloning', $wc_os_settings['wc_os_additional']));		
		
		return $cloning;
	}
	function wc_os_order_split(){
		wc_os_settings_refresh();
		global $wc_os_settings, $post;
		
		$split = (!in_array('split', $wc_os_settings['wc_os_additional']));
		$split_lock = (isset($wc_os_settings['wc_os_additional']['split_lock'])?$wc_os_settings['wc_os_additional']['split_lock']:'');
		
		//pree($split);
		//pree($split_lock);exit;
		if($split && $split_lock!=''){
			$wc_os_order_splitter = new wc_os_order_splitter;
			//pree($_POST['post_ID']);
			//pree($post->ID);
			$order_id = (isset($_GET['order_id'])?$_GET['order_id']:$wc_os_order_splitter->original_order_id);
			$order_id = (!$order_id?(isset($_POST['post_ID']) && $post->ID==$_POST['post_ID'])?$_POST['post_ID']:$order_id:$order_id);
			//pree($order_id);
			//exit;
			//pree($split_lock);
			//pree($get_order_status);
			if($order_id){
				$get_order_status = str_replace('wc-', '', get_post_status($order_id));
				$split = ($get_order_status==$split_lock);
			}
			
			//pree($get_order_status);
			//pree($split_lock);exit;
		}
		//pree($split);
		//exit;
		
		return $split;		
	}		
	function wc_os_order_removal(){
		wc_os_settings_refresh();
		global $wc_os_settings;
		
		$removal = (in_array('removal', $wc_os_settings['wc_os_additional']));
		
		return $removal;		
	}
	function wc_os_order_removal_action($type='boolean'){
		wc_os_settings_refresh();
		global $wc_os_settings;
		
		$removal_lock = (array_key_exists('removal_lock', $wc_os_settings['wc_os_additional']) && $wc_os_settings['wc_os_additional']['removal_lock']);
		
		if($type=='string' && $removal_lock){
			$removal_lock = $wc_os_settings['wc_os_additional']['removal_lock'];
		}
		
		return $removal_lock;		
	}	
	
	function wc_os_order_split_status_action(){
		wc_os_settings_refresh();
		global $wc_os_settings;

		$split_status_lock = in_array('split_status_lock', $wc_os_settings['wc_os_additional']);
		$split_status_lock = (isset($wc_os_settings['wc_os_additional']['split_status_lock'])?$wc_os_settings['wc_os_additional']['split_status_lock']:'');
		
		
		return $split_status_lock;		
	}	
		
	function wc_os_order_qty_split(){
		wc_os_settings_refresh();
		global $wc_os_settings;
		
		$qty_split = (in_array('qty_split', $wc_os_settings['wc_os_additional']));
		
		return $qty_split;		
	}	
	
	add_action( 'pre_get_posts', 'wos_shop_page_pre_get_posts' );
	function wos_shop_page_pre_get_posts( $query ) {
		if ( is_shop() && $query->is_main_query() && isset($_GET['vendor']) && is_numeric($_GET['vendor']) && $_GET['vendor']>0) :
			$query->set( 'author', sanitize_wc_os_data($_GET['vendor']) );
		endif;
	}
	function wc_os_links($actions, $post){
		

	
	
		if ($post->post_type=='shop_order' && wc_os_order_cloning()) {
			
			$url = admin_url( 'edit.php?post_type=shop_order&order_id=' . $post->ID );
			
			$copy_link = wp_nonce_url( add_query_arg( array( 'clone' => 'yes', 'clone-session' => date('Ymhi') ), $url ), 'edit_order_nonce' );
			
			$actions = array_merge( $actions, 
				array(
					'clone' => sprintf( '<a href="%1$s">%2$s</a>',
						esc_url( $copy_link ), 
						__('Clone', 'woo-order-splitter')
					) 
				) 
			);
		}
	
		if ($post->post_type=='shop_order' && wc_os_order_split()) {
		
			$url = admin_url( 'edit.php?post_type=shop_order&order_id=' . $post->ID );
			
			$copy_link = wp_nonce_url( add_query_arg( array( 'split' => 'init', 'split-session' => date('Ymhi') ), $url ), 'edit_order_nonce' );
			
			$actions = array_merge( $actions, 
				array(
					'split' => sprintf( '<a href="%1$s">%2$s</a>',
						esc_url( $copy_link ), 
						__( 'Split', 'woo-order-splitter' )
					) 
				) 
			);
			
		}
		//pree($post->post_author);
		if ($post->post_type=='product' && $post->post_author>0 && !isset($_GET['vendor'])) {
		
			$url = admin_url().'user-edit.php?user_id='. $post->post_author;
			
			$display_name = wos_get_author_name($post->post_author);
			
			$copy_link = wp_nonce_url( add_query_arg( array(), $url ), 'edit_order_nonce' );
			
			$actions = array_merge( $actions, 
				array(
					'vendor_url' => sprintf( '<a href="%1$s" target="_blank">%2$s</a>',
						esc_url( $copy_link ), 
						$display_name
					) 
				) 
			);
			
		}		
	
		return $actions;
				
	}
	
	add_filter( 'post_row_actions', 'wc_os_links', 10, 2 );
	
	function wos_get_author_name($vendor_id=0){
		$display_name = '';
		if($vendor_id>0){
			$vendor_data = get_user_by( 'ID', $vendor_id );
			$full_name = trim($vendor_data->first_name.' '.$vendor_data->last_name);
			$display_name = trim($vendor_data->display_name?$vendor_data->user_login:$vendor_data->user_login).($full_name?' ('.$full_name.')':'');
			$display_name = ($display_name?$display_name:$vendor_data->user_email);		
		}
		return $display_name;
	}
		
	function sv_wc_add_order_meta_box_action( $actions ) {
		global $theorder;

		global $wc_os_settings;
		
		$split_status = get_post_meta($theorder->get_id(), 'split_status', true);
		$splitted_from = get_post_meta($theorder->get_id(), 'splitted_from', true);	
		
		//wc_os_pree($wc_os_settings);
		//wc_os_pree(!$theorder->is_paid());
		//wc_os_pree($split_status);
		//wc_os_pree($splitted_from);
				
		// bail if the order has been paid for or this action has been run
		//! $theorder->is_paid() || 
		if ( $split_status || $splitted_from) {
			return $actions;
		}
	
	
		// add "mark printed" custom action
		//wc_os_pree(wc_os_order_split());
		if(wc_os_order_split()){
			$actions['wc_os_split_action'] = __( 'Split Order', 'woo-order-splitter' );
		}
		
		return $actions;
	}
	add_action( 'woocommerce_order_actions', 'sv_wc_add_order_meta_box_action' );	
		
	function sv_wc_process_order_meta_box_action( $order ) {
		//wc_os_pree($order->get_id());exit;
		wc_os_checkout_order_processed($order->get_id());
		
	}
	
	//add_action( 'woocommerce_order_action_wc_custom_order_action', 'sv_wc_process_order_meta_box_action' );
	function wc_order_total_qty($order){
		$qty = 0;		
		foreach($order->get_items() as $item_id=>$item_data){
		
			$qty += $item_data->get_quantity();
			
		}
		
		return $qty;
	}
		
	add_filter( 'woocommerce_admin_order_actions', 'add_wc_os_order_status_actions_button', 100, 2 );
	function add_wc_os_order_status_actions_button( $actions, $order ) {
		// Display the button for all orders that have a 'processing' status
		global $wc_os_settings;
		//pree($order->get_id());
		$url = admin_url( 'edit.php?post_type=shop_order&order_id=' . $order->get_id() );
		$conflict_status = get_post_meta($order->get_id(), 'conflict_status', true);
		
		$split_lock = (isset($wc_os_settings['wc_os_additional']['split_lock'])?$wc_os_settings['wc_os_additional']['split_lock']:'');
		
		//$status_arr = array( 'processing', 'on-hold', 'completed', 'pending' );
		//$status_arr[] = str_replace('wc-', '', $split_lock);
		//$status_arr = array_unique($status_arr);
		
		$wc_os_order_statuses = wc_get_order_statuses(); 
		$wc_os_order_statuses_keys = array_keys($wc_os_order_statuses);		
		$wc_os_order_statuses_keys = array_unique($wc_os_order_statuses_keys);
		
		$status_lock_released = (!$split_lock || ($split_lock && $order->has_status($split_lock)));
		
		//pre($status_arr);
		//pre($order->get_status());
		
		if ( $status_lock_released && wc_os_order_split() ) {
			
			$split_status = get_post_meta($order->get_id(), 'split_status', true);
			
			$splitted_from = get_post_meta($order->get_id(), 'splitted_from', true);
			
			$order_total_qty = wc_order_total_qty($order);
			//wc_os_pree(count($order->get_items())>1);exit;
			//wc_os_pree('$order_total_qty: '.$order_total_qty.' && wc_os_ie:'. $wc_os_settings['wc_os_ie']);
			//wc_os_pree('$split_status: '.$split_status.' && '.'$splitted_from: '.$splitted_from);
			if(!$split_status && !$splitted_from && 
					(
							count($order->get_items())>1 
						|| 
							($order_total_qty>1 && $wc_os_settings['wc_os_ie']=='quantity_split') //21/05/2019
					)
			){
	
				
				
				$copy_link = wp_nonce_url( add_query_arg( array( 'split' => 'init', 'split-session' => date('Ymhi') ), $url ), 'edit_order_nonce' );
				
				// Get Order ID (compatibility all WC versions)
				$order_id = $order->get_id();
				// Set the action button
				$actions['split_order'] = array(
					'url'       => $copy_link,
					'name'      => __( 'Split Order', 'woo-order-splitter' ),
					'action'    => "wc_os_split", 
				);
				
			}
		}
		
		if(wc_os_order_cloning()){
				
			$copy_link = wp_nonce_url( add_query_arg( array( 'clone' => 'yes', 'clone-session' => date('Ymhi') ), $url ), 'edit_order_nonce' );				
			$actions['clone_order'] = array(
				'url'       => $copy_link,
				'name'      => __( 'Clone Order', 'woo-order-splitter' ),
				'action'    => "wc_os_clone", 
			);	
		}
		
		if($conflict_status){			

			$actions['clone_order'] = array(
				'url'       => get_edit_post_link($order->get_id()),
				'name'      => __( 'Conflict Alert!', 'woo-order-splitter' ),
				'action'    => "wc_os_conflict", 
			);	
			
		}
		
		
		return $actions;
	}	
	
	function wos_clone_order_notes($original_order_id=0, $order_id=array()){
		//pree($original_order_id);
		//pree($order_id);exit;
		if($original_order_id && ((is_numeric($order_id) && $original_order_id != $order_id) || (is_array($order_id) && !in_array($original_order_id, $order_id)))){
			
			$order_id = (is_numeric($order_id)?array($order_id):$order_id);

			global $wpdb;		
			$comments_query = "SELECT * FROM $wpdb->comments WHERE comment_post_ID=$original_order_id ORDER BY comment_ID DESC";
			//wc_os_pree($comments_query);
			$original_order = wc_get_order($original_order_id);
			$comments_results = $wpdb->get_results($comments_query);
			//$orginal_order_post = get_posts(array('include'=>$original_order_id, 'post_type'=>'shop_order', 'post_status'=>'any'));
			//$orginal_order_post = (!empty($orginal_order_post)?current($orginal_order_post):'');
			//pree($original_order_id);
			//pree(get_post($original_order_id));
			//pree($orginal_order_post);
			//pree($original_order->customer_message);
			
			//wc_os_pree($comments_results);
			if(!empty($comments_results)){
				
				foreach($comments_results as $comments){


					unset($comments->comment_ID);
					if(!empty($order_id)){					
						foreach($order_id as $new_order_id){
							$comments->comment_post_ID = $new_order_id;
							$comments = (array)$comments;
							//wc_os_pree($comments);//exit;
							if(wp_insert_comment($comments)){
								//wc_os_pree($comments->comment_post_ID.' > Ok');
							}else{
								//wc_os_pree($comments->comment_post_ID.' > Failed');
							}
						}
					}
				}
			}
			//exit;

			if(!empty($order_id) && !empty($original_order) && $original_order->customer_message!=''){					
				foreach($order_id as $new_order_id){
					$my_order = array(
						  'ID'           => $new_order_id,
						  'post_excerpt' => $original_order->customer_message
					  );
					wp_update_post( $my_order );
				}
			}
			//exit;
			
		}
	}	
	
	function wc_os_random_color_part() {
		return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
	}
	
	function wc_os_random_color() {
		return wc_os_random_color_part() . wc_os_random_color_part() . wc_os_random_color_part();
	}	
	
	function wos_troubleshooting(){
		extract($_POST);
		$ret = array();
		$hex = '#'.wc_os_random_color();
		$ret['color_hex'] = $hex;
		list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");
		$ret['color'] = array('r'=>$r, 'g'=>$g, 'b'=>$b);
		$order_data = new WC_Order($order_id);
		$order_data->calculate_totals();
		
		$get_items = $order_data->get_items();
		
		
		
		$meta = get_post_meta($order_id);
		$wc_os_meta_keys = get_option('wc_os_meta_keys', array());
		
		$cloned_from = (isset($meta['cloned_from'])?$meta['cloned_from'][0]:false);
		$splitted_from = (isset($meta['splitted_from'])?$meta['splitted_from'][0]:false);
		
		
		$wc_os_meta_data = array(
			'parent_order' => (!$cloned_from && !$splitted_from)?'Yes':'No',
			'cloned_from' => $cloned_from?'<a target="_blank" href="'.get_edit_post_link($cloned_from).'">'.$cloned_from.'</a>':'-',
			'splitted_from' => $splitted_from?'<a target="_blank" href="'.get_edit_post_link($splitted_from).'">'.$splitted_from.'</a>':'-',
		);
				
		ob_start();
		
		foreach($get_items as $item_id=>$item_data){
			//wc_update_order_item_meta( $item_id, 'total_tax', 0 ); 
			//wc_os_pree($item_id);
			
			//wc_os_pree(get_metadata( 'order_item', $item_id, '_line_subtotal_tax'));
			//wc_os_pree(get_metadata( 'order_item', $item_id, '_line_tax'));
			//wc_os_pree(get_metadata( 'order_item', $item_id, '_line_tax_data'));

/*
			update_metadata( 'order_item', $item_id, '_line_subtotal_tax', 0);
			update_metadata( 'order_item', $item_id, '_line_tax_data', 0);
			update_metadata( 'order_item', $item_id, '_line_tax_data', array());
*/			
			
			//wc_os_pree($item_data);
			
			//wc_os_pree(wc_get_order_item_meta( $item_id ));

			//wc_update_order_item_meta( $item_id, '_line_subtotal_tax', 0 );
			//wc_update_order_item_meta( $item_id, '_line_tax', 0 );
			//wc_os_pree(wc_update_order_item_meta( $item_id, 'total_tax', 0 )); 
		}
		
		wc_os_pree($wc_os_meta_data);
		
		wc_os_pree($order_data);
		
		wc_os_pree($meta);		
		
		wc_os_pree($get_items);		
		
		$ret['html'] = ob_get_contents();
		ob_end_clean();
		
		
		$ret = json_encode($ret);
		echo $ret;
		exit;
	}
	
	add_action( 'wp_ajax_wos_troubleshooting', 'wos_troubleshooting' );
	
	
	function wos_auto_settings(){
		
		global $wc_os_settings;
		$wc_os_products = $wc_os_settings['wc_os_products'];
		$ret = array();
		
		$wc_os_ie = $_POST['wc_os_ie'];
		//pree($wc_os_ie);exit;
		//$products = wc_os_get_products();
		
		switch($wc_os_ie){
			default:
				
				$selected_items = $wc_os_products[$wc_os_ie];
				unset($wc_os_products[$wc_os_ie]);
				
				$ret = array($selected_items, $wc_os_products);
				
			break;
			
			case 'cats':
				
				$ret = $wc_os_settings['wc_os_cats']['cats'];
				
			break;
			
			
			case 'group_cats':
				
				$ret = $wc_os_settings['wc_os_cats']['group_cats'];
				
			break;
			
			
			case 'group_by_vendors':
				
				$ret = $wc_os_settings['wc_os_vendors'];
				
			break;		
							
		}
				
		
		/*
		if(!empty($products)){
			foreach($products as $prod){				
				$product = wc_get_product($prod->ID);
				$ticked = in_array($prod->ID, $wc_os_settings['wc_os_products']);
				$ret[] = array(
								'id'=>$prod->ID, 
								'stock'=>$product->managing_stock()?(($product->is_in_stock() && $product->get_stock_quantity()>0)?'<span class="green"><b>'.__('In', 'woo-order-splitter').'</b></span>':'<span class="red">'.__('Out', 'woo-order-splitter').'</span>'):'<small class="faded">'.__('N/A', 'woo-order-splitter').'</small>',
								'title_price'=>$prod->post_title.' '.$wc_os_currency.$product->get_price(),
								'edit_link'=>get_edit_post_link($prod->ID),
								'view_link'=>get_permalink($prod->ID)
						);
			}
		}*/
		
		
		$ret = json_encode($ret);
		echo $ret;
		exit;
	}	
	
	add_action( 'wp_ajax_wos_auto_settings', 'wos_auto_settings' );
	
	function wos_forced_ie(){
		if(isset($_POST['order_action'])){
			$order_id = $_POST['order_id'];
			$order_data = wc_get_order( $order_id );
			if(!empty($order_data)){
				update_post_meta($order_id, 'wos_forced_ie', $_POST['order_action']);
				update_post_meta($order_id, 'wc_os_order_splitter_cron', true);				
				delete_post_meta($order_id, 'conflict_status');
				delete_post_meta($order_id, 'split_status');

			}
		}
		exit;
	}
	
	add_action( 'wp_ajax_wos_forced_ie', 'wos_forced_ie' );
	
	function wpdocs_filter_wp_title( $title, $sep ) {
		global $paged, $page;
	 
		if ( is_feed() )
		return $title;
	 
		// Add the site name.
		$title .= get_bloginfo( 'name' );
	 
		// Add the site description for the home/front page.
		$site_description = get_bloginfo( 'description', 'display' );
		if ( $site_description && ( is_home() || is_front_page() ) )
			$title = "$title $sep $site_description";
	 
		// Add a page number if necessary.
		if ( $paged >= 2 || $page >= 2 )
			$title = "$title $sep " . sprintf( __( 'Page %s', 'twentytwelve' ), max( $paged, $page ) );
	 
		return $title;
	}	
	
	add_filter( 'wp_title', 'wpdocs_filter_wp_title', 10, 2 );
	
	function wos_cart_notices($content=''){
		
		global $wos_notices_css;
		//pree($_SERVER);
		$notice_text = '';
		
		$wos_cart_notices = get_option( 'wc_os_cart_notices', true);
		$page_type = '';
		
		if(is_cart()){
			$notice_text = $wos_cart_notices['cart'];
			$page_type = 'cart';
		}if(is_checkout()){
			$notice_text = $wos_cart_notices['checkout'];
			$page_type = 'checkout';
		}if(is_product()){
			$notice_text = $wos_cart_notices['product'];
			$page_type = 'product';
		}if(is_shop()){
			$notice_text = $wos_cart_notices['shop'];
			$page_type = 'shop';
		}
		
		$wos_notices_css = ((isset($wos_cart_notices['styles']) && $wos_cart_notices['styles']!='')?$wos_cart_notices['styles']:$wos_notices_css);
		
		if($notice_text){
			$notice_text = '<style type="text/css">							
							'.$wos_notices_css.'
							</style><div class="wos_notice_div wos_'.$page_type.'">'.$notice_text.'</div>
							
							
							
							<script type="text/javascript" language="javascript">
								jQuery(document).ready(function($){
									if($(".wos_notice_div.wos_product").length>1)
									$(".wos_notice_div.wos_product").eq(0).remove();
									
									if($(".wos_notice_div.wos_product").length>0)
									$(".wos_notice_div.wos_product").eq(0).show();
									
								});
							</script>							
							';
		}
		
		if(is_product()){
			return $notice_text.$content;
		}elseif(is_shop()){
			echo $notice_text.$content;
		}else{
			return $content;
		}
	}
		
	add_filter('the_content', 'wos_cart_notices', 20);	
	
	add_filter('woocommerce_before_main_content', 'wos_cart_notices', 5);
	
	add_filter('woocommerce_before_single_product', 'wos_cart_notices', 10);
	
	/*
	add_action('init', 'post_modify');
	function post_modify(){
		$post = $_GET['post'];
		if($post==5020){
			$order = wc_get_order($post);
			foreach($order->get_items() as $item_key=>$item_data){
				$item_data['quantity'] = $item_data['quantity'] - 1 ;
				$order->save();
			}
		}
	}*/
	
	function wos_filter_woocommerce_can_reduce_order_stock( $true, $instance ) { 
		return false; 
	}
	