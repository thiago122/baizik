<?php
	
	function wos_email_notification($pref=array(), $action='split'){
		$ret = false;
		$myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
		$wos_cart_notices = get_option( 'wc_os_cart_notices', true);
		if ( $myaccount_page_id ) {
			$myaccount_page_url = get_permalink( $myaccount_page_id );
		}		
		$to = '';
		$subject = '';
		$display_name = '';
		$body = 'USER_NAME,<br><br>BODY_1BODY_2BODY_3<br><br>'.get_bloginfo('name').'<br>'.get_bloginfo('description').'<br>'.get_bloginfo('wpurl');
		switch($action){
			case 'combine':
				$subject = __('Following orders are combined into order#', 'woo-order-splitter').' '.$pref['new'];
				$body_1 = __('Following orders are combined into one order#', 'woo-order-splitter').' <a href="'.$myaccount_page_url.'view-order/'.$pref['new'].'">'.$pref['new'].'</a>';
				$body_1 .= '<br><br><ul>';
				$order_id = 0;

				if(!empty($pref['original'])){
					foreach($pref['original'] as $order_id){
						//$original_order = new WC_Order($orderid);
						//echo $order_id.'<br>';
						$post_author_id = get_post_field( 'post_author', $order_id );
						$body_1 .= '<li>Order# <a href="'.$myaccount_page_url.'view-order/'.$order_id.'">'.$order_id.'</a></li>';
					}
				}	

				$body_1 .= '</ul><br><br>';
				
				$body_2 = __('Order items will remain intact, same product (items) will be merged and quantity will be incremented.', 'woo-order-splitter').'<br><br>';
				
				$body_3 = '<a href="'.$myaccount_page_url.'orders'.'">'.__('Click here', 'woo-order-splitter').'</a> '.__('to check your orders status in your account.', 'woo-order-splitter').'';
					
				//pree($post_author_id);
				$post_author = get_userdata( $post_author_id );
				
				
				
				
				
				
				if(get_option('wc_os_order_combine_email', 0)){
					
					if(!empty($post_author) && isset($post_author->user_email)){
						$to = $post_author->user_email;
						$display_name = strtoupper($post_author->display_name);
					}else{
						$any_order = wc_get_order($order_id);
						if(!empty($any_order)){
							$to = $any_order->get_billing_email();
							$display_name = ($display_name?$display_name:$any_order->get_formatted_billing_full_name());
						}
					}
					
					
				}
				
				$body = str_replace(array('USER_NAME', 'BODY_1', 'BODY_2', 'BODY_3'), array($display_name, $body_1, $body_2, $body_3), $body);
				//pree($body);
			break;
			case 'split':

				$order_id = 0;
				//pree($pref);exit;
				$subject = __('Order#', 'woo-order-splitter').' '.$pref['original'].' '.__('splitted into', 'woo-order-splitter').' '.count($pref['new']).' '.'new order'.(count($pref['new'])>1?'s':'');
				if(isset($wos_cart_notices['co_esubject']) && $wos_cart_notices['co_esubject']!=''){
					$subject = str_replace(array('ORDER_ID', 'ORDER_COUNT'), array($pref['original'], count($pref['new'])), $wos_cart_notices['co_esubject']);
				}
				
				$body_1 = $subject.' ORDERS_TABLE';
				if(isset($wos_cart_notices['co_ebody']) && trim($wos_cart_notices['co_ebody'])!=''){
					$body_1 = $wos_cart_notices['co_ebody'];
				}
				
				//$body_1 .= '<br><br><ul>';
				//pree($pref);exit;
				$post_author_id = 0;
				if(isset($pref['new']) && !empty($pref['new'])){
					//pree($pref);exit;
					$order_received_text = trim(__wos_change_order_received_text($pref['original']));
					$post_author_id = get_post_field( 'post_author', $pref['original'] );
					
					if(!$order_received_text){
						update_post_meta($pref['original'], '_wos_consider_split_email', true);
					}else{
						$order_received_text = ($order_received_text?'<br /><br /><br />'.$order_received_text.'<br /><br /><br />':'');
						//pree($order_received_text);
						$body_1 = str_replace(array('ORDERS_TABLE', 'ORDER_ID', 'ORDER_COUNT'), array($order_received_text, $pref['original'], count($pref['new'])), $body_1);
						//pree($body_1);exit;
						foreach($pref['new'] as $order_id){
							//$original_order = new WC_Order($orderid);
							//echo $order_id.'<br>';
							if(!$post_author_id){
								$post_author_id = get_post_field( 'post_author', $order_id );
							}
							//$body_1 .= '<li>Order# <a href="'.$myaccount_page_url.'view-order/'.$order_id.'">'.$order_id.'</a></li>';
						}
					}
				}	

				//$body_1 .= '</ul><br><br>';
				
				$body_2 = '';//__('Order items are intact with respective quantities.', 'woo-order-splitter').'<br><br>';
				
				$body_3 = '<a href="'.$myaccount_page_url.'orders'.'">'.__('Click here', 'woo-order-splitter').'</a> '.__('to check your orders status in your account.', 'woo-order-splitter').'';
					
				//pree($post_author);	
				//pree($post_author_id);
				if($post_author_id){
					
					$post_author = get_userdata( $post_author_id );
					
					if(get_option('wc_os_order_split_email', 0)){
						if(!empty($post_author) && isset($post_author->user_email)){
							$to = $post_author->user_email;
							$display_name = strtoupper($post_author->display_name);
						}else{
							$any_order = wc_get_order($order_id);
							if(!empty($any_order)){
								$to = $any_order->get_billing_email();
								$display_name = ($display_name?$display_name:$any_order->get_formatted_billing_full_name());
							}
						}
					}
					
					$body = str_replace(array('USER_NAME', 'BODY_1', 'BODY_2', 'BODY_3'), array($display_name, $body_1, $body_2, $body_3), $body);
				}
				
			break;

		}
		

		$co_efrom_name = ((isset($wos_cart_notices['co_efrom_name']) && $wos_cart_notices['co_efrom_name']!='')?$wos_cart_notices['co_efrom_name']:get_bloginfo('name'));
		$co_efrom_email = ((isset($wos_cart_notices['co_efrom_email']) && $wos_cart_notices['co_efrom_email']!='')?$wos_cart_notices['co_efrom_email']:get_bloginfo('admin_email'));
		$co_ereplyto_email = ((isset($wos_cart_notices['co_ereplyto_email']) && $wos_cart_notices['co_ereplyto_email']!='')?$wos_cart_notices['co_ereplyto_email']:get_bloginfo('admin_email'));
		
		$headers = array(
						'Content-Type: text/html; charset=UTF-8',
						'From: '.$co_efrom_name.' <'.$co_efrom_email.'>',
						'Reply-To: '.get_bloginfo('name').' <'.$co_ereplyto_email.'>'
					);

		//pree($to);
		//pree(email_exists($to));
		//pree($subject);
		//pree($body);exit;
		
		if(email_exists($to) || is_email($to)){
			$ret = wp_mail( $to, $subject, $body, $headers );
		}
		return $ret;
		
	}
	/**
	 * Unhook and remove WooCommerce default emails.
	 */
	 
	add_action( 'woocommerce_email', 'unhook_wos_emails' );
	
	function unhook_wos_emails( $email_class ) {
	
			/**
			 * Hooks for sending emails during store events
			 **/
			 
			$disable_backorder_mail_notification = get_option( 'wc_os_backorder_mail_notification', 0 );

			if($disable_backorder_mail_notification) {
				// unhooks sending email backorders during store events
				remove_action( 'woocommerce_low_stock_notification', array( $email_class, 'low_stock' ) );
				remove_action( 'woocommerce_no_stock_notification', array( $email_class, 'no_stock' ) );				
				remove_action( 'woocommerce_product_on_backorder_notification', array( $email_class, 'backorder' ) );
			}
			
			//remove_action( 'woocommerce_low_stock_notification', array( $email_class, 'low_stock' ) );
			//remove_action( 'woocommerce_no_stock_notification', array( $email_class, 'no_stock' ) );
			//remove_action( 'woocommerce_product_on_backorder_notification', array( $email_class, 'backorder' ) );
			
			// New order emails
			//remove_action( 'woocommerce_order_status_pending_to_processing_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_pending_to_completed_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_pending_to_on-hold_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_failed_to_processing_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_failed_to_completed_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_failed_to_on-hold_notification', array( $email_class->emails['WC_Email_New_Order'], 'trigger' ) );
			
			// Processing order emails
			//remove_action( 'woocommerce_order_status_pending_to_processing_notification', array( $email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger' ) );
			//remove_action( 'woocommerce_order_status_pending_to_on-hold_notification', array( $email_class->emails['WC_Email_Customer_Processing_Order'], 'trigger' ) );
			
			// Completed order emails
			//remove_action( 'woocommerce_order_status_completed_notification', array( $email_class->emails['WC_Email_Customer_Completed_Order'], 'trigger' ) );
				
			// Note emails
			//remove_action( 'woocommerce_new_customer_note_notification', array( $email_class->emails['WC_Email_Customer_Note'], 'trigger' ) );
	}	