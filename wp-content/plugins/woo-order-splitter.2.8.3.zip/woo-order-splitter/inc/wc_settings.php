<?php defined( 'ABSPATH' ) or die( __('No script kiddies please!', 'woo-order-splitter') );
	if ( !current_user_can( 'administrator' ) ) {
		wp_die( __( 'You do not have sufficient permissions to access this page.', 'woo-order-splitter' ) );
	}

	global $wpdb, $wc_os_data, $wc_os_pro, $wc_os_activated, $wc_os_settings, $wc_os_currency, $wc_os_premium_copy, $wos_actions_arr, $wc_os_cust, $wos_notices_css;//, $wc_os_active_plugins;
	
	$wc_os_cust = get_option( 'wc_os_cuztomization', array() );
	//wc_os_pree($wc_os_active_plugins);
	//wc_os_pree($wc_os_activated);
	//wc_os_pree($wc_os_settings);
	//pree($wc_os_settings['wc_os_ie']);

?>


<div class="wrap wc_settings_div">

        



        <div class="icon32" id="icon-options-general"><br></div><h2><?php echo $wc_os_data['Name']; ?> <?php echo '('.$wc_os_data['Version'].($wc_os_pro?') Pro':')'); ?> - <?php _e("Settings","woo-order-splitter"); ?> <?php if(!$wc_os_pro){ ?><a class="gopro" target="_blank" href="<?php echo $wc_os_premium_copy; ?>"><?php _e("Go Premium","woo-order-splitter"); ?></a><?php } ?></h2> 
    
         
           
        <h2 class="nav-tab-wrapper">
            <a class="nav-tab nav-tab-active"><?php _e("General Settings","woo-order-splitter"); ?></a>
            
            <a class="nav-tab"><?php _e("Automatic Settings","woo-order-splitter"); ?></a>
            <a class="nav-tab"><?php _e("Customization","woo-order-splitter"); ?></a>
            <?php //if($wc_os_pro): ?>
            <a class="nav-tab" id="wc_os_rules"><?php _e("Rules","woo-order-splitter"); ?></a>
            <?php /* <a class="nav-tab" id="wc_os_meta_keys"><?php _e("Order Meta Keys","woo-order-splitter"); ?></a> */ ?>
            <?php //endif; ?>
            
            <a class="nav-tab" id="wc_os_meta_keys"><?php _e("Troubleshoot","woo-order-splitter"); ?></a>
        </h2>      



<?php if(!$wc_os_activated): ?>
<div class="wc_os_notes">
<h2><?php _e("You need WooCommerce plugin to be installed and activated.","woo-order-splitter"); ?> <?php _e("Please","woo-order-splitter"); ?> <a href="plugin-install.php?s=woocommerce&tab=search&type=term" target="_blank"><?php _e("Install","woo-order-splitter"); ?></a> <?php _e("and","woo-order-splitter"); ?>/<?php _e("or","woo-order-splitter"); ?> <a href="plugins.php?plugin_status=inactive" target="_blank"><?php _e("Activate","woo-order-splitter"); ?></a> WooCommerce <?php _e("plugin to proceed","woo-order-splitter"); ?>.</h2>
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
<br />
</div>
<?php exit; endif; ?>



<form class="nav-tab-content" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<?php wp_nonce_field( 'wc_os_settings_action', 'wc_os_settings_field' ); ?>


<div class="wc_os_optional">


<h3><?php _e("Optional","woo-order-splitter"); ?></h3>

    <fieldset>

        <ul>

		<li <?php echo(get_option('wc_os_auto_forced', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_auto_forced" name="wc_os_auto_forced" type="checkbox" value="1" <?php echo(get_option('wc_os_auto_forced', 0)?'checked="checked"':''); ?> /><label for="wc_os_auto_forced"><?php _e("Auto Split","woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>

        </li>
        
		<li <?php echo(get_option('wc_os_auto_clone', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_auto_clone" name="wc_os_auto_clone" type="checkbox" value="1" <?php echo(get_option('wc_os_auto_clone', 0)?'checked="checked"':''); ?> /><label for="wc_os_auto_clone"><?php _e("Auto Clone","woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>

        </li>

        <li <?php echo(get_option('wc_os_billing_off', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_billing_off" name="wc_os_billing_off" type="checkbox" value="1" <?php echo(get_option('wc_os_billing_off', 0)?'checked="checked"':''); ?> /><label for="wc_os_billing_off"><?php _e("Hide Billing Details","woo-order-splitter"); ?> <strong><?php _e("On","woo-order-splitter"); ?></strong>/<strong><?php _e("Off","woo-order-splitter"); ?></strong></label>

        </li>

        <li <?php echo(get_option('wc_os_shipping_off', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_shipping_off" name="wc_os_shipping_off" type="checkbox" value="1" <?php echo(get_option('wc_os_shipping_off', 0)?'checked="checked"':''); ?> /><label for="wc_os_shipping_off"><?php _e("Hide Shipping Details","woo-order-splitter"); ?> <strong><?php _e("On","woo-order-splitter"); ?></strong>/<strong><?php _e("Off","woo-order-splitter"); ?></strong></label>

        </li>
        
		<li <?php echo(get_option('wc_os_shipping_cost', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_shipping_cost" name="wc_os_shipping_cost" type="checkbox" value="1" <?php echo(get_option('wc_os_shipping_cost', 0)?'checked="checked"':''); ?> /><label for="wc_os_shipping_cost"><?php _e("Add Shipping Cost","woo-order-splitter"); ?> <strong><?php _e("No","woo-order-splitter"); ?></strong>/<strong><?php _e("Yes","woo-order-splitter"); ?></strong></label>

        </li>        

        <li <?php echo(get_option('wc_os_order_comments_off', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_order_comments_off" name="wc_os_order_comments_off" type="checkbox" value="1" <?php echo(get_option('wc_os_order_comments_off', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_comments_off"><?php _e("Order Comments","woo-order-splitter"); ?> <strong><?php _e("On","woo-order-splitter"); ?></strong>/<strong><?php _e("Off","woo-order-splitter"); ?></strong></label>

        </li>
        
        <li <?php echo(get_option('wc_os_backorder_mail_notification', 0)?'class="selected"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_backorder_mail_notification" name="wc_os_backorder_mail_notification" type="checkbox" value="1" <?php echo(get_option('wc_os_backorder_mail_notification', 0)?'checked="checked"':''); ?> /><label for="wc_os_backorder_mail_notification" title="<?php echo __( 'Don\'t send email notifications when a backorder is made.', "woo-order-splitter" ); ?>"><?php echo __( 'Disable backorder email notifications', "woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></a></label>

        </li>
        
        <li <?php echo(get_option('wcbm_backorder_mail_notification', 0)?'class="selected"':''); ?> <?php echo (!$wc_os_pro?'class="wc_os_premium"':''); ?>>

        <input class="wc_os_checkout_options" id="wc_os_order_title_splitted" name="wc_os_order_title_splitted" type="checkbox" value="1" <?php echo(get_option('wc_os_order_title_splitted', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_title_splitted"><?php _e("Order Titles Splitted","woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong> <a href="https://youtu.be/6QKnpC2xcoM" target="_blank"><small><?php _e('Video Tutorial', 'woo-order-splitter'); ?></small></a></label>

        </li>
          
        <?php if(function_exists('wos_email_notification')): ?>
        <li class="wos_emails_settings">
            <strong><?php _e('Send email notifications to customer', 'woo-order-splitter'); ?>:</strong>    
            <ul>
                <li <?php echo(get_option('wc_os_order_combine_email', 0)?'class="selected"':''); ?>>
        
                <input class="wc_os_checkout_options" id="wc_os_order_combine_email" name="wc_os_order_combine_email" type="checkbox" value="1" <?php echo(get_option('wc_os_order_combine_email', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_combine_email"><?php _e("Orders Combined","woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>
        
                </li> 
				<li <?php echo(get_option('wc_os_order_split_email', 0)?'class="selected"':''); ?>>
        
                <input class="wc_os_checkout_options" id="wc_os_order_split_email" name="wc_os_order_split_email" type="checkbox" value="1" <?php echo(get_option('wc_os_order_split_email', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_split_email"><?php _e("Orders Splitted","woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>
        
                </li>                          
            </ul>
        </li>
        <?php endif; ?>
                   
        
        <li <?php echo(get_option('wc_os_order_splitf_column', 0)?'class="selected"':''); ?> <?php echo (!$wc_os_pro?'class="wc_os_premium"':''); ?>>

        <input class="wc_os_checkout_options" <?php echo (!$wc_os_pro?'disabled="disabled"':''); ?> id="wc_os_order_splitf_column" name="wc_os_order_splitf_column" type="checkbox" value="1" <?php echo(get_option('wc_os_order_splitf_column', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_splitf_column"><?php _e('"Split From" Column',"woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>

        </li> 
        
        <li <?php echo(get_option('wc_os_order_clonef_column', 0)?'class="selected"':''); ?> <?php echo (!$wc_os_pro?'class="wc_os_premium"':''); ?>>

        <input class="wc_os_checkout_options" <?php echo (!$wc_os_pro?'disabled="disabled"':''); ?> id="wc_os_order_clonef_column" name="wc_os_order_clonef_column" type="checkbox" value="1" <?php echo(get_option('wc_os_order_clonef_column', 0)?'checked="checked"':''); ?> /><label for="wc_os_order_clonef_column"><?php _e('"Parent Order" Column',"woo-order-splitter"); ?> <strong><?php _e("Off","woo-order-splitter"); ?></strong>/<strong><?php _e("On","woo-order-splitter"); ?></strong></label>

        </li>        
        
        
        <li></li><li></li><li></li>

        <li><iframe width="300" height="150" src="https://www.youtube.com/embed/wjClFEeYEzo" style="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></li>          
        
        <li><iframe width="300" height="150" src="https://www.youtube.com/embed/tOT4l7_GCIw" style="" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></li>            
        <li></li>

        </ul>

    </fieldset>


</div>


<br />
<div class="wc_os_notes"></div>


<table class="wos_general">
<tbody>
<?php	
		
		$cloning = in_array('cloning', $wc_os_settings['wc_os_additional']);

?>
<tr>
<td colspan="2"><?php _e('Order cloning is an for bulk action dropdown and orders list.', 'woo-order-splitter'); ?></td>
</tr>
<tr>
<td><input id="wip-cloning" <?php checked($cloning); ?> type="checkbox" name="wc_os_settings[wc_os_additional][]" value="cloning" /></td>
<td><label for="wip-cloning"><?php _e('Enable order duplication or cloning', 'woo-order-splitter'); ?></label>
</td>
</tr>


<?php	
		
		$disable_split = in_array('split', $wc_os_settings['wc_os_additional']);
		$split_lock = (isset($wc_os_settings['wc_os_additional']['split_lock'])?$wc_os_settings['wc_os_additional']['split_lock']:'');

		//$split_status_lock = in_array('split_status_lock', $wc_os_settings['wc_os_additional']);
		//$split_status_lock = (isset($wc_os_settings['wc_os_additional']['split_status_lock'])?$wc_os_settings['wc_os_additional']['split_status_lock']:'');
		$split_status_value = wc_os_order_split_status_action();
?>
<tr>
<td colspan="2"><?php //echo wc_os_order_split_status_action(); echo $split_status_lock; ?>
<div class="split_lock_bars">
<strong><?php _e('Splitting order is a default feature so it is activated by default. You can deactivate it if need.', 'woo-order-splitter'); ?></strong><br />
&nbsp;&nbsp;&nbsp;<input id="wip-split" <?php checked($disable_split); ?> type="checkbox" name="wc_os_settings[wc_os_additional][]" value="split" />
<label for="wip-split"><?php _e('Disable split order option', 'woo-order-splitter'); ?></label>
<?php if(!$disable_split): 
$wc_os_order_statuses = wc_get_order_statuses(); 
$wc_os_order_statuses_keys = array_keys($wc_os_order_statuses);
?>
<div class="inner_split_lock">
<br /><br />


<strong><?php _e('Split lock, so split aciton will not work until this condition will be true.', 'woo-order-splitter'); ?></strong>
<br />
&nbsp;&nbsp;&nbsp;<select name="wc_os_settings[wc_os_additional][split_lock]">
<option value=""><?php _e('No Lock (Default)', 'woo-order-splitter'); ?></option>
<?php foreach($wc_os_order_statuses_keys as $order_status){ $order_status = str_replace('wc-','', $order_status); ?>
<option value="<?php echo $order_status; ?>" <?php selected($order_status==$split_lock); ?>><?php echo __('Split', 'woo-order-splitter').' '.str_replace('WC-', '', (strtoupper($order_status))).' '.__('Orders', 'woo-order-splitter').' '.__('Only', 'woo-order-splitter'); ?></option>
<?php } ?>
</select>
</div>

<strong><?php _e('And splitted order(s) can be updated with a different available order status.', 'woo-order-splitter'); ?></strong>
<br />
&nbsp;&nbsp;&nbsp;<select name="wc_os_settings[wc_os_additional][split_status_lock]">
<option value=""><?php _e('Default', 'woo-order-splitter'); ?></option>
<?php foreach($wc_os_order_statuses_keys as $order_status){ ?>
<option value="<?php echo $order_status; ?>" <?php selected($order_status==$split_status_value); ?>><?php echo __('Change', 'woo-order-splitter').' to '.str_replace('WC-', '', (strtoupper($order_status))); ?></option>
<?php } ?>
</select>

<?php endif; ?>
</div>
</td>
</tr>
<?php	
		
		$removal = in_array('removal', $wc_os_settings['wc_os_additional']);
		$removal_lock = (isset($wc_os_settings['wc_os_additional']['removal_lock'])?$wc_os_settings['wc_os_additional']['removal_lock']:'');


?>






<tr>
<td colspan="2">
<div class="order_removal_bars">
<strong><?php _e('Order removal is an optional feature, once order has been splitted so original order can be removed.', 'woo-order-splitter'); ?></strong><br />
&nbsp;&nbsp;&nbsp;<input id="wip-removal" <?php checked($removal); ?> type="checkbox" name="wc_os_settings[wc_os_additional][]" value="removal" />
<label for="wip-removal"><?php _e('Enable original order removal on splitting', 'woo-order-splitter'); ?></label>
<?php if(!$removal): 
$wc_os_order_statuses = wc_get_order_statuses(); 
$wc_os_order_statuses_keys = array_keys($wc_os_order_statuses);
?>
<div class="inner_removal_lock">
<br /><br /><?php //pree(wc_os_order_removal_action()); ?>
<strong><?php _e('Alternatively, orginal order can be updated with a different available order status.', 'woo-order-splitter'); ?></strong>
<br />
&nbsp;&nbsp;&nbsp;<select name="wc_os_settings[wc_os_additional][removal_lock]">
<option value=""><?php _e('Default', 'woo-order-splitter'); ?></option>
<?php foreach($wc_os_order_statuses_keys as $order_status){ ?>
<option value="<?php echo $order_status; ?>" <?php selected($order_status==$removal_lock); ?>><?php echo __('Change', 'woo-order-splitter').' to '.str_replace('WC-', '', (strtoupper($order_status))); ?></option>
<?php } ?>
</select>


</div>
<?php endif; ?>
</div>
</td>
</tr>





<?php
		$remove_combined = in_array('remove_combined', $wc_os_settings['wc_os_additional']);
?>		

<?php if($wc_os_pro): ?>
<tr>
<td colspan="2"><br />
<br />
<?php _e('Consolidated/Merged/Combined orders should be removed after action.', 'woo-order-splitter'); ?> - <a href="https://www.youtube.com/embed/qrZMZAuv-VU" target="_blank"><?php echo __('Watch Tutorial', 'woo-order-splitter'); ?></a></td>
</tr>
<tr>
<td><input id="wip-combine-remove" <?php checked($remove_combined); ?> type="checkbox" name="wc_os_settings[wc_os_additional][]" value="remove_combined" /></td>
<td><label for="wip-combine-remove"><?php _e('Enable original order removal on consolidation', 'woo-order-splitter'); ?></label>
</td>
</tr>
<?php endif; ?>

</tbody>
</table>	

<input type="hidden" name="wc_os_settings[wc_os_additional][]" value="0" />
<p class="submit"><input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>



</form>

<form class="nav-tab-content hide" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<a href="https://www.youtube.com/embed/tOT4l7_GCIw" target="_blank" style="float:right;"><?php _e('Video Tutorial', 'woo-order-splitter'); ?></a>
<?php wp_nonce_field( 'wc_os_settings_action', 'wc_os_settings_field' ); ?>





<br />
<div class="wc_os_notes"><h3><?php _e('Configure automatic split action and products based trigger:', 'woo-order-splitter'); ?></h3></div>

<div class="wc_os_ahead">
<?php
	//wc_os_pree($wc_os_settings);
	//pree($wc_os_settings['wc_os_qty_split_option']);
?>
<ul class="wc_os_ie_wrapper">
<li class="wc_os_ie_products">
<label for="wc_os_ie_products"><input type="radio" value="default" id="wc_os_ie_products" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='default'); ?> /><?php echo _e('Product Based', 'woo-order-splitter'); ?> <i>(<?php echo split_actions_display('default', 'title'); ?> | <?php echo split_actions_display('exclusive', 'title'); ?> | <?php echo split_actions_display('inclusive', 'title'); ?> | <?php echo split_actions_display('shredder', 'title'); ?> | <?php echo split_actions_display('io', 'title'); ?> | <?php echo split_actions_display('quantity_split', 'title'); ?>)</i></label>
<ul>
<li class="wc_os_ie_one"><label for="wc_os_ie_one"><input type="radio" value="default" id="wc_os_ie_one" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='default'); ?> /><?php echo split_actions_display('default', 'title'); ?> <i>(<?php echo split_actions_display('default', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-2.png" target="_blank"></a></li>

<li class="wc_os_ie_two"><label for="wc_os_ie_two"><input type="radio" value="exclusive" id="wc_os_ie_two" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='exclusive'); ?> /><?php echo split_actions_display('exclusive', 'title'); ?> <i>(<?php echo split_actions_display('exclusive', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-3.png" target="_blank"></a></li>

<li class="wc_os_ie_three"><label for="wc_os_ie_three"><input type="radio" value="inclusive" id="wc_os_ie_three" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='inclusive'); ?> /><?php echo split_actions_display('inclusive', 'title'); ?> <i>(<?php echo split_actions_display('inclusive', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-4.png" target="_blank"></a></li>

<li class="wc_os_ie_four"><label for="wc_os_ie_four"><input type="radio" value="shredder" id="wc_os_ie_four" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='shredder'); ?> /><?php echo split_actions_display('shredder', 'title'); ?> <i>(<?php echo split_actions_display('shredder', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-5.png" target="_blank"></a></li>

<li class="wc_os_ie_five <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>"><label for="wc_os_ie_five"><input type="radio" <?php disabled(!$wc_os_pro); ?> value="io" id="wc_os_ie_five" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='io' && $wc_os_pro); ?> /><?php echo split_actions_display('io', 'title'); ?> <i>(<?php echo split_actions_display('io', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-6.png" target="_blank"></a></li>

<li class="wc_os_ie_seven <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>"><label for="wc_os_ie_seven"><input type="radio" <?php disabled(!$wc_os_pro); ?> value="quantity_split" id="wc_os_ie_seven" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='quantity_split' && $wc_os_pro); ?> /><?php echo split_actions_display('quantity_split', 'title'); ?> <i>(<?php echo split_actions_display('quantity_split', 'description'); ?>)</i></label> <div class="qty_split_options">
<a title="<?php _e('Default (All qty. to x1) - Video Tutorial', 'woo-order-splitter'); ?>" class="split_auto" href="https://www.youtube.com/embed/vspbAX8Krx4" target="_blank"></a> &nbsp; <a title="<?php _e('Custom (Split only defined values) - Video Tutorial', 'woo-order-splitter'); ?>" class="split_custom" href="https://www.youtube.com/embed/7m05fzIQlqY" target="_blank"></a>
<select name="wc_os_settings[wc_os_qty_split_option]">
	<option value="default" <?php selected($wc_os_settings['wc_os_qty_split_option']=='default'); ?>><?php _e('Default (All qty. to x1)', 'woo-order-splitter'); ?></option>
    <option value="custom" <?php selected($wc_os_settings['wc_os_qty_split_option']=='custom'); ?>><?php _e('Custom (Split only defined values)', 'woo-order-splitter'); ?></option>
    <option value="eric_logic" <?php selected($wc_os_settings['wc_os_qty_split_option']=='eric_logic'); ?>><?php _e('Eric Logic (Selected+Defined items/quantity into new order)', 'woo-order-splitter'); ?></option>
</select>
</div><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-7.png" target="_blank"></a></li>


</ul>

</li>

<li style="display:none" class="wc_os_ie_six noproducts <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>"><label for="wc_os_ie_six"><input data-title="<?php echo split_actions_display('cats', 'title'); ?>" type="radio" <?php disabled(!$wc_os_pro); ?> value="cats" id="wc_os_ie_six" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='cats' && $wc_os_pro); ?> /><?php echo split_actions_display('cats', 'title'); ?> <i>(<?php echo split_actions_display('cats', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-8.png" target="_blank"></a></li>

<li class="wc_os_ie_nine noproducts <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>">
<label for="wc_os_ie_nine"><input data-title="<?php echo split_actions_display('group_cats', 'title'); ?>" type="radio" <?php disabled(!$wc_os_pro); ?> value="group_cats" id="wc_os_ie_nine" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='cats' && $wc_os_pro); ?> /><?php echo split_actions_display('group_cats', 'title'); ?> <i>(<?php echo split_actions_display('group_cats', 'description'); ?>)</i></label>
<div class="qty_split_options">
<a title="<?php echo split_actions_display('group_cats', 'title').' - '.__('Video Tutorial', 'woo-order-splitter'); ?>" class="split_auto" href="https://www.youtube.com/embed/HvnF9uvRsGQ" target="_blank"></a>
</div>
<a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-9.png" target="_blank"></a></li>

<li class="wc_os_ie_eight <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>"><label for="wc_os_ie_eight"><input data-title="<?php echo split_actions_display('groups', 'title'); ?>" type="radio" <?php disabled(!$wc_os_pro); ?> value="groups" id="wc_os_ie_eight" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='cats' && $wc_os_pro); ?> /><?php echo split_actions_display('groups', 'title'); ?> <i>(<?php echo split_actions_display('groups', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-10.png" target="_blank"></a></li>

<li class="wc_os_ie_ten noproducts nocategories <?php echo (!$wc_os_pro)?'wc_os_premium':''; ?>"><label for="wc_os_ie_ten"><input data-title="<?php echo split_actions_display('group_by_vendors', 'title'); ?>" type="radio" <?php disabled(!$wc_os_pro); ?> value="group_by_vendors" id="wc_os_ie_ten" name="wc_os_settings[wc_os_ie]" <?php //checked($wc_os_settings['wc_os_ie']=='cats' && $wc_os_pro); ?> /><?php echo split_actions_display('group_by_vendors', 'title'); ?> <i>(<?php echo split_actions_display('group_by_vendors', 'description'); ?>)</i></label><a class="wos-va" href="//ps.w.org/woo-order-splitter/assets/screenshot-1.png" target="_blank"></a></li>
</ul>


</div>

<?php switch($wc_os_settings['wc_os_ie']){ default: ?>

<div class="wc_os_notes"><h3><?php _e('Select products to trigger the above selected split order action', 'woo-order-splitter'); ?>:</h3></div>

<?php
	$products = wc_os_get_products();
	
	$product_categories = wc_os_get_product_categories();
	
	$wc_os_products_ids = $wc_os_settings['wc_os_products'];
	//pree($wc_os_products_ids);
	if(array_key_exists($wc_os_settings['wc_os_ie'], $wc_os_products_ids)){
		$wc_os_products_ids = $wc_os_settings['wc_os_products'][$wc_os_settings['wc_os_ie']];
	}
	
	//pree($products);
	//pree($product_categories);
	
	 

	
	if(!empty($products)){
		

?>
<div class="wos_loading"></div>
<table border="0" class="wos_products_list">
<thead>
<th><input <?php checked(isset($wc_os_settings['wc_os_all_product']) && $wc_os_settings['wc_os_all_product']=='all_products')?> id="wc_os_all_product" name="wc_os_settings[wc_os_all_product]" type="checkbox" value="all_products" title="<?php _e('All products listed and all future products added.','woo-order-splitter'); ?>" /></th>
<th><?php _e('Stock', 'woo-order-splitter'); ?></th>
<th><?php _e('Product Name', 'woo-order-splitter'); ?></th>
<th><?php _e('Category', 'woo-order-splitter'); ?></th>
<th><?php _e('Order Split Action', 'woo-order-splitter'); ?></th>
<th><?php _e('Product Actions', 'woo-order-splitter'); ?></th>
</thead>
<tbody>
<?php	
		$wc_os_ie_name = ($wc_os_settings['wc_os_ie']?'wc_os_settings[wc_os_products]['.$wc_os_settings['wc_os_ie'].'][]':'wc_os_settings[wc_os_products][]');
		//wc_os_pree($wc_os_settings['wc_os_products']);
		$groups_arr = range('A', 'Z');
		
		foreach($products as $prod){
			$product = wc_get_product($prod->ID);
			//wc_os_pree($product);
			//wc_os_pree($product->managing_stock().' ~ '.$product->is_in_stock());

			
			
			$default_ticked = (isset($wc_os_settings['wc_os_products']['default']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['default']))?true:false);
			$exclusive_ticked = (isset($wc_os_settings['wc_os_products']['exclusive']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['exclusive']))?true:false);
			$inclusive_ticked = (isset($wc_os_settings['wc_os_products']['inclusive']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['inclusive']))?true:false);
			$shredder_ticked = (isset($wc_os_settings['wc_os_products']['shredder']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['shredder']))?true:false);
			$io_ticked = (isset($wc_os_settings['wc_os_products']['io']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['io']))?true:false);
			$qty_ticked = (isset($wc_os_settings['wc_os_products']['quantity_split']) && in_array($prod->ID, ($wc_os_settings['wc_os_products']['quantity_split']))?true:false);
			

			$ticked = ($default_ticked || $exclusive_ticked || $inclusive_ticked || $shredder_ticked || $io_ticked);//in_array($prod->ID, $wc_os_products_ids);
			//pree($prod->ID);
			//pree($exclusive_ticked);
			//pree(($default_ticked .' || '. $exclusive_ticked .' || '. $inclusive_ticked .' || '. $shredder_ticked .' || '. $io_ticked));
			
			$product_cats = wp_get_post_terms($prod->ID, 'product_cat', array('fields' => 'names'));
			
			$multiple_cats = (count($product_cats)>1);
			
?>

<tr>
<td>
<?php //if(!$multiple_cats): ?>
<input id="wip-<?php echo $prod->ID; ?>" <?php checked($ticked); ?> type="checkbox" name="<?php echo $wc_os_ie_name; ?>" value="<?php echo $prod->ID; ?>" class="<?php echo $ticked?'':'hides'; ?>" />
<?php //endif; ?>
</td>
<td><label for="wio-<?php echo $prod->ID; ?>"><?php echo $product->managing_stock()?(($product->is_in_stock() && $product->get_stock_quantity()>0)?'<span class="green"><b>'.__('In', 'woo-order-splitter').'</b></span>':'<span class="red">'.__('Out', 'woo-order-splitter').'</span>'):'<small class="faded">'.__('N/A', 'woo-order-splitter').'</small>'; ?></label></td>
<td><label for="wip-<?php echo $prod->ID; ?>"><?php echo $prod->post_title.' '.$wc_os_currency.$product->get_price(); ?></label></td>
<td><label for="win-<?php echo $prod->ID; ?>"><?php echo implode(', ',  $product_cats); ?></label></td>
<td class="split-actions">
	<ul>
    	
        <li><input <?php checked($default_ticked); ?> id="default-<?php echo $prod->ID; ?>" type="radio" value="default" <?php //disabled($multiple_cats); ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="default-<?php echo $prod->ID; ?>"><?php echo split_actions_display('default', 'title'); ?></label></li>
        <li><input <?php checked($exclusive_ticked); ?> id="exclusive-<?php echo $prod->ID; ?>" type="radio" value="exclusive" <?php //disabled($multiple_cats); ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="exclusive-<?php echo $prod->ID; ?>"><?php echo split_actions_display('exclusive', 'title'); ?></label></li>
        <li><input <?php checked($inclusive_ticked); ?> id="inclusive-<?php echo $prod->ID; ?>" type="radio" value="inclusive" <?php //disabled($multiple_cats); ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="inclusive-<?php echo $prod->ID; ?>"><?php echo split_actions_display('inclusive', 'title'); ?></label></li>
        <li><input <?php checked($shredder_ticked); ?> id="shredder-<?php echo $prod->ID; ?>" type="radio" value="shredder" <?php //disabled($multiple_cats); ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="shredder-<?php echo $prod->ID; ?>"><?php echo split_actions_display('shredder', 'title'); ?></label></li>
        <li><input <?php checked($io_ticked); ?> id="io-<?php echo $prod->ID; ?>" type="radio" value="io" <?php disabled(!$wc_os_pro); //$multiple_cats ||  ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="io-<?php echo $prod->ID; ?>"><?php echo split_actions_display('io', 'title'); ?></label></li>
        <li><input <?php checked($qty_ticked); ?> id="quantity_split-<?php echo $prod->ID; ?>" type="radio" value="quantity_split" <?php disabled(!$wc_os_pro); ?> name="split_action[<?php echo $prod->ID; ?>]" /><label for="quantity_split-<?php echo $prod->ID; ?>"><?php echo split_actions_display('quantity_split', 'title'); ?></label></li>
    </ul>

	<select id="group-<?php echo $prod->ID; ?>" name="split_action[groups][<?php echo $prod->ID; ?>]" data-ie="groups">
    <option value=""></option>
    	<?php foreach($groups_arr as $v): 
			$k = strtolower($v);
			$groups_selected = (isset($wc_os_settings['wc_os_products']['groups'][$k])?$wc_os_settings['wc_os_products']['groups'][$k]:array());
		?>
        <option <?php selected(in_array($prod->ID, $groups_selected)); ?> value="<?php echo $k; ?>"><?php echo $v; ?></option>
        <?php endforeach; ?>
    </select>
  
</td>
<td><a href="<?php echo get_edit_post_link($prod->ID); ?>" target="_blank"><?php _e('Edit', 'woo-order-splitter'); ?></a> - <a href="<?php echo get_permalink($prod->ID); ?>" target="_blank"><?php _e('View', 'woo-order-splitter'); ?></a>
</td>
</tr>
<?php
		}
?>
</tbody>
</table>

<?php    
	}
?>		
<?php break; //case 'cats': break; 
} ?>

<div><br />
<small><?php _e('Warning: Products in multiple categories might will produce unexpected results. It is not recommended to split product items in multiple categories.', 'woo-order-splitter'); ?></small>
</div>


<p class="submit">


<input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>

<input type="hidden" name="wc_os_settings[wc_os_products][]" value="0" />

</form>

<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" class="wos_categories_list">
<label></label>
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<?php wp_nonce_field( 'wc_os_cats_action', 'wc_os_cats_field' ); ?>
<?php
	if( !empty($product_categories) ){
		$groups_arr = range('A', 'Z');
	//wc_os_pree(get_option('wc_os_settings'));//exit;
?>
<table border="0" class="">
<thead>
<th><?php _e('Enable/Disable', 'woo-order-splitter'); ?></th>
<th><?php _e('No. of Products', 'woo-order-splitter'); ?></th>
<th><?php _e('Category Name', 'woo-order-splitter'); ?></th>
<th><?php _e('Split Group', 'woo-order-splitter'); ?></th>
<th><?php _e('Category Actions', 'woo-order-splitter'); ?></th>
</thead>
<tbody>
<?php	
			$wc_os_ie_name = 'wc_os_cats[]';
		
		
			
			foreach ($product_categories as $key => $category) {
			
	 			//pree($category);


?>

<tr>
<td><input id="wic-<?php echo $category->term_id; ?>" <?php checked($ticked); ?> type="checkbox" name="<?php echo $wc_os_ie_name; ?>" value="<?php echo $category->term_id; ?>" class="<?php echo $ticked?'':'hides'; ?>" /></td>
<td><a target="_blank" href="<?php echo admin_url(); ?>/edit.php?product_cat=<?php echo $category->slug; ?>&post_type=product"><?php echo $category->count; ?></a></td>
<td><label for="wic-<?php echo $category->term_id; ?>"><?php echo $category->name; ?></label></td>
<td class="split-actions" data-id="<?php echo $category->term_id; ?>">

	<ul>
    	<li><input id="default-<?php echo $category->term_id; ?>" type="radio" value="default" name="split_action[<?php echo $category->term_id; ?>]" /><label for="default-<?php echo $category->term_id; ?>"><?php echo split_actions_display('default', 'title'); ?></label></li>
        <li><input id="exclusive-<?php echo $category->term_id; ?>" type="radio" value="exclusive" name="split_action[<?php echo $category->term_id; ?>]" /><label for="exclusive-<?php echo $category->term_id; ?>"><?php echo split_actions_display('exclusive', 'title'); ?></label></li>
        <li><input id="inclusive-<?php echo $category->term_id; ?>" type="radio" value="inclusive" name="split_action[<?php echo $category->term_id; ?>]" /><label for="inclusive-<?php echo $category->term_id; ?>"><?php echo split_actions_display('inclusive', 'title'); ?></label></li>
        <li><input id="shredder-<?php echo $category->term_id; ?>" type="radio" value="shredder" name="split_action[<?php echo $category->term_id; ?>]" /><label for="shredder-<?php echo $category->term_id; ?>"><?php echo split_actions_display('shredder', 'title'); ?></label></li>
        <li><input id="io-<?php echo $category->term_id; ?>"  <?php disabled(!$wc_os_pro); ?> type="radio" value="io" name="split_action[<?php echo $category->term_id; ?>]" /><label for="io-<?php echo $category->term_id; ?>"><?php echo split_actions_display('io', 'title'); ?></label></li>
        <li><input id="none-<?php echo $category->term_id; ?>" type="radio" value="none" name="split_action[<?php echo $category->term_id; ?>]" /><label for="none-<?php echo $category->term_id; ?>"><?php echo split_actions_display('none', 'title'); ?></label></li>
    </ul>
    
    <select id="group-cat-<?php echo $category->term_id; ?>" name="split_action[group_cats][<?php echo $category->term_id; ?>]" data-ie="group_cats">
    <option value=""></option>
    	<?php foreach($groups_arr as $v): 
			$k = strtolower($v);
			$groups_selected = (isset($wc_os_settings['wc_os_products']['group_cats'][$k])?$wc_os_settings['wc_os_products']['group_cats'][$k]:array());
		?>
        <option <?php selected(in_array($category->term_id, $groups_selected)); ?> value="<?php echo $k; ?>"><?php echo $v; ?></option>
        <?php endforeach; ?>
    </select>
</td>
<td><a href="<?php echo get_edit_term_link($category); ?>" target="_blank"><?php _e('Edit', 'woo-order-splitter'); ?></a> - <a href="<?php echo get_term_link($category); ?>" target="_blank"><?php _e('View', 'woo-order-splitter'); ?></a>
</td>
</tr>
<?php
		}
?>
</tbody>
</table>

<div><br />
<small><?php _e('Warning: Products in multiple categories might will produce unexpected results. It is not recommended to split product items in multiple categories.', 'woo-order-splitter'); ?></small>
</div>
<?php	
	}
?>	
<input type="hidden" name="<?php echo $wc_os_ie_name; ?>" value="0" />

<input type="hidden" name="split_action[group_cats][0]" value="" />
<input type="hidden" name="wc_os_cats[group_cats][0][]" value="" />
<p class="submit"><input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>
</form>



<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" class="wos_vendors_list">
<label></label>
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<?php wp_nonce_field( 'wc_os_vendors_action', 'wc_os_vendors_field' ); ?>
<?php
	$vendors_query = "SELECT post_author FROM $wpdb->posts WHERE (post_author>0 AND post_type='product' AND post_status='publish') GROUP BY post_author";	
	$product_vendors = $wpdb->get_results($vendors_query);
	if( !empty($product_vendors) ){
		$groups_arr = range('A', 'Z');
	//wc_os_pree(get_option('wc_os_settings'));//exit;
?>
<table border="0" class="">
<thead>
<th><?php _e('Enable/Disable', 'woo-order-splitter'); ?></th>
<th><?php _e('Vendor Name', 'woo-order-splitter'); ?></th>
<th><?php _e('Split Group', 'woo-order-splitter'); ?></th>
<th><?php _e('Actions', 'woo-order-splitter'); ?></th>
</thead>
<tbody>
<?php	
			$wc_os_ie_name = 'wc_os_vendors[]';
		
		
			
			foreach ($product_vendors as $key => $vendor) {
			$display_name = wos_get_author_name($vendor->post_author);
			
	 			//pree($category);

			if($display_name):
			
			$vendor_edit_shop_url = admin_url().'edit.php?post_type=product&vendor='.$vendor->post_author;
			$vendor_view_shop_url = get_permalink( woocommerce_get_page_id( 'shop' ) ).'?vendor='.$vendor->post_author;
?>

<tr>
<td><input id="wic-<?php echo $vendor->post_author; ?>" <?php checked($ticked); ?> type="checkbox" name="<?php echo $wc_os_ie_name; ?>" value="<?php echo $vendor->post_author; ?>" class="<?php //echo $ticked?'':'hides'; ?>" /></td>
<td><a target="_blank" href="<?php echo $vendor_url = admin_url().'user-edit.php?user_id='.$vendor->post_author; ?>"><?php echo $display_name; ?></a></td>

<td class="split-actions" data-id="<?php echo $vendor->post_author; ?>">

	
    
    <select id="group-vendor-<?php echo $vendor->post_author; ?>" name="split_action[wc_os_vendors][<?php echo $vendor->post_author; ?>]" data-ie="group_by_vendors">
    <option value=""></option>
    	<?php foreach($groups_arr as $v): 
			$k = strtolower($v);
			$groups_selected = (isset($wc_os_settings['wc_os_vendors'][$k])?$wc_os_settings['wc_os_vendors'][$k]:array());
		?>
        <option <?php selected(in_array($vendor->post_author, $groups_selected)); ?> value="<?php echo $k; ?>"><?php echo $v; ?></option>
        <?php endforeach; ?>
    </select>
</td>
<td><a href="<?php echo $vendor_edit_shop_url; ?>" target="_blank"><?php _e('Edit', 'woo-order-splitter'); ?></a> - <a href="<?php echo $vendor_view_shop_url; ?>" target="_blank"><?php _e('View', 'woo-order-splitter'); ?></a>
</td>
</tr>
<?php
			endif;
		}
?>
</tbody>
</table>

<div><br />
<small><?php _e('Note: Products by unselected vendors will remain in the parent order.', 'woo-order-splitter'); ?></small>
</div>
<?php	
	}
?>	
<input type="hidden" name="<?php echo $wc_os_ie_name; ?>" value="0" />

<input type="hidden" name="split_action[wc_os_vendors][0]" value="" />
<input type="hidden" name="wc_os_vendors[0][]" value="" />
<p class="submit"><input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>
</form>

<form class="nav-tab-content hide" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<?php wp_nonce_field( 'wc_os_cuztomization', 'wc_os_cuztomization_field' ); ?>
<p class="submit" style="text-align:right"><input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>
<div class="wos_cart_notices">
<div class="wos_cart_notices_left">
<h3><?php _e('WooCommerce Notices:', 'woo-order-splitter'); ?></h3>
<?php $wos_cart_notices = get_option( 'wc_os_cart_notices', true); ?>
<ul>

<li><textarea name="wos_cart_notices[shop]" placeholder="<?php _e('Shop page notice', 'woo-order-splitter'); ?>"><?php echo $wos_cart_notices['shop']; ?></textarea></li>
<li><textarea name="wos_cart_notices[product]" placeholder="<?php _e('Product page notice', 'woo-order-splitter'); ?>"><?php echo $wos_cart_notices['product']; ?></textarea></li>
<li><textarea name="wos_cart_notices[cart]" placeholder="<?php _e('Cart page notice', 'woo-order-splitter'); ?>"><?php echo $wos_cart_notices['cart']; ?></textarea></li>
<li><textarea name="wos_cart_notices[checkout]" placeholder="<?php _e('Checkout page notice', 'woo-order-splitter'); ?>"><?php echo $wos_cart_notices['checkout']; ?></textarea></li>
<li style="display:none"><textarea name="wos_cart_notices[thankyou]" placeholder="<?php _e('Thankyou page notice', 'woo-order-splitter'); ?>"><?php echo $wos_cart_notices['thankyou']; ?></textarea></li>

</ul>
<small><?php _e('Note: Keep these fields empty to disable.', 'woo-order-splitter'); ?></small>
</div>
<div class="wos_cart_notices_right">
<h3><?php _e('Notices Styles:', 'woo-order-splitter'); ?></h3>
<ul>
<li>
	<textarea name="wos_cart_notices[styles]" placeholder=".wos_notice_div {} .woocommerce-checkout .wos_notice_div{} .post-type-archive-product .wos_notice_div{}"><?php echo (isset($wos_cart_notices['styles']) && trim($wos_cart_notices['styles'])!=''?$wos_cart_notices['styles']:$wos_notices_css); ?></textarea>
</li>
</ul>    
</div>
</div>

<?php if(!empty($wos_actions_arr)): ?>
<div class="wos_actions_arr_section">
<h3><?php _e('You can change the label and/or description for each split action(Products):', 'woo-order-splitter'); ?></h3>
<ul>
<?php foreach($wos_actions_arr as $key=>$action_data): ?>
	<li>
    	<div class="actions_left">
    	<input type="text" name="wos_actions[<?php echo $key; ?>][title]" placeholder="<?php echo $action_data['action']; ?>" value="<?php echo ((isset($wc_os_cust[$key]) && $wc_os_cust[$key]['title']!='')?$wc_os_cust[$key]['title']:''); ?>" />
        <span><?php echo $action_data['action']; ?></span>
        </div>
        <div class="actions_right">
        <input type="text" name="wos_actions[<?php echo $key; ?>][description]" placeholder="<?php echo $action_data['description']; ?>" value="<?php echo ((isset($wc_os_cust[$key]) && $wc_os_cust[$key]['description']!='')?$wc_os_cust[$key]['description']:''); ?>" />
        <span><?php echo $action_data['description']; ?></span>
        </div>
    </li>
<?php endforeach; ?>    
</ul>
<small><?php _e('Note: It is for your convenience only. It will not change the functionality in any aspect.', 'woo-order-splitter'); ?></small>
</div>
<?php endif; ?>



<div class="wos_cart_notices_left">
<h3><?php _e('Child Order Page Labels:', 'woo-order-splitter'); ?></h3>
<?php $wos_cart_notices = get_option( 'wc_os_cart_notices', true); ?>
<ul>
<li><input type="text" name="wos_cart_notices[co_heading]" placeholder="<?php _e('Child Order', 'woo-order-splitter'); ?>" value="<?php echo $wos_cart_notices['co_heading']; ?>" /></li>
<li><input type="text" name="wos_cart_notices[co_number]" placeholder="<?php _e('Order number', 'woo-order-splitter'); ?>" value="<?php echo $wos_cart_notices['co_number']; ?>" /></li>
<li><label for="co_total"><input type="checkbox" name="wos_cart_notices[co_total]" id="co_total" value="1" <?php echo checked($wos_cart_notices['co_total']); ?> /><?php _e('Orders Grand Total Display', 'woo-order-splitter'); ?></label></li>
</ul>
<small><?php _e('Note: Keep these fields empty to work with default values.', 'woo-order-splitter'); ?></small>
</div>
<div class="wos_cart_notices_left">
<h3><?php _e('Child Order Emails Text:', 'woo-order-splitter'); ?></h3>
<?php $wos_cart_notices = get_option( 'wc_os_cart_notices', true); ?>
<ul>
<li><input type="text" name="wos_cart_notices[co_esubject]" placeholder="Email Subject: <?php _e('Order# ORDER_ID splitted into ORDER_COUNT new order(s)', 'woo-order-splitter'); ?>" value="<?php echo $wos_cart_notices['co_esubject']; ?>" /></li>
<li><input type="text" name="wos_cart_notices[co_ebody]" placeholder="Email Body: <?php _e('ORDERS_TABLE', 'woo-order-splitter'); ?>" value="<?php echo $wos_cart_notices['co_ebody']; ?>" /></li>
<li><input type="text" name="wos_cart_notices[co_efrom_name]" placeholder="Email From Name: <?php echo get_bloginfo('name'); ?>" value="<?php echo $wos_cart_notices['co_efrom_name']; ?>" /></li>
<li><input type="text" name="wos_cart_notices[co_efrom_email]" placeholder="Email From Email: <?php echo get_bloginfo('admin_email'); ?>" value="<?php echo $wos_cart_notices['co_efrom_email']; ?>" /></li>
<li><input type="text" name="wos_cart_notices[co_ereplyto_email]" placeholder="Email ReplyTo Email: <?php echo get_bloginfo('admin_email'); ?>" value="<?php echo $wos_cart_notices['co_ereplyto_email']; ?>" /></li>
</ul>
<small><?php _e('Note: Keep these fields empty to work with default values.', 'woo-order-splitter'); ?></small>
</div>




<p class="submit"><input type="submit" value="<?php _e('Save Changes', 'woo-order-splitter'); ?>" class="button button-primary" id="submit" name="submit"></p>



</form>


<?php 
if($wc_os_pro && class_exists('wc_os_bulk_order_splitter')): 

	$classObj = new wc_os_bulk_order_splitter;
	$classObj->wc_os_rules();
	//$classObj->wc_os_meta_keys(); //22/05/2019
	
else:
?>
<form class="nav-tab-content hide wc_os_rules" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />

<iframe width="460" height="215" src="https://www.youtube.com/embed/swHpd8-9H-s" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<iframe width="460" height="215" src="https://www.youtube.com/embed/nX9ir93V-ug" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<div class="wc_os_notes"><a href="<?php echo $wc_os_premium_copy; ?>" target="_blank"><?php _e('This is a premium feature.', 'woo-order-splitter'); ?></a></div>

</form>
<form class="nav-tab-content hide wc_os_meta_keys" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" name="wos_tn" value="<?php echo $_GET['t']; ?>" />
<div class="wc_os_notes"><a href="<?php echo $wc_os_premium_copy; ?>" target="_blank"><?php _e('This is a premium feature.', 'woo-order-splitter'); ?></a></div>
</form>
<?php	
endif; ?>





<form class="nav-tab-content wc_os_console hide" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="text" name="wc_os_order_id" placeholder="<?php _e('Order ID', 'woo-order-splitter'); ?>" />
<input type="button" name="wc_os_order_test" value="<?php _e('Test', 'woo-order-splitter'); ?>" />

</form>

</div>

<script type="text/javascript" language="javascript">
jQuery(document).ready(function($) {
	
	<?php if(isset($_POST['wos_tn'])): ?>
	
		$('.nav-tab-wrapper .nav-tab:nth-child(<?php echo $_POST['wos_tn']+1; ?>)').click();
	
	<?php endif; ?>

	
});	
</script>

<style type="text/css">
<?php echo implode('', $css_arr); ?>
	#wpfooter{
		display:none;
	}
<?php if(!$wc_os_pro): ?>

	#adminmenu li.current a.current {
		font-size: 12px !important;
		font-weight: bold !important;
		padding: 6px 0px 6px 12px !important;
	}
	#adminmenu li.current a.current,
	#adminmenu li.current a.current span:hover{
		color:#9B5C8F;
	}
	#adminmenu li.current a.current:hover,
	#adminmenu li.current a.current span{
		color:#fff;
	}	
<?php endif; ?>
	.woocommerce-message,
	.update-nag{
		display:none;
	}

</style>
