// JavaScript Document
jQuery(document).ready(function($){

		$('.woo_inst_checkout_options').on('click', function(){
			if($(this).is(':checked')){
				$(this).parent().addClass('selected');
			}else{
				$(this).parent().removeClass('selected');
			}
		});
		

		
		$('select[name="wc_order_action"]').on('change', function(){

			var obj_wrapper = $('#order_line_items');
			if(obj_wrapper.length>0){
				obj_wrapper.removeClass('wc_os_selection')
				obj_wrapper.find('tr').removeClass('selected');
				obj_wrapper.find('input[name^="wc_os_ps"]').remove();
				$('.woocommerce_order_items_wrapper .wc_os_split_selection').remove();


				if($(this).val()=='wc_os_split_action'){
					obj_wrapper.addClass('wc_os_selection')
					obj_wrapper.find('tr').addClass('selected');					
					$('.woocommerce_order_items_wrapper').prepend('<div class="wc_os_split_selection"><iframe src="https://www.youtube.com/embed/wjClFEeYEzo" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></div>');				
					
					$.each(obj_wrapper.find('tr'), function(){
						$(this).find('td').eq(0).append('<input type="hidden" name="wc_os_ps[]" value="'+$(this).data('order_item_id')+'" />');
					});
					
				}
			}
		});
		

		
		$('#order_line_items tr').on('click', function(){
			if($(this).find('input[name^="wc_os_ps"]').length>0){
				$(this).find('input[name^="wc_os_ps"]').remove();
				$(this).removeClass('selected');
			}else{
				$(this).find('td').eq(0).append('<input type="hidden" name="wc_os_ps[]" value="'+$(this).data('order_item_id')+'" />');
				$(this).addClass('selected');
			}
		});		
		
		if($('select[name="wc_order_action"]').length>0)
		$('select[name="wc_order_action"]').change();
		
		$('.wc-os-defined-rules').on('click', 'ol > li > a', function(){
			var ask = confirm(wos_obj.defined_rules_confirm);
			if(ask){
				var elem = $(this).parents().eq(0);
				var data = {
					'action': 'wos_rules_action',
					'key': $(this).parents().eq(0).data('key')
				};
				
				// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
				$.post(ajaxurl, data, function(response) {
					//alert('Got this from the server: ' + response);
					elem.remove();
				});
								
				
			}
		});
		
		
		function parse_query_string(query) {
		  var vars = query.split("&");
		  var query_string = {};
		  for (var i = 0; i < vars.length; i++) {
			var pair = vars[i].split("=");
			// If first entry with this name
			if (typeof query_string[pair[0]] === "undefined") {
			  query_string[pair[0]] = decodeURIComponent(pair[1]);
			  // If second entry with this name
			} else if (typeof query_string[pair[0]] === "string") {
			  var arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
			  query_string[pair[0]] = arr;
			  // If third or later entry with this name
			} else {
			  query_string[pair[0]].push(decodeURIComponent(pair[1]));
			}
		  }
		  return query_string;
		}		

		$('.wc_settings_div a.nav-tab').click(function(){
			$(this).siblings().removeClass('nav-tab-active');
			$(this).addClass('nav-tab-active');
			$('.nav-tab-content, form:not(.wrap.wc_settings_div .nav-tab-content)').hide();
			$('.nav-tab-content').eq($(this).index()).show();
			window.history.replaceState('', '', wos_obj.this_url+'&t='+$(this).index());	
			$('form input[name="wos_tn"]').val($(this).index());
			wos_obj.wc_os_tab = $(this).index();
			wos_trigger_selected_ie();
			
		});				
		
		var query = window.location.search.substring(1);
		var qs = parse_query_string(query);		
		
		if(typeof(qs.t)!='undefined'){
			$('.wc_settings_div a.nav-tab').eq(qs.t).click();
			
		}
		if($('.wc_settings_div').length>0)
		$('.wc_settings_div').show();		
		
		$('.wc_os_console input[name="wc_os_order_test"]').on('click', function(){
			
			var order_id = $('input[name="wc_os_order_id"]');
			if(order_id.val()!=''){
				var data = {
					'action': 'wos_troubleshooting',
					'order_id': $.trim(order_id.val())
				};				
				// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
				$.post(ajaxurl, data, function(response) {
					
					if($('.wc_os_console ul').length==0)
					$('.wc_os_console').append('<ul></ul>');
					
					//alert('Got this from the server: ' + response);
					var resp = $.parseJSON(response);
					

					$('.wc_os_console ul').prepend('<li style="background-color:rgba('+resp.color.r+','+resp.color.g+','+resp.color.b+',0.05);"></li>');
					$('.wc_os_console ul li').eq(0).html(resp.html);
				});
								
				
			}
		});	
		
		$('#woocommerce-order-items > div.inside .wc-order-items-editable').on('click', '.conflict_status ul li a', function(){
			
			var order_id = $('input[name="wc_os_order_id"]');
			
			if(order_id!=''){
				$('.wos_loading').fadeIn();
				$('.conflict_status ul li a.forced').removeClass('forced');
				$(this).addClass('forced');
				var data = {
					'action': 'wos_forced_ie',
					'order_id': $('#post_ID').val(),
					'order_action': $(this).data('action')
				};				
				// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
				$.post(ajaxurl, data, function(response) {
					
					setTimeout(function(){ document.location.href = wos_obj.orders_list; }, 1000);
					
				});
								
				
			}
		});			
		$('.wos_products_list td.split-actions ul li input[type="radio"]').on('click', function(){
			var wc_os_ie_value = $(this).val();
			var row_id = $(this).attr('id').replace(wc_os_ie_value+'-', '');
			$('#wip-'+row_id).attr({'name':'wc_os_settings[wc_os_products]['+wc_os_ie_value+'][]', 'checked':'checked'}).removeClass('hides');
			
			if(!$('#wc_os_all_product').is(':checked')){
				$('.wc_os_ahead .active').removeClass('active');
				$('.wc_os_ahead + .wc_os_notes, .wc_os_ahead + .wc_os_notes + p').hide();
			}else{
			}
			
		});
		
		$('.wos_products_list td.split-actions select[name^="split_action"]').on('change', function(){			
			
			$(this).parents().eq(1).find('input[type="checkbox"]').removeAttr('checked').addClass('hides');
			$(this).parents().eq(1).find('input[type="radio"]').removeAttr('checked');
			if($.trim($(this).val())!=''){
				$(this).parents().eq(1).find('input[type="checkbox"]').attr({'name':'wc_os_settings[wc_os_products]['+$(this).data('ie')+']['+$(this).val()+'][]', 'checked':'checked'}).removeClass('hides');
			}
		});	
		
		$('.wos_categories_list td.split-actions select[name^="split_action"]').on('change', function(){			
			
			$(this).parents().eq(1).find('input[type="checkbox"]').removeAttr('checked').addClass('hides');
			$(this).parents().eq(1).find('input[type="radio"]').removeAttr('checked');
			if($.trim($(this).val())!=''){
				$(this).parents().eq(1).find('input[type="checkbox"]').attr({'name':'wc_os_cats['+$(this).data('ie')+']['+$(this).val()+'][]', 'checked':'checked'}).removeClass('hides');
			}
		});
		
		$('.wos_vendors_list td.split-actions select[name^="split_action"]').on('change', function(){			
			
			$(this).parents().eq(1).find('input[type="checkbox"]').removeAttr('checked').addClass('hides');
			$(this).parents().eq(1).find('input[type="radio"]').removeAttr('checked');
			if($.trim($(this).val())!=''){
				$(this).parents().eq(1).find('input[type="checkbox"]').attr({'name':'wc_os_vendors['+$(this).val()+'][]', 'checked':'checked'}).removeClass('hides');
			}
		});		
		
		$('.wos_products_list td input[type="checkbox"]').on('click', function(){
			var obj = $(this).parents().eq(1);
			var cv_obj = obj.find('td.split-actions');
			var cv_obj_radio = cv_obj.find('ul li input[type="radio"]:checked');
			var cv_obj_select = cv_obj.find('select');
			if($(this).is(':checked')){
				//console.log(obj);//.data('cv')
				if(typeof obj.data('cv')!='undefined' && obj.data('cv')){
					obj.find('td.split-actions ul li input[id^="'+obj.data('cv')+'"]').attr('checked','checked');
					
				}else{
					return false;
				}
			}else{		
			
				if(cv_obj_radio.length>0){		
					obj.attr('data-cv',cv_obj_radio.val());
					cv_obj_radio.removeAttr('checked');
				}
				
				if(cv_obj_select.length>0){				
					cv_obj_select.val('');
				}
			}	
		});
		
		
		$('.wos_categories_list td input[type="checkbox"], .wos_vendors_list td input[type="checkbox"]').on('click', function(){
			var obj = $(this).parents().eq(1);
			var cv_obj = obj.find('td.split-actions select');

			if($(this).is(':checked') && cv_obj.val()!=''){
			}else{				
				cv_obj.val('');
				$(this).addClass('hides');
			}	
		});
		
		$('.wos_categories_list td.split-actions ul li input[type="radio"]').on('click', function(){
			var wc_os_ie_value = $(this).val();
			var row_id = $(this).attr('id').replace(wc_os_ie_value+'-', '');
			$('#wic-'+row_id).attr({'name':'wc_os_cats['+wc_os_ie_value+'][]', 'checked':'checked'});	
		});		
		
		$('input[name="wc_os_settings[wc_os_ie]"]').on('click', function(){
			//console.log($(this));
			
			switch($(this).attr('id')){
				case 'wc_os_ie_products':
					$(this).parents().eq(1).find('ul, li').toggle();
				break;
				default:
					
					$('.wc_os_ie_wrapper').find('.active').removeClass('active');
					$('.wc_os_ahead + .wc_os_notes, .wc_os_ahead + .wc_os_notes + p').show();
					var wc_os_ie = $(this).val();
					var data = {
						'action': 'wos_auto_settings',
						'wc_os_ie': wc_os_ie
					};				
					// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
					$('input[name^="wc_os_settings[wc_os_products]"').removeAttr('checked').addClass('hides');
					$('td.split-actions ul li input[type="radio"]').removeAttr('checked');
					$('input[name^="wc_os_settings[wc_os_products]"').attr('name', 'wc_os_settings[wc_os_products]['+wc_os_ie+'][]');
					$('.wos_loading').fadeIn();
					$('.wos_products_list, .wos_categories_list').css('opacity', '0.2');
					$(this).parents().eq(1).addClass('active');
					//console.log($(this).parents().eq(1).hasClass('noproducts'));
					//console.log($(this).parents().eq(1).hasClass('nocategories'));
					if($(this).parents().eq(1).hasClass('noproducts') || $(this).parents().eq(1).hasClass('nocategories')){
						$('.wc_os_ahead + .wc_os_notes, .wc_os_ahead + .wc_os_notes + p, .wos_products_list, .wos_products_list + div, .wos_products_list + div + p.submit').hide();
						if($(this).parents().eq(1).hasClass('nocategories')){
							$('.wos_categories_list').hide();
							$('.wos_vendors_list').show();
							$('.wos_vendors_list td input[type="checkbox"], .wos_vendors_list td input[type="radio"]').removeAttr('checked');
						}else{						
							$('.wos_categories_list').show();
							$('.wos_categories_list td input[type="checkbox"], .wos_categories_list td input[type="radio"]').removeAttr('checked');
							
						}
					}else{
						$('.wc_os_ahead + .wc_os_notes, .wc_os_ahead + .wc_os_notes + p, .wos_products_list, .wos_products_list + div, .wos_products_list + div + p.submit').show();
						$('.wos_categories_list').hide();
					}
					
					switch(wc_os_ie){
						default:
							$('.wos_products_list td.split-actions ul').show();
							$('.wos_products_list td.split-actions select').hide();
						break;
						case 'groups':
							$('.wos_products_list td.split-actions ul').hide();						
							$('.wos_products_list td.split-actions select').show();
						break;
						case 'cats':
						break;
						case 'group_cats':
							$('.wos_categories_list td.split-actions ul').hide();						
							$('.wos_categories_list td.split-actions select').show();
							$('.wos_categories_list > label').html($(this).data('title')).show();
							
							
							$.each($('.wos_categories_list td.split-actions select[name^="split_action["]'), function(sp, ac){
								var wic_id = $(this).parent().data('id');
								$(this).attr({'name':'split_action['+wc_os_ie+']['+wic_id+']', 'data-ie': wc_os_ie}).val('');
								$('input[name^="wc_os_cats["]#wic-'+wic_id).attr('name', 'wc_os_cats['+wc_os_ie+']['+$(this).val()+'][]');//.prop('checked', false).hide();
							});
						break;
						case 'group_by_vendors':
							$('.wos_vendors_list > label').html($(this).data('title')).show();
							$('.wos_vendors_list td.split-actions select').show();
						break;
					}
					$.post(ajaxurl, data, function(response) {
						response = $.parseJSON(response);
						//console.log(response);
						$('.wos_loading').fadeOut();
						$('.wos_products_list, .wos_categories_list').css('opacity', '1');
						switch(wc_os_ie){
							default:
									
									var selected_items = response[0];
									$.each(selected_items, function(i,v){
										var i_obj = '.wos_products_list td.split-actions ul li #'+wc_os_ie+'-'+v;
										$('#wip-'+v).attr('checked', 'checked').removeClass('hides');
										$(i_obj).attr('checked', 'checked');	
										$(i_obj).parent().removeClass('wos-selected');
									});
									
									selected_items = response[1];
									$.each(selected_items, function(i,v){
										//$('#wip-'+v).attr('checked', 'checked').removeClass('hides');
										if(typeof v=='object'){
											$.each(v, function(j,k){
												var i_obj = '.wos_products_list td.split-actions ul li #'+i+'-'+k;
												$(i_obj).parent().addClass('wos-selected');												
											});
										}else{
											var i_obj = '.wos_products_list td.split-actions ul li #'+i+'-'+v;
											$(i_obj).parent().addClass('wos-selected');
										}
									});
							break;
							case 'cats':
							break;
							case 'groups':
							case 'group_cats':
							
								
								
								
								$.each(response, function(i,v){
									//console.log(v);
									switch(wc_os_ie){								
										case 'groups':
											if(typeof v!='string'){							
												$.each(v, function(ind,val){	
													//console.log(ind);
													//console.log(val);
													//$('.wos_products_list td.split-actions select#group-'+val).val(i);
													//$('.wos_products_list td.split-actions ul li input[type="radio"]').removeAttr('checked');										
												});		
												$('.wos_products_list td.split-actions select').trigger('change');
											}
										break;
										case 'cats':
										break;
										case 'group_cats':											
											
											if(typeof v!='string'){							
												$('.wos_categories_list td.split-actions ul li input[type="radio"]').removeAttr('checked');	
												$.each(v, function(ind,val){					
													$('.wos_categories_list td.split-actions select#group-cat-'+val).val(i);													
													$('.wos_categories_list td.split-actions ul li #'+ind+'-'+val).attr('checked', 'checked');									
												});
												
												$('.wos_categories_list td.split-actions select').trigger('change');
											}
										break;
										case 'catss':
											$.each(v, function(ind,val){
												//$('#wic-'+val).attr('name', 'wc_os_cats['+i+'][]').attr('checked', 'checked').removeClass('hides');
												$('.wos_categories_list td.split-actions ul li #'+i+'-'+val).attr('checked', 'checked');
											});
										break;
									}
								});
							
							break;
							case 'group_by_vendors':
								$.each(response, function(i,v){
									if(typeof v!='string'){							
										$('.wos_vendors_list td.split-actions ul li input[type="radio"]').removeAttr('checked');	
										$.each(v, function(ind,val){					
											$('.wos_vendors_list td.split-actions select#group-vendor-'+val).val(i);													
											$('.wos_vendors_list td.split-actions ul li #'+ind+'-'+val).attr('checked', 'checked');									
										});
										
										$('.wos_vendors_list td.split-actions select').trigger('change');
									}
								});
							break;
						}
						
					});
					
					
					split_action_toggle($(this));
					
				break;
			}
							
		});			
			
		//if 'All products' checked, disable checking individual products
		$('#wc_os_all_product').on('change', function(){
			//$('[name^="wc_os_settings\[wc_os_products\]"]').attr('disabled', this.checked ? 'disabled' : null);
			if($(this).is(':checked')){
				var action_main = $('.wc_os_ahead .active input:checked').val();
				//console.log(action_main);
				if(action_main){
					$('td.split-actions ul li input[type="radio"][id^="'+action_main+'"]').click();
				}
				
			}else{
				$('.wos_products_list input[name^="wc_os_settings[wc_os_products]"]:checked').click();
			}
		});
		
		//MOVED TO LINE 225
		//if a certain actions is selected, enable 'All products' checkbox, else disable
		//$('[name="wc_os_settings\[wc_os_ie\]"]').on('change', function(){
		//});
		
		//initialize split action
		//$('[name="wc_os_settings\[wc_os_ie\]"]:checked').trigger('change');
		function wos_trigger_selected_ie(){
			if(wos_obj.wc_os_tab==1){
				setTimeout(function(){
					$('input[name="wc_os_settings[wc_os_ie]"][value="'+wos_obj.wc_os_ie+'"]').trigger('click');
					switch(wos_obj.wc_os_ie){
						default:
							$('.wc_os_ie_products').find('ul, li').show();
						break;
						case 'cats':
						break;
					}
				}, 1000);
			}
		}
		
		
		wos_trigger_selected_ie();
		
		
		
		setTimeout(function(){
			if($('.split_lock_bars input[type="checkbox"]').length>0){
				if(!$('.split_lock_bars input[type="checkbox"]').is(':checked')){
					$('.inner_split_lock').show();
				}
			}
			if($('.order_removal_bars input[type="checkbox"]').length>0){
				if(!$('.order_removal_bars input[type="checkbox"]').is(':checked')){
					$('.inner_removal_lock').show();
				}
			}
		}, 1000);
		
		$('.split_lock_bars input[type="checkbox"]').on('click', function(){
			if($(this).is(':checked')){
				$('.inner_split_lock').hide();
			}else{
				$('.inner_split_lock').show();
			}
		});
		
		$('.order_removal_bars input[type="checkbox"]').on('click', function(){
			if($(this).is(':checked')){
				$('.inner_removal_lock').hide();
			}else{
				$('.inner_removal_lock').show();
			}
		});
		
		if(wos_obj.wc_os_splitting){
			//$('body').css('opacity', '0.5');
			$('form#posts-filter').html('<div class="wos_loading"></div>');
			$('.wos_loading').show();
			setTimeout(function(){
				document.location.href = wos_obj.orders_list;
			}, 1000);
		}
		
		//functions
		function split_action_toggle(obj){
			//console.log(selected_value);
			obj.parents().eq(1).addClass('active');
			switch(obj.val())
			{
			  case 'default':
			  case 'exclusive':
			  case 'io':
				$('#wc_os_all_product').removeAttr('checked').attr('disabled', null);
				$('#wc_os_all_product').trigger('change');
				break;
			  default:
			  	
				$('#wc_os_all_product').removeAttr('checked').attr('disabled', 'disabled');
				$('[name^="wc_os_settings\[wc_os_products\]"]').attr('disabled', null);
			}
		}
		
		$('#woocommerce-order-items > div.inside').eq(0).find('.wc-order-items-editable').eq(0).prepend('<div class="conflict_status">'+wos_obj.conflict_status+'</div>');
		
		$('.wos_products_list input[name^="wc_os_settings[wc_os_products]"]').on('click', function(){
			if($(this).is(':checked')){
			}else{
				$(this).parents().eq(1).find('.split-actions input[type="radio"]').removeAttr('checked');
				$(this).addClass('hides');
			}
		});
		
		$('select#bulk-action-selector-top').on('change', function(){
			switch($(this).val()){
				default:
					$('#the-list .wc_actions.column-wc_actions p .wc_os_parent, input[name="wc_os_parent"][type="hidden"]').remove();
				break;
				case 'combine':					
					$('#the-list input[name="post[]"][type="checkbox"]:checked').addClass('wos_parent_mark').prop('checked', false);
					$('#the-list input[name="post[]"][type="checkbox"].wos_parent_mark').removeClass('wos_parent_mark').click();
				break;
			}
		});
		$('#the-list input[name="post[]"][type="checkbox"]').on('click', function(){
			switch($('select#bulk-action-selector-top').val()){
				case 'combine':
					var obj = $(this).parents().eq(1).find('.wc_actions.column-wc_actions p');
					if($(this).is(':checked')){
						if(obj.find('a.wos_parent').length==0){
							obj.append('<a title="Click here to mark this item as parent/main order during this action" class="button wc-action-button wc-action-button-wc_os_parent wc_os_parent"></a>');
						}					
					}else{
						obj.find('.wc_os_parent').remove();
					}
				break;
			}
		});
		
		$('#the-list .wc_actions.column-wc_actions').on('click', 'p .wc_os_parent', function(event){
			event.preventDefault();
			$('p .wc_os_parent.selected').not(this).removeClass('selected');
			$(this).toggleClass('selected');
			
			var cvalue = $(this).parents().eq(2).find('input[name="post[]"][type="checkbox"]:checked').val();
			if($('input[name="wc_os_parent"][type="hidden"]').length==0){
				$('form#posts-filter').prepend('<input type="hidden" name="wc_os_parent" value="'+cvalue+'">');
			}else{
				$('input[name="wc_os_parent"][type="hidden"]').val(cvalue);
			}
		});
		
		
});		