=== Order Splitter for WooCommerce ===
Contributors: fahadmahmood
Tags: woocommerce, orders, duplicate, clone, preorder, split, pending payment, failed, processing, completed, on-hold, cancelled, refunded
Requires at least: 4.4
Tested up to: 5.3
Stable tag: 2.8.3
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html
A great plugin to split WooCommerce orders. You can duplicate orders as well.

== Description ==

WooCommerce is an awesome eCommerce plugin that allows you to sell anything and if you want to sell products that are not on stock yet, but you're sure that you'll have them soon in stock again? So Order Splitter for WooCommerce is a solution for you as you can create a rule for those items. All of the upcoming items can go in a separate orders section/status. It enables you to split, consolidate, clone, your crowd/combined/bulk orders using intelligent rules.

After activation there will  be a Split icon in wp-admin > WooCommerce > orders list page within the order actions. Splits all order Meta data and product data across into the new order ID. Order is created and a note is left in the new order of the older order ID for future reference. Order status is then set on hold awaiting admin to confirm payment. 

How to use this plugin?
[youtube http://www.youtube.com/watch?v=wjClFEeYEzo]

* Author: [Fahad Mahmood](http://www.androidbubbles.com/contact)

* Project URI: <http://androidbubble.com/blog/wordpress/plugins/woo-order-splitter>
 
 
== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. There will now be a Split icon in the to Woocommerce  order overview page within the order actions.


== Frequently Asked Questions ==

= How automatic settings work? =
[youtube http://www.youtube.com/watch?v=tOT4l7_GCIw]

= How order rules work? =
[youtube http://www.youtube.com/watch?v=nX9ir93V-ug]

= How to Consolidate/Merge/Combine WooCommerce Orders? =
[youtube http://www.youtube.com/watch?v=qrZMZAuv-VU]

= YITH Pre-Order Compatibility =
[youtube http://www.youtube.com/watch?v=swHpd8-9H-s]


== Screenshots ==
1. Group by Vendors - Explanation
2. Default Mode - Explanation
3. Exclusive Mode - Explanation
4. Inclusive Mode - Explanation
5. Shredder Mode - Explanation
6. In Stock / Out of Stock Mode - Explanation
7. Quantity Split Mode - Explanation
8. Category Based Mode - Explanation
9. Grouped Categories Mode - Explanation
10. Grouped Products Mode - Explanation
11. Automatic Settings > Illustration [Visual Aid Explained]
12. Settings page
13. Order Page
14. WooCommerce Orders List
15. WooCommerce Orders List > Split & Clone Icons
16. Order Page > Selective Products
17. WooCommerce Orders List > "Split From" column added [Premium Feature]
18. Settings page > "Automatic Settings" [New Feature]
19. Settings page > Rules [Premium Feature]
20. Automatic Settings > Illustration [Visual Aid]

== Changelog ==
= 2.8.3 =
* In stock/out of stock automatic settings was missing same product backorder split. Fixed in this version. [Thanks to Ryan Chmura]
= 2.8.2 =
* Auto clone option added, customer notes will be copied in clone action as well. [Thanks to Ryan & Rafał]
= 2.8.1 =
* In stock/out of stock automatic settings option refined and tested in variable product scenario. [Thanks to Ryan Chmura]
= 2.8.0 =
* Product update with vendor id has been refined. [Thanks to Meikel Wolter]
= 2.7.9 =
* Customer notes are being copied/cloned to the splitted orders. [Thanks to Rafał]
* Shipping cost implemented conditionally and optionally. [Thanks to Rafał]
= 2.7.8 =
* Quantity split synchronized with original order status update option. [Thanks to Ryon Whyte]
= 2.7.7 =
* Product update and order status update hooks are rechecked. [Thanks to Meikel Wolter]
= 2.7.6 =
* Deleted orders will not bug on update_status functon. [Thanks to ryonwhyte]
= 2.7.5 =
* A new status option for splitted orders provided in this version. [Thanks to ryonwhyte]
= 2.7.4 =
* Qty. split default mode tested and improved. [Thanks to ryonwhyte]
= 2.7.3 =
* In stock/out of stock automatic settings option refined and tested in multiple scenarios. [Thanks to Anastasia Wilson]
= 2.7.2 =
* Multi-vendor split method added in automatic settings. [Thanks to Abu Usman]
= 2.7.1 =
* Multi-vendor split method added in automatic settings. [Thanks to maman99]
= 2.7.0 =
* Child order emails refined on order split action. [Thanks to SV Delos]
* Quantity split option improved and a new option added. [Thanks to Eric Holterman]
= 2.6.9 =
* Split action should not affect the stock. Methods refined. [Thanks to Vicenç Vives]
* Quantity split option will work without selecting any product as well. [Thanks to Eric Holterman]
= 2.6.8 =
* Child order emails refined on split action. [Thanks to SV Delos]
= 2.6.7 =
* Child order display on thankyour page and email text management from customization tab added. [Thanks to Brian Trautman]
= 2.6.6 =
* Thank you page will display child orders related information and recalculating order totals. [Thanks to Anita & Brian]
= 2.6.5 =
* Automatic settings revised. [Thanks to Erki Dorbek]
= 2.6.4 =
* Customization tab revised and extra emails are tested. [Thanks to Anita Jinton]
= 2.6.3 =
* Automatic settings are saving now. [Thanks to ehymichy]
= 2.6.2 =
* Grouped categories method tested again and Grouped products method refined. [Thanks to Francesco Porcino]
= 2.6.1 =
= 2.6.0 =
* Another PHP notice related "id was called incorrectly" fixed. [Thanks to joncon62]
= 2.5.9 =
* Category Based and Grouped Categories selection related bug fixed. [Thanks to Mike Stimson]
= 2.5.8 =
* Another PHP warning regarding expected array parameter given null fixed. [Thanks to David Frisch]
= 2.5.7 =
* Split by category groups, splitted orders were not recalculating the totals. It's fixed. [Thanks to Mike Stimson]
= 2.5.6 =
* Product items in orders were missing meta data, refined. [Thanks to Jon Norman & Scott James]
= 2.5.5 =
* A new feature added to disable backorder email notifications. [Thanks to Remy Medranda]
= 2.5.4 =
* Auto split feature tested and refined. [Thanks to Paul Rodarte]
= 2.5.3 =
* Order items meta function wc_get_order_item_meta muted. [Thanks to Remy Medranda]
= 2.5.2 =
* Product items in orders were missing meta data. It has been fixed. [Thanks to Scott James Cop]
= 2.5.1 =
* Products in multiple categories can be splitted as well. [Thanks to scopmiles]
= 2.5.0 =
* Consolidation feature improved with parent order toggle button. [Thanks to Remy Medranda]
= 2.4.9 =
* Checkboxes aren't visible until radio button or select box aren't selected. [Thanks to Jim Fulford]
= 2.4.8 =
* Two more bulk options added. [Thanks to Don Carrick]
= 2.4.7 =
* Added premium version link on settings page. [Thanks to Don Martin]
= 2.4.6 =
* Category grouped option improved in another case where all items are assigned to a category group. [Thanks to Michael Berk]
= 2.4.5 =
* A few notice warnings are handled on settings page. [Thanks to Arthur Chan]
* Auto split checkbox on settings page for split action trigger just after order placement. [Thanks to Michael Berk]
= 2.4.4 =
* Shipping cost should not be added to splitted orders. [Thanks to Michael Berk]
= 2.4.3 =
* No taxes on split if parent order has no taxes. [Thanks to Gwennola LANGE]
= 2.4.2 =
* Grouped categories and grouped products introduced. [Thanks to Michael Berk]
= 2.4.1 =
* Shipping cost will be divided among order items on split. [Thanks to Gwennola LANGE]
* Category based split actions got another item as none. [Thanks to Michael Berk]
* Group based split actions are introduced. [Thanks to Michael Berk]
= 2.4.0 =
* Cart notices were causing empty product description, it has been fixed. [Thanks to Sunny Chang]
= 2.3.9 =
* Custom WooCommere order statuses can be configured for split triggers. [Thanks to Arthur Chan]
= 2.3.8 =
* Quantity split added in auto settings, custom quantity can be used to split products with order. [Thanks to Peter Brazier]
* Multiple split actions can be configured and triggered based on selected products. [Thanks to Arthur Chan]
= 2.3.7 =
* The Events Calendar meta keys are conditionally added. [Thanks kranate]
= 2.3.6 =
* Order title splitted feature added in optional section. [Thanks to Arthur Chan]
= 2.3.5 =
* Email notifications to customers on consolidation and split action. [Thanks to Arthur Chan]
= 2.3.4 =
* Split lock feature added.
* Category based split option added. [Thanks to Arthur Chan]
= 2.3.3 =
* After consolidation, the order should not be considered for split again automatically. [Thanks to Kim CheeZZ]
= 2.3.2 =
* A couple of notices are fixed and The Events Calendar meta keys are conditionally added. [Thanks to Arthur Chan & kranate]
= 2.3.1 =
* Default split order as well, will clone all meta_keys to splitted order. [Thanks to Diego Saavedra]
= 2.3.0 =
* Order edit effects handled in all automatic settings. [Thanks to Sean Owen]
= 2.2.9 =
* Split option with inclusive auto settings case rechecked with order removal option. [Thanks to Sean Owen & ecreationsllc]
= 2.2.8 =
* Split option with inclusive auto settings case refined. [Thanks to Sean Owen]
= 2.2.7 =
* Split option on order page has been refined for qty split case. [Thanks to Sean Owen]
= 2.2.6 =
* Consolidation option has been refined for edited invoices. [Thanks to Sean Owen & Raees Sufyan]
= 2.2.5 =
* Select all products checkbox in automatic settings. [Thanks to Joshua Dale & Raees Sufyan]
= 2.2.4 =
* Languages added. [Thanks to Abu Usman]
= 2.2.3 =
* In stock/out of stock split action added. [Thanks to Sean Burney]
= 2.2.2 =
* Qty. split related problem fixed. [Thanks to Stelios Agoropoulos]
= 2.2.1 =
* Fatal error reported and fixed. [Thanks to Luca Franchini]
= 2.2.0 =
* Order meta keys to be cloned/copied to new orders. [Thanks to Roland]
= 2.1.9 =
* WooCommerce activation check added. [Thanks to Nick]
* Troubleshooting tab added to provide a better support. [Thanks to Peter & Ruth]
= 2.1.8 =
* Useful video tutorials are included in settings page.
= 2.1.7 =
* Order meta keys selection to be cloned/copied to new orders. [Thanks to Roland]
= 2.1.6 =
* Split status returned false on unaffected orders.
= 2.1.5 =
* Pro version restoration function removed which was active in earlier versions.
= 2.1.4 =
* Orders disappearing problem has been fixed for YITH WooCommerce Pre Orders Extension. [Thanks to Ruth Schofield]
= 2.1.3 =
* YITH WooCommerce Pre-Order | YITH > YITH WooCommerce Pre Orders Extension Compatibility.
* Orders disappearing problem has been fixed. [Thanks to Ruth Schofield]
= 2.1.2 =
* Order notes will remain intact from this version and further.
* YITH Pre-Order for WooCommerce Premium compatibility refined. [Thanks to Ruth Schofield]
= 2.1.1 =
* Save changes action refined for automatic split actions.
= 2.1.0 =
* Video tutorial added for YITH Pre-Order for WooCommerce.
= 2.0.9 =
* Automatic split actions enhanced with shredder option in automatic settings tab.
* Plugin banners updated, and enhanced with pencil drawings. [Thanks to Zunera Fahad]
= 2.0.8 =
* Split Order dropdown option refined on order page. [Thanks to Tameron Green-Garrity]
* Original order removal option after consolidation.
* Default pre-order item's  order status set to wc-on-hold for now.
* Compatibility added for YITH Pre-Order for WooCommerce Premium. [Thanks to Ruth Schofield]
= 2.0.7 =
* Orders can be combined as well. [Thanks to Marcelo Mika & Tameron Green]
= 2.0.6 =
* Automatic split actions refined. [Thanks to Yasir Amin Sial]
= 2.0.5 =
* Automatic split actions added in additional settings tab. [Thanks to Peter Schofield]
* Compatibility added for YITH Pre-Order for WooCommerce. [Thanks to Ruth Schofield]
= 2.0.4 =
* Split Rules added in Premium version to control order statuses based on product meta keys and values. [Thanks to Peter]
= 2.0.3 =
* Split Order dropdown option enabled for on-hold orders as well. [Thanks to Tameron Green-Garrity]
= 2.0.2 =
* A few notices and warnings are fixed. [Thanks to Dan Rubín]
= 2.0.1 =
* New Orders will skip shipping for virtual items and for those which don't have shipping fee information. [Thanks to Clodoaldo Xavier Gomes]
= 2.0.0 =
* "Split from" column in orders list. [Thanks to Shazliyana Shahizal]
= 1.1.9 =
* Updated according to WooCommerce 3.5.0 [Thanks to Yukari Takase]
= 1.1.8 =
* Bulk options revised. [Thanks to Kranate]
= 1.1.7 =
* Problem with calculate_totals fixed as suggested. [Thanks to kranate]
= 1.1.6 =
* Plugin is compatible with multisite environment now. [Thanks to Eelco Wynia]
= 1.1.5 =
* Products can be selected for split option instead of full order split. [Thanks to Team nutrabay.com]
= 1.1.4 =
* Updated with latest WooCommerce changes regarding bulk actions.
= 1.1.3 =
* Updated with latest WooCommerce changes. [Thanks to Liam Cresswell]
= 1.1.2 =
* Sanitized input and fixed direct file access issues.
= 1.1.1 =
* A few important updates in core.
= 1.1.0 =
* A few important updates in settings.

== Upgrade Notice ==
= 2.8.3 =
In stock/out of stock automatic settings was missing same product backorder split. Fixed in this version.
= 2.8.2 =
Auto clone option added, customer notes will be copied in clone action as well.
= 2.8.1 =
In stock/out of stock automatic settings option refined and tested in variable product scenario.
= 2.8.0 =
Product update with vendor id has been refined.
= 2.7.9 =
Customer notes are being copied/cloned to the splitted orders.
= 2.7.8 =
Quantity split synchronized with original order status update option.
= 2.7.7 =
Product update and order status update hooks are rechecked.
= 2.7.6 =
Deleted orders will not bug on update_status functon.
= 2.7.5 =
A new status option for splitted orders provided in this version.
= 2.7.4 =
Qty. split default mode tested and improved.
= 2.7.3 =
In stock/out of stock automatic settings option refined and tested in multiple scenarios.
= 2.7.2 =
Multi-vendor & stock based split methods are refined.
= 2.7.1 =
Multi-vendor split method added in automatic settings.
= 2.7.0 =
Quantity split option improved and a new option added.
= 2.6.9 =
Split action should not affect the stock. Methods refined.
= 2.6.8 =
Child order emails refined on split action.
= 2.6.7 =
Child order display on thankyour page and email text management from customization tab added.
= 2.6.6 =
Thank you page will display child orders related information and recalculating order totals.
= 2.6.5 =
Automatic settings revised.
= 2.6.4 =
Customization tab revised and extra emails are tested.
= 2.6.3 =
Automatic settings are saving now.
= 2.6.2 =
Grouped categories method tested again and Grouped products method refined.
= 2.6.1 =
Another PHP notice related "id was called incorrectly" fixed.
= 2.6.0 =
Another PHP notice related "id was called incorrectly" fixed.
= 2.5.9 =
Category Based and Grouped Categories selection related bug fixed.
= 2.5.8 =
Another PHP warning regarding expected array parameter given null fixed.
= 2.5.7 =
Split by category groups, splitted orders were not recalculating the totals. It's fixed.
= 2.5.6 =
Product items in orders were missing meta data, refined. - 07 Aug, 2019
= 2.5.5 =
A new feature added to disable backorder email notifications.
= 2.5.4 =
Auto split feature tested and refined.
= 2.5.3 =
Order items meta function wc_get_order_item_meta muted.
= 2.5.2 =
Product items in orders were missing meta data. It has been fixed.
= 2.5.1 =
Products in multiple categories can be splitted as well.
= 2.5.0 =
Consolidation feature improved with parent order toggle button.
= 2.4.9 =
Checkboxes aren't visible until radio button or select box aren't selected.
= 2.4.8 =
Two more bulk options added.
= 2.4.7 =
Added premium version link on settings page.
= 2.4.6 =
Category grouped option improved in another case where all items are assigned to a category group.
= 2.4.5 =
A few notice warnings are handled on settings page.
= 2.4.4 =
Shipping cost should not be added to splitted orders.
= 2.4.3 =
No taxes on split if parent order has no taxes.
= 2.4.2 =
Grouped categories and grouped products introduced.
= 2.4.1 =
Shipping cost will be divided among order items on split.
= 2.4.0 =
Cart notices were causing empty product description, it has been fixed.
= 2.3.9 =
Custom WooCommere order statuses can be configured for split triggers.
= 2.3.8 =
Multiple split actions can be configured and triggered based on selected products.
= 2.3.7 =
The Events Calendar meta keys are conditionally added.
= 2.3.6 =
Order title splitted feature added in optional section.
= 2.3.5 =
Email notifications to customers on consolidation and split action.
= 2.3.4 =
A couple of features added.
= 2.3.3 =
After consolidation, the order should not be considered for split again automatically.
= 2.3.2 =
A couple of notices are fixed and The Events Calendar meta keys are conditionally added.
= 2.3.1 =
Default split order as well, will clone all meta_keys to splitted order.
= 2.3.0 =
Order edit effects handled in all automatic settings.
= 2.2.9 =
Split option with inclusive auto settings case rechecked with order removal option.
= 2.2.8 =
Split option with inclusive auto settings case refined.
= 2.2.7 =
Split option on order page has been refined for qty split case.
= 2.2.6 =
Consolidation option has been refined for edited invoices.
= 2.2.5 =
Select all products checkbox in automatic settings.
= 2.2.4 =
Languages added.
= 2.2.3 =
In stock/out of stock split action added.
= 2.2.2 =
Qty. split related problem fixed.
= 2.2.1 =
Fatal error reported and fixed.
= 2.2.0 =
Order meta keys to be cloned/copied to new orders.
= 2.1.9 =
WooCommerce activation check added.
= 2.1.8 =
Useful video tutorials are included in settings page.
= 2.1.7 =
Order meta keys selection to be cloned/copied to new orders.
= 2.1.6 =
Split status returned false on unaffected orders.
= 2.1.5 =
Pro version restoration function removed which was active in earlier versions.
= 2.1.4 =
Orders disappearing problem has been fixed for YITH WooCommerce Pre Orders Extension.
= 2.1.3 =
YITH WooCommerce Pre-Order | YITH > YITH WooCommerce Pre Orders Extension Compatibility.
= 2.1.2 =
YITH Pre-Order for WooCommerce Premium compatibility refined.
= 2.1.1 =
Save changes action refined for automatic split actions.
= 2.1.0 =
Video tutorial added for YITH Pre-Order for WooCommerce.
= 2.0.9 =
Automatic split actions enhanced with shredder option in automatic settings tab.
= 2.0.8 =
Split Order dropdown option refined on order page.
= 2.0.7 =
Orders can be combined as well.
= 2.0.6 =
Automatic split actions refined.
= 2.0.5 =
Automatic split actions added in additional settings tab.
= 2.0.4 =
Split Rules added in Premium version to control order statuses based on product meta keys and values.
= 2.0.3 =
Split Order dropdown option enabled for on-hold orders as well.
= 2.0.2 =
A few notices and warnings are fixed.
= 2.0.1 =
New Orders will skip shipping for virtual items and for those which don't have shipping fee information. [Thanks to Clodoaldo Xavier Gomes]
= 2.0.0 =
"Split from" column in orders list.
= 1.1.9 =
Updated according to WooCommerce 3.5.0
= 1.1.8 =
Bulk options revised.
= 1.1.7 =
Problem with calculate_totals fixed as suggested.
= 1.1.6 =
Plugin is compatible with multisite environment now.
= 1.1.5 =
Products can be selected for split option instead of full order split.
= 1.1.4 =
Updated with latest WooCommerce changes regarding bulk actions.
= 1.1.3 =
Updated with latest WooCommerce changes.
= 1.1.2 =
Sanitized input and fixed direct file access issues.
= 1.1.1 =
A few important updates in core.
= 1.1.0 =
A few important updates in settings.


== License ==
This WordPress plugin is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
This WordPress plugin is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with this WordPress plugin. If not, see http://www.gnu.org/licenses/gpl-2.0.html.